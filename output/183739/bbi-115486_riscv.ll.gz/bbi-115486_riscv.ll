
define void @f(ptr %dst, ptr %src, i32 %x, i1 %c3) {
entry:
  br label %for.body36

for.cond.cleanup35:                               ; preds = %cond.end158
  ret void

for.body36:                                       ; preds = %cond.end158, %entry
  %iv = phi i64 [ 0, %entry ], [ %iv.next, %cond.end158 ]
  %gep.src = getelementptr i32, ptr %src, i64 %iv
  %val = load i32, ptr %gep.src, align 4
  %cmp42 = icmp sgt i32 %val, 0
  br i1 %cmp42, label %land.lhs.true43, label %cond.end96.sink.split

land.lhs.true43:                                  ; preds = %for.body36
  %div5 = sdiv i32 1, %x
  %div6 = sdiv i32 1, %x
  %div7 = sdiv i32 1, %x
  %div8 = sdiv i32 1, %x
  %div9 = sdiv i32 1, %x
  %div10 = sdiv i32 1, %x
  %gadd106 = or i32 %div9, %div10
  %div11 = sdiv i32 1, %x
  %div12 = sdiv i32 1, %x
  %gadd107 = or i32 %div11, %div12
  %div13 = sdiv i32 1, %x
  %div14 = sdiv i32 1, %x
  %gadd109 = or i32 %div13, %div14
  %div15 = sdiv i32 1, %x
  %div16 = sdiv i32 1, %x
  %gadd110 = or i32 %div15, %div16
  %div1 = sdiv i32 1, %x
  %div2 = sdiv i32 1, %x
  %gadd100 = or i32 %div1, %div2
  %div3 = sdiv i32 1, %x
  %div4 = sdiv i32 1, %x
  %gadd101 = or i32 %div3, %div4
  %gadd102 = or i32 %gadd100, %gadd101
  %gadd103 = or i32 %div5, %div6
  %gadd104 = or i32 %div7, %div8
  %gadd105 = or i32 %gadd103, %gadd104
  %fadd112 = or i32 %gadd102, %gadd105
  %gadd108 = or i32 %gadd106, %gadd107
  %gadd111 = or i32 %gadd109, %gadd110
  %fadd113 = or i32 %gadd108, %gadd111
  %fadd114 = or i32 %fadd112, %fadd113
  %cmp46 = icmp slt i32 %fadd114, 0
  br i1 %cmp46, label %cond.end96, label %cond.end96.sink.split

cond.end96.sink.split:                            ; preds = %land.lhs.true43, %for.body36
  br label %cond.end96

cond.end96:                                       ; preds = %cond.end96.sink.split, %land.lhs.true43
  br i1 %c3, label %cond.end158, label %lor.lhs.false144

lor.lhs.false144:                                 ; preds = %cond.end96
  br i1 false, label %cond.end158, label %lor.lhs.false151

lor.lhs.false151:                                 ; preds = %lor.lhs.false144
  br label %cond.end158

cond.end158:                                      ; preds = %lor.lhs.false151, %lor.lhs.false144, %cond.end96
  %cond159 = phi i32 [ 1, %lor.lhs.false151 ], [ 0, %cond.end96 ], [ 0, %lor.lhs.false144 ]
  %gep.dst = getelementptr i32, ptr %dst, i64 %iv
  store i32 %cond159, ptr %gep.dst, align 4
  %iv.next = add i64 %iv, 1
  %done = icmp eq i64 %iv, 1024
  br i1 %done, label %for.cond.cleanup35, label %for.body36
}
