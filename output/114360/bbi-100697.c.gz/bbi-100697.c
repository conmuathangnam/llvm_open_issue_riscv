#include <stdio.h>

typedef signed short int __int16_t;
typedef __int16_t int16_t;

typedef unsigned short int __uint16_t;
typedef __uint16_t uint16_t;

typedef struct tnr_t {
    int16_t tnr;
    uint16_t faults;
} tnr_t;



static signed _BitInt(107) idbi(signed _BitInt(107) b) {
  signed _BitInt(107) res;
  res = b;
  return res;
}

tnr_t test_oper3_ternary_9(tnr_t tnr)
{
    _BitInt(107) x, y, z;
    _BitInt(107) res;
    x = idbi((((_BitInt(107))1wb << ((107) - 2)) - 1wb));
    y = idbi((_BitInt(107))-((107) & 1 ? (_BitInt(107))~(unsigned _BitInt((107) / 2))0uwb : (_BitInt(107))( 0xb504f333f9de6484597d89b3754abe9fuwb >> (128 - (107) / 2))));
    z = idbi((_BitInt(107))-(((_BitInt(107))1wb << ((107) - 2)) - 1wb));
    res = (_BitInt(107))(x & y & z);
    tnr = (tnr_t){ .faults = tnr.faults + ((_BitInt(107))(res) == (_BitInt(107))(((((_BitInt(107))1wb << ((107) - 2)) - 1wb)) & ((_BitInt(107))-((107) & 1 ? (_BitInt(107))~(unsigned _BitInt((107) / 2))0uwb : (_BitInt(107))( 0xb504f333f9de6484597d89b3754abe9fuwb >> (128 - (107) / 2)))) & ((_BitInt(107))-(((_BitInt(107))1wb << ((107) - 2)) - 1wb))) ? 0 : 1) } ;
    x = idbi(x);
    y = idbi(y);
    res = (_BitInt(107))(x & y & ((_BitInt(107))-(((_BitInt(107))1wb << ((107) - 2)) - 1wb)));
    tnr = (tnr_t){ .faults = tnr.faults + ((_BitInt(107))(res) == (_BitInt(107))(((((_BitInt(107))1wb << ((107) - 2)) - 1wb)) & ((_BitInt(107))-((107) & 1 ? (_BitInt(107))~(unsigned _BitInt((107) / 2))0uwb : (_BitInt(107))( 0xb504f333f9de6484597d89b3754abe9fuwb >> (128 - (107) / 2)))) & ((_BitInt(107))-(((_BitInt(107))1wb << ((107) - 2)) - 1wb))) ? 0 : 1) } ;
    z = idbi(z);
    res = (_BitInt(107))(((((_BitInt(107))1wb << ((107) - 2)) - 1wb)) & ((_BitInt(107))-((107) & 1 ? (_BitInt(107))~(unsigned _BitInt((107) / 2))0uwb : (_BitInt(107))( 0xb504f333f9de6484597d89b3754abe9fuwb >> (128 - (107) / 2)))) & z);
    tnr = (tnr_t){ .faults = tnr.faults + ((_BitInt(107))(res) == (_BitInt(107))(((((_BitInt(107))1wb << ((107) - 2)) - 1wb)) & ((_BitInt(107))-((107) & 1 ? (_BitInt(107))~(unsigned _BitInt((107) / 2))0uwb : (_BitInt(107))( 0xb504f333f9de6484597d89b3754abe9fuwb >> (128 - (107) / 2)))) & ((_BitInt(107))-(((_BitInt(107))1wb << ((107) - 2)) - 1wb))) ? 0 : 1) } ;

    return tnr;
}

tnr_t test_oper3_ternary_11(tnr_t tnr)
{
    _BitInt(107) x, y, z;
    _BitInt(107) res;
    x = (_BitInt(107))-((_BitInt(107))1wb);
    y = idbi((_BitInt(107))-((107) & 1 ? (_BitInt(107))~(unsigned _BitInt((107) / 2))0uwb : (_BitInt(107))( 0xb504f333f9de6484597d89b3754abe9fuwb >> (128 - (107) / 2))));
    z = idbi((_BitInt(107))-(((_BitInt(107))1wb << ((107) - 2)) + 1wb));
    res = (_BitInt(107))(x & y & z);
    tnr = (tnr_t){ .faults = tnr.faults + ((_BitInt(107))(res) == (_BitInt(107))(((_BitInt(107))-((_BitInt(107))1wb)) & ((_BitInt(107))-((107) & 1 ? (_BitInt(107))~(unsigned _BitInt((107) / 2))0uwb : (_BitInt(107))( 0xb504f333f9de6484597d89b3754abe9fuwb >> (128 - (107) / 2)))) & ((_BitInt(107))-(((_BitInt(107))1wb << ((107) - 2)) + 1wb))) ? 0 : 1) } ;
    res = (_BitInt(107))(x & y & ((_BitInt(107))-(((_BitInt(107))1wb << ((107) - 2)) + 1wb)));
    tnr = (tnr_t){ .faults = tnr.faults + ((_BitInt(107))(res) == (_BitInt(107))(((_BitInt(107))-((_BitInt(107))1wb)) & ((_BitInt(107))-((107) & 1 ? (_BitInt(107))~(unsigned _BitInt((107) / 2))0uwb : (_BitInt(107))( 0xb504f333f9de6484597d89b3754abe9fuwb >> (128 - (107) / 2)))) & ((_BitInt(107))-(((_BitInt(107))1wb << ((107) - 2)) + 1wb))) ? 0 : 1) } ;
    y = (_BitInt(107))-((107) & 1 ? (_BitInt(107))~(unsigned _BitInt((107) / 2))0uwb : (_BitInt(107))( 0xb504f333f9de6484597d89b3754abe9fuwb >> (128 - (107) / 2)));
    res = (_BitInt(107))(((_BitInt(107))-((_BitInt(107))1wb)) & ((_BitInt(107))-((107) & 1 ? (_BitInt(107))~(unsigned _BitInt((107) / 2))0uwb : (_BitInt(107))( 0xb504f333f9de6484597d89b3754abe9fuwb >> (128 - (107) / 2)))) & z);
    tnr = (tnr_t){ .faults = tnr.faults + ((_BitInt(107))(res) == (_BitInt(107))(((_BitInt(107))-((_BitInt(107))1wb)) & ((_BitInt(107))-((107) & 1 ? (_BitInt(107))~(unsigned _BitInt((107) / 2))0uwb : (_BitInt(107))( 0xb504f333f9de6484597d89b3754abe9fuwb >> (128 - (107) / 2)))) & ((_BitInt(107))-(((_BitInt(107))1wb << ((107) - 2)) + 1wb))) ? 0 : 1) } ;

    return tnr;
}

int main(void)
{
    tnr_t tnr = { 0, 0 };

    _BitInt(107) z;
    _BitInt(107) res;
    z = idbi((_BitInt(107))-((_BitInt(107))1wb << ((107) - 2)));
    res = (_BitInt(107))((((_BitInt(107))1wb << ((107) - 2))) & ((_BitInt(107))-((_BitInt(107))1wb)) & z);
    tnr = (tnr_t){ .faults = tnr.faults + ((_BitInt(107))(res) == (_BitInt(107))((((_BitInt(107))1wb << ((107) - 2))) & ((_BitInt(107))-((_BitInt(107))1wb)) & ((_BitInt(107))-((_BitInt(107))1wb << ((107) - 2)))) ? 0 : 1) } ;

    tnr = test_oper3_ternary_9(tnr);
    tnr = test_oper3_ternary_11(tnr);

    if (tnr.faults != 0)
      printf("Fail!\n");
    else
      printf("Pass!\n");

    return 0;
}
