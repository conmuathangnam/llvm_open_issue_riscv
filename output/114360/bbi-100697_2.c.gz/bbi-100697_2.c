#include <stdio.h>

typedef signed short int __int16_t;
typedef __int16_t int16_t;

typedef unsigned short int __uint16_t;
typedef __uint16_t uint16_t;

typedef struct tnr_t {
    int16_t dummy;
    uint16_t faults;
} tnr_t;



static signed _BitInt(107) idbi(signed _BitInt(107) b) {
  signed _BitInt(107) res;
  res = b;
  return res;
}

tnr_t test_oper3_ternary_9(tnr_t tnr)
{
    _BitInt(107) x, y, z;
    _BitInt(107) res;
    x = idbi(((_BitInt(107))1wb << 105) - 1wb);
    y = idbi(-((_BitInt(107))~(unsigned _BitInt(53))0uwb));
    z = idbi(-(((_BitInt(107))1wb << 105) - 1wb));

    res = x & y & z;
    tnr.faults += (res == (((((_BitInt(107))1wb << 105) - 1wb)) & (-((_BitInt(107))~(unsigned _BitInt(53))0uwb)) & (-(((_BitInt(107))1wb << 105) - 1wb))) ? 0 : 1);

    x = idbi(x);
    y = idbi(y);

    res = x & y & (-(((_BitInt(107))1wb << 105) - 1wb));
    tnr.faults += (res == (((((_BitInt(107))1wb << 105) - 1wb)) & (-((_BitInt(107))~(unsigned _BitInt(53))0uwb)) & (-(((_BitInt(107))1wb << (105)) - 1wb))) ? 0 : 1);

    z = idbi(z);

    res = (((_BitInt(107))1wb << 105) - 1wb) & (-((_BitInt(107))~(unsigned _BitInt(53))0uwb)) & z;
    tnr.faults += (res == (((((_BitInt(107))1wb << 105) - 1wb)) & (-((_BitInt(107))~(unsigned _BitInt(53))0uwb)) & (-(((_BitInt(107))1wb << (105)) - 1wb))) ? 0 : 1);

    return tnr;
}

tnr_t test_oper3_ternary_11(tnr_t tnr)
{
    _BitInt(107) y, z;
    _BitInt(107) res;
    y = idbi(-((_BitInt(107))~(unsigned _BitInt(53))0uwb));
    z = idbi((((_BitInt(107))1wb << 105)));

    res = y & z;
    tnr.faults += (res == ((-((_BitInt(107))~(unsigned _BitInt(53))0uwb)) & ((((_BitInt(107))1wb << 105)))) ? 0 : 1) ;

    res = y & (-(((_BitInt(107))1wb << 105)));
    tnr.faults += (res == ((-((_BitInt(107))~(unsigned _BitInt(53))0uwb)) & (-(((_BitInt(107))1wb << 105)))) ? 0 : 1) ;

    printf("tnr.faults = %d\n", tnr.faults);

    return tnr;
}

int main(void)
{
    tnr_t tnr = { 0, 0 };

    _BitInt(107) z = idbi((_BitInt(107))1wb);
    _BitInt(107) res = ((_BitInt(107))1wb) & z;

    tnr.faults += (res == (_BitInt(107))1wb) ? 0 : 1;

    tnr = test_oper3_ternary_9(tnr);
    tnr = test_oper3_ternary_11(tnr);

    if (tnr.faults != 0)
      printf("Fail!\n");
    else
      printf("Pass!\n");

    return 0;
}
