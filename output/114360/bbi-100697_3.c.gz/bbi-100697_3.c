#include <stdio.h>

typedef struct tnr_t {
    short dummy;
    unsigned short faults;
} tnr_t;

_BitInt(107) idbi(_BitInt(107) b) {
  return b;
}

tnr_t test_oper3_ternary_9(tnr_t tnr)
{
    _BitInt(107) x1, y1, z1, x2, y2, z2;
    _BitInt(107) res1, res2;

    x2 = ((_BitInt(107))1wb << 105) - 1wb;
    x1 = idbi(x2);
    y2 = -((_BitInt(107))~(unsigned _BitInt(53))0uwb);
    y1 = idbi(y2);
    z2 = -(((_BitInt(107))1wb << 105) - 1wb);
    z1 = idbi(z2);

    res1 = x1 & y1 & z1;
    res2 = x2 & y2 & z2;
    tnr.faults += (res1 == res2 ? 0 : 1);

    x1 = idbi(x1);
    y1 = idbi(y1);
    res1 = x1 & y1 & z2;
    res2 = x2 & y2 & z2;
    tnr.faults += (res1 == res2 ? 0 : 1);

    z1 = idbi(z1);
    res1 = x2 & y2 & z1;
    res2 = x2 & y2 & z2;
    tnr.faults += (res1 == res2 ? 0 : 1);

    return tnr;
}

tnr_t test_oper3_ternary_11(tnr_t tnr)
{
    _BitInt(107) y1, z1, y2, z2;
    _BitInt(107) res1, res2;
    y2 = -((_BitInt(107))~(unsigned _BitInt(53))0uwb);
    y1 = idbi(y2);
    z2 = (_BitInt(107))1wb << 1;
    z1 = idbi(z2);

    res1 = y1 & z1;
    res2 = y2 & z2;
    tnr.faults += (res1 == res2 ? 0 : 1) ;

    z2 = -((_BitInt(107))1wb << 1);
    res2 = y2 & z2;
    res1 = y1 & z2;
    tnr.faults += (res1 == res2 ? 0 : 1) ;

    printf("tnr.faults = %d\n", tnr.faults);

    return tnr;
}

int main(void)
{
    tnr_t tnr = { 0, 0 };

    _BitInt(107) z1, z2;
    _BitInt(107) res1, res2;
    z2 = (_BitInt(107))1wb;
    z1 = idbi(z2);
    res1 = z2 & z1;
    res2 = z2;

    tnr.faults += (res1 == res2) ? 0 : 1;

    tnr = test_oper3_ternary_9(tnr);
    tnr = test_oper3_ternary_11(tnr);

    if (tnr.faults != 0)
      printf("Fail!\n");
    else
      printf("Pass!\n");

    return 0;
}
