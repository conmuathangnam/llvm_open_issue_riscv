!-----------------------------------------------------------------------
!
!WRF:MODEL_LAYER:PHYSICS
!
!####################TIEDTKE SCHEME#########################
!   Taken from the IPRC iRAM - Yuqing Wang, University of Hawaii
!   Added by Chunxi Zhang and Yuqing Wang to WRF3.2, May, 2010
!   refenrence: Tiedtke (1989, MWR, 117, 1779-1800)
!               Nordeng, T.E., (1995), CAPE closure and organized entrainment/detrainment
!               Yuqing Wang et al. (2003,J. Climate, 16, 1721-1738) for improvements 
!                                                  for cloud top detrainment 
!                       (2004, Mon. Wea. Rev., 132, 274-296), improvements for PBL clouds
!                        (2007,Mon. Wea. Rev., 135, 567-585), diurnal cycle of precipitation
!   This scheme is on testing
!###########################################################
MODULE module_cu_tiedtke
!
!+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
! epsl--- allowed minimum value for floating calculation
!---------------------------------------------------------------
      real,parameter ::  epsl  = 1.0e-20
      real,parameter ::  t000  = 273.15
      real,parameter ::  hgfr  = 233.15   ! defined in param.f in explct
!-------------------------------------------------------------    
!  Ends the parameters set
!++++++++++++++++++++++++++++
     REAL,PRIVATE :: G,CPV
     REAL :: API,A,EOMEGA,RD,RV,CPD,RCPD,VTMPC1,VTMPC2,   &
             RHOH2O,ALV,ALS,ALF,CLW,TMELT,SOLC,STBO,DAYL,YEARL, &
             C1ES,C2ES,C3LES,C3IES,C4LES,C4IES,C5LES,C5IES,ZRG 
    
     REAL :: ENTRPEN,ENTRSCV,ENTRMID,ENTRDD,CMFCTOP,RHM,RHC,    &
             CMFCMAX,CMFCMIN,CMFDEPS,RHCDD,CPRCON,CRIRH,ZBUO0,  &
             fdbk,ZTAU
 
     INTEGER :: orgen,nturben,cutrigger

     REAL :: CVDIFTS, CEVAPCU1, CEVAPCU2,ZDNOPRC
    
  
     PARAMETER(A=6371.22E03,                                    &
      ALV=2.5008E6,                 &                  
      ALS=2.8345E6,                 &
      ALF=ALS-ALV,                  &
      CPD=1005.46,                  &
      CPV=1869.46,                  & ! CPV in module is 1846.4
      RCPD=1.0/CPD,                 &
      RHOH2O=1.0E03,                & 
      TMELT=273.16,                 &
      G=9.806,                      & ! G=9.806
      ZRG=1.0/G,                    &
      RD=287.05,                    &
      RV=461.51,                    &
      C1ES=610.78,                  &
      C2ES=C1ES*RD/RV,              &
      C3LES=17.269,                 &
      C4LES=35.86,                  &
      C5LES=C3LES*(TMELT-C4LES),    &
      C3IES=21.875,                 &
      C4IES=7.66,                   &
      C5IES=C3IES*(TMELT-C4IES),    &
      API=3.141593,                 & ! API=2.0*ASIN(1.)
      VTMPC1=RV/RD-1.0,             &
      VTMPC2=CPV/CPD-1.0,           &
      CVDIFTS=1.0,                  &
      CEVAPCU1=1.93E-6*261.0*0.5/G, & 
      CEVAPCU2=1.E3/(38.3*0.293) )

     
!                SPECIFY PARAMETERS FOR MASSFLUX-SCHEME
!                  --------------------------------------
!                   These are tunable parameters
!
!     ENTRPEN: AVERAGE ENTRAINMENT RATE FOR PENETRATIVE CONVECTION
!     -------
!
      PARAMETER(ENTRPEN=1.0E-4)
!
!     ENTRSCV: AVERAGE ENTRAINMENT RATE FOR SHALLOW CONVECTION
!     -------
!
      PARAMETER(ENTRSCV=1.2E-3)
!
!     ENTRMID: AVERAGE ENTRAINMENT RATE FOR MIDLEVEL CONVECTION
!     -------
!
      PARAMETER(ENTRMID=1.0E-4)
!
!     ENTRDD: AVERAGE ENTRAINMENT RATE FOR DOWNDRAFTS
!     ------
!
      PARAMETER(ENTRDD =2.0E-4)
!
!     CMFCTOP:   RELATIVE CLOUD MASSFLUX AT LEVEL ABOVE NONBUOYANCY LEVEL
!     -------
!
      PARAMETER(CMFCTOP=0.30)
!
!     CMFCMAX:   MAXIMUM MASSFLUX VALUE ALLOWED FOR UPDRAFTS ETC
!     -------
!
      PARAMETER(CMFCMAX=1.0)
!
!     CMFCMIN:   MINIMUM MASSFLUX VALUE (FOR SAFETY)
!     -------
!
      PARAMETER(CMFCMIN=1.E-10)
!
!     CMFDEPS:   FRACTIONAL MASSFLUX FOR DOWNDRAFTS AT LFS
!     -------
!
      PARAMETER(CMFDEPS=0.30)
!
!     CPRCON:  COEFFICIENTS FOR DETERMINING CONVERSION FROM CLOUD WATER
!
      PARAMETER(CPRCON = 1.1E-3/G)
!
!     ZDNOPRC: The pressure depth below which no precipitation
!
      PARAMETER(ZDNOPRC =1.5E4)
!--------------------
     PARAMETER(orgen=1)   ! Old organized entrainment rate
!      PARAMETER(orgen=2)   ! New organized entrainment rate

     PARAMETER(nturben=1) ! old deep turburent entrainment/detrainment rate
!      PARAMETER(nturben=2) ! New deep turburent entrainment/detrainment rate

     PARAMETER(cutrigger=1) ! Old trigger function
!      PARAMETER(cutrigger=2) ! New trigger function
!
!--------------------
      PARAMETER(RHC=0.80,RHM=1.0,ZBUO0=0.50)
!--------------------
      PARAMETER(CRIRH=0.70,fdbk = 1.0,ZTAU = 1800.0)
!--------------------
      LOGICAL :: LMFPEN,LMFMID,LMFSCV,LMFDD,LMFDUDV
      PARAMETER(LMFPEN=.TRUE.,LMFMID=.TRUE.,LMFSCV=.TRUE.,LMFDD=.TRUE.,LMFDUDV=.TRUE.)
!--------------------
!#################### END of Variables definition##########################
!-----------------------------------------------------------------------
!
CONTAINS
!-----------------------------------------------------------------------

!====================================================================

!------------This is the combined version for tiedtke---------------
!----------------------------------------------------------------
!  In this module only the mass flux convection scheme of the ECMWF is included
!+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
!#############################################################
!
!#############################################################
!
!**********************************************
!       SUBROUTINE CUTYPE
!********************************************** 
      SUBROUTINE CUTYPE    &
        ( KLON,     KLEV,     KLEVP1,   KLEVM1,&
          PTENH,   PQENH,     PQSENH,    PGEOH,   PAPH,&
          RHO,      HFX,         QFX,    KTYPE,   lndj   )
!      THIS ROUTINE CALCULATES CLOUD BASE and TOP
!      AND RETURN CLOUD TYPES
!      ZHANG & WANG      IPRC           12/2010
!***PURPOSE.
!   --------
!          TO PRODUCE CLOUD TYPE for CU-PARAMETERIZATIONS
!***INTERFACE
!   ---------
!          THIS ROUTINE IS CALLED FROM *CUMASTR*.
!          INPUT ARE ENVIRONM. VALUES OF T,Q,P,PHI AT HALF LEVELS.
!          IT RETURNS CLOUD TYPES AS FOLLOWS;
!                 KTYPE=1 FOR deep cumulus
!                 KTYPE=2 FOR shallow cumulus
!***METHOD.
!  --------
!          based on a simplified updraught equation
!            partial(Hup)/partial(z)=eta(H - Hup)
!            eta is the entrainment rate for test parcel
!            H stands for dry static energy or the total water specific humidity
!            references: Christian Jakob, 2003: A new subcloud model for mass-flux convection schemes
!                        influence on triggering, updraft properties, and model climate, Mon.Wea.Rev.
!                        131, 2765-2778
!            and
!                        IFS Documentation - Cy33r1 
!          
!***EXTERNALS
!   ---------
!          *CUADJTQ* FOR ADJUSTING T AND Q DUE TO CONDENSATION IN ASCENT
! ----------------------------------------------------------------
!-------------------------------------------------------------------
      IMPLICIT NONE
!-------------------------------------------------------------------
      INTEGER   KLON, KLEV, KLEVP1
      INTEGER   klevm1
      INTEGER   JL,JK,IS,IK,ICALL,IKB,LEVELS
      REAL     PTENH(KLON,KLEV),       PQENH(KLON,KLEV), &
                                       PQSENH(KLON,KLEV),&
               PGEOH(KLON,KLEV),       PAPH(KLON,KLEVP1)
      REAL     ZRELH(KLON)
      REAL     QFX(KLON),RHO(KLON),HFX(KLON)
      REAL     ZQOLD(KLON,KLEV),       ZPH(KLON)
      INTEGER  KCTOP(KLON),KCBOT(KLON)
      INTEGER  KTYPE(KLON),LCLFLAG(KLON)
      LOGICAL  TOPFLAG(KLON),DEEPFLAG(KLON),MYFLAG(KLON)

      REAL     part1(klon), part2(klon), root(klon)
      REAL     conw(klon),deltT(klon),deltQ(klon)
      REAL     eta(klon),dz(klon),coef(klon)
      REAL     dhen(KLON,KLEV), dh(KLON,KLEV),qh(KLON,KLEV)
      REAL      Tup(KLON,KLEV),Qup(KLON,KLEV),ql(KLON,KLEV)
      REAL       ww(KLON,KLEV),Kup(KLON,KLEV)
      REAL     Vtup(KLON,KLEV),Vten(KLON,KLEV),buoy(KLON,KLEV)

      INTEGER  lndj(KLON)
      REAL     CRIRH1
!***INPUT VARIABLES:
!       PTENH [ZTENH] - Environment Temperature on half levels. (CUINI)
!       PQENH [ZQENH] - Env. specific humidity on half levels. (CUINI)
!       PGEOH [ZGEOH] - Geopotential on half levels, (MSSFLX)
!       PAPH - Pressure of half levels. (MSSFLX)
!       RHO  - Density of the lowest Model level
!       QFX  - net upward moisture flux at the surface (kg/m^2/s)
!       HFX  - net upward heat flux at the surface (W/m^2)
!***VARIABLES OUTPUT BY CUTYPE:
!       KTYPE - Convection type - 1: Penetrative  (CUMASTR)
!                                 2: Stratocumulus (CUMASTR)
!                                 3: Mid-level  (CUASC)
!--------------------------------------------------------------
      DO JL=1,KLON
        KCBOT(JL)=KLEVM1
        KCTOP(JL)=KLEVM1
        KTYPE(JL)=0
      END DO
!-----------------------------------------------------------
! let's do test,and check the shallow convection first
! the first level is JK+1
! define deltaT and deltaQ
!-----------------------------------------------------------
      DO JK=1,KLEV
      DO JL=1,KLON
        ZQOLD(JL,JK)=0.0
           ql(jl,jk)=0.0  ! parcel liquid water
          Tup(jl,jk)=0.0  ! parcel temperature
          Qup(jl,jk)=0.0  ! parcel specific humidity
           dh(jl,jk)=0.0  ! parcel dry static energy
           qh(jl,jk)=0.0  ! parcel total water specific humidity
           ww(jl,jk)=0.0  ! parcel vertical speed (m/s)
         dhen(jl,jk)=0.0  ! environment dry static energy
          Kup(jl,jk)=0.0  ! updraught kinetic energy for parcel
         Vtup(jl,jk)=0.0  ! parcel virtual temperature considering water-loading
         Vten(jl,jk)=0.0  ! environment virtual temperature
         buoy(jl,jk)=0.0  ! parcel buoyancy
      END DO
      END DO

      do jl=1,klon
         lclflag(jl) = 0  ! flag for the condensation level
         conw(jl)    = 0.0 ! convective-scale velocity,also used for the vertical speed at the first level
         myflag(jl)  = .true. ! just as input for cuadjqt subroutine
        topflag(jl)  = .false.! flag for whether the cloud top is found
      end do

! check the levels from lowest level to second top level
      do JK=KLEVM1,2,-1
        DO JL=1,KLON
          ZPH(JL)=PAPH(JL,JK)
        END DO

! define the variables at the first level      
      if(jk .eq. KLEVM1) then
      do jl=1,klon
        part1(jl) = 1.5*0.4*pgeoh(jl,jk+1)/(rho(jl)*ptenh(jl,jk+1))
        part2(jl) = hfx(jl)/cpd+0.61*ptenh(jl,jk+1)*qfx(jl)
        root(jl) = 0.001-part1(jl)*part2(jl)
        if(root(jl) .gt. 0) then
          conw(jl) = 1.2*(root(jl))**(1.0/3.0)
        else
          conw(jl) = -1.2*(-root(jl))**(1.0/3.0)
        end if
        deltT(jl) = -1.5*hfx(jl)/(rho(jl)*cpd*conw(jl))
        deltQ(jl) = -1.5*qfx(jl)/(rho(jl)*conw(jl))

        Tup(jl,jk+1) = ptenh(jl,jk+1) + deltT(jl)
        Qup(jl,jk+1) = pqenh(jl,jk+1) + deltQ(jl)
         ql(jl,jk+1) = 0.
         dh(jl,jk+1) = pgeoh(jl,jk+1) + Tup(jl,jk+1)*cpd
         qh(jl,jk+1) = pqenh(jl,jk+1) + deltQ(jl) + ql(jl,jk+1)
         ww(jl,jk+1) = conw(jl)
      end do
      end if

! the next levels, we use the variables at the first level as initial values
      do jl=1,klon
      if(.not. topflag(jl)) then
        eta(jl) = 0.5*(0.55/(pgeoh(jl,jk)*zrg)+1.0e-3)
        dz(jl)  = (pgeoh(jl,jk)-pgeoh(jl,jk+1))*zrg
        coef(jl)= eta(jl)*dz(jl)
        dhen(jl,jk) = pgeoh(jl,jk) + cpd*ptenh(jl,jk)
        dh(jl,jk) = (coef(jl)*dhen(jl,jk) + dh(jl,jk+1))/(1+coef(jl))
        qh(jl,jk) = (coef(jl)*pqenh(jl,jk)+ qh(jl,jk+1))/(1+coef(jl))
        Tup(jl,jk) = (dh(jl,jk)-pgeoh(jl,jk))*RCPD
        Qup(jl,jk) = qh(jl,jk) - ql(jl,jk+1)
        zqold(jl,jk) = Qup(jl,jk)
      end if
      end do
! check if the parcel is saturated
      ik=jk
      icall=1
      call CUADJTQ(klon,klev,ik,zph,Tup,Qup,myflag,icall)
      do jl=1,klon
        if( .not. topflag(jl) .and. zqold(jl,jk) .ne. Qup(jl,jk) ) then
          lclflag(jl) = lclflag(jl) + 1
          ql(jl,jk) = ql(jl,jk+1) + zqold(jl,jk) - Qup(jl,jk)
          dh(jl,jk) = pgeoh(jl,jk) + cpd*Tup(jl,jk)
        end if
      end do

! compute the updraft speed
      do jl=1,klon
        if(.not. topflag(jl))then
          Kup(jl,jk+1) = 0.5*ww(jl,jk+1)**2
          Vtup(jl,jk) = Tup(jl,jk)*(1.+VTMPC1*Qup(jl,jk)-ql(jl,jk))
          Vten(jl,jk) = ptenh(jl,jk)*(1.+VTMPC1*pqenh(jl,jk))
          buoy(jl,jk) = (Vtup(jl,jk) - Vten(jl,jk))/Vten(jl,jk)*g
          Kup(jl,jk)  = (Kup(jl,jk+1) + 0.333*dz(jl)*buoy(jl,jk))/ &
                        (1+2*2*eta(jl)*dz(jl))
          if(Kup(jl,jk) .gt. 0 ) then
             ww(jl,jk) = sqrt(2*Kup(jl,jk))
             if(lclflag(jl) .eq. 1 ) kcbot(jl) = jk
             if(jk .eq. 2) then
                kctop(jl) = jk
                topflag(jl)= .true.
             end if
          else
             ww(jl,jk) = 0
             kctop(jl) = jk + 1
             topflag(jl) = .true.
          end if
         end if
      end do
      end do ! end all the levels

      do jl=1,klon
        if(paph(jl,kcbot(jl)) - paph(jl,kctop(jl)) .lt. ZDNOPRC .and. &
          paph(jl,kcbot(jl)) - paph(jl,kctop(jl)) .gt. 0 &
           .and. lclflag(jl) .gt. 0) then
           ktype(jl) = 2
         end if
      end do

!-----------------------------------------------------------
! Next, let's check the deep convection
! the first level is JK
! define deltaT and deltaQ
!----------------------------------------------------------
! we check the parcel starting level by level (from the second lowest level to the next 12th level,
! usually, the 12th level around 700 hPa for common eta levels)
      do levels=KLEVM1-1,KLEVM1-12,-1
      DO JK=1,KLEV
      DO JL=1,KLON
        ZQOLD(JL,JK)=0.0
           ql(jl,jk)=0.0  ! parcel liquid water
          Tup(jl,jk)=0.0  ! parcel temperature
          Qup(jl,jk)=0.0  ! parcel specific humidity
           dh(jl,jk)=0.0  ! parcel dry static energy
           qh(jl,jk)=0.0  ! parcel total water specific humidity
           ww(jl,jk)=0.0  ! parcel vertical speed (m/s)
         dhen(jl,jk)=0.0  ! environment dry static energy
          Kup(jl,jk)=0.0  ! updraught kinetic energy for parcel
         Vtup(jl,jk)=0.0  ! parcel virtual temperature considering water-loading
         Vten(jl,jk)=0.0  ! environment virtual temperature
         buoy(jl,jk)=0.0  ! parcel buoyancy
      END DO
      END DO

      do jl=1,klon
         lclflag(jl) = 0  ! flag for the condensation level
         kctop(jl) = levels
         kcbot(jl) = levels
         myflag(jl)  = .true. ! just as input for cuadjqt subroutine
        topflag(jl)  = .false.! flag for whether the cloud top is found
      end do

! check the levels from lowest level to second top level
      do JK=levels,2,-1
        DO JL=1,KLON
          ZPH(JL)=PAPH(JL,JK)
        END DO

! define the variables at the first level      
      if(jk .eq. levels) then
      do jl=1,klon
        deltT(jl) = 0.2
        deltQ(jl) = 1.0e-4

        if(paph(jl,KLEVM1-1)-paph(jl,jk) .le. 6.e3) then
         ql(jl,jk+1) = 0.
        Tup(jl,jk+1) = 0.25*(ptenh(jl,jk+1)+ptenh(jl,jk)+ &
                             ptenh(jl,jk-1)+ptenh(jl,jk-2)) + &
                      deltT(jl)
        dh(jl,jk+1) = 0.25*(pgeoh(jl,jk+1)+pgeoh(jl,jk)+ &
                            pgeoh(jl,jk-1)+pgeoh(jl,jk-2)) + &
                      Tup(jl,jk+1)*cpd 
        qh(jl,jk+1) = 0.25*(pqenh(jl,jk+1)+pqenh(jl,jk)+ &
                            pqenh(jl,jk-1)+pqenh(jl,jk-2))+ &
                      deltQ(jl) + ql(jl,jk+1)
        Qup(jl,jk+1) = qh(jl,jk+1) - ql(jl,jk+1)
        else
         ql(jl,jk+1) = 0.
        Tup(jl,jk+1) = ptenh(jl,jk+1) + deltT(jl)
         dh(jl,jk+1) = pgeoh(jl,jk+1) + Tup(jl,jk+1)*cpd
         qh(jl,jk+1) = pqenh(jl,jk+1) + deltQ(jl)
        Qup(jl,jk+1) =    qh(jl,jk+1) - ql(jl,jk+1)
        end if
      ww(jl,jk+1) = 1.0

      end do
      end if

! the next levels, we use the variables at the first level as initial values
      do jl=1,klon
      if(.not. topflag(jl)) then
        eta(jl) = 1.1e-4
        dz(jl)  = (pgeoh(jl,jk)-pgeoh(jl,jk+1))*zrg
        coef(jl)= eta(jl)*dz(jl)
        dhen(jl,jk) = pgeoh(jl,jk) + cpd*ptenh(jl,jk)
        dh(jl,jk) = (coef(jl)*dhen(jl,jk) + dh(jl,jk+1))/(1+coef(jl))
        qh(jl,jk) = (coef(jl)*pqenh(jl,jk)+ qh(jl,jk+1))/(1+coef(jl))
        Tup(jl,jk) = (dh(jl,jk)-pgeoh(jl,jk))*RCPD
        Qup(jl,jk) = qh(jl,jk) - ql(jl,jk+1)
        zqold(jl,jk) = Qup(jl,jk)
      end if
      end do
! check if the parcel is saturated
      ik=jk
      icall=1
      call CUADJTQ(klon,klev,ik,zph,Tup,Qup,myflag,icall)
      do jl=1,klon
        if( .not. topflag(jl) .and. zqold(jl,jk) .ne. Qup(jl,jk) ) then
          lclflag(jl) = lclflag(jl) + 1
          ql(jl,jk) = ql(jl,jk+1) + zqold(jl,jk) - Qup(jl,jk)
          dh(jl,jk) = pgeoh(jl,jk) + cpd*Tup(jl,jk)
        end if
      end do

! compute the updraft speed
      do jl=1,klon
        if(.not. topflag(jl))then
          Kup(jl,jk+1) = 0.5*ww(jl,jk+1)**2
          Vtup(jl,jk) = Tup(jl,jk)*(1.+VTMPC1*Qup(jl,jk)-ql(jl,jk))
          Vten(jl,jk) = ptenh(jl,jk)*(1.+VTMPC1*pqenh(jl,jk))
          buoy(jl,jk) = (Vtup(jl,jk) - Vten(jl,jk))/Vten(jl,jk)*g
          Kup(jl,jk)  = (Kup(jl,jk+1) + 0.333*dz(jl)*buoy(jl,jk))/ &
                        (1+2*2*eta(jl)*dz(jl))
          if(Kup(jl,jk) .gt. 0 ) then
             ww(jl,jk) = sqrt(2*Kup(jl,jk))
             if(lclflag(jl) .eq. 1 ) kcbot(jl) = jk
             if(jk .eq. 2) then
                kctop(jl) = jk
                topflag(jl)= .true.
             end if
          else
             ww(jl,jk) = 0
             kctop(jl) = jk + 1
             topflag(jl) = .true.
          end if
         end if
      end do
      end do ! end all the levels

      do jl = 1, klon
       if(paph(jl,kcbot(jl)) - paph(jl,kctop(jl)) .gt. ZDNOPRC .and. &
              lclflag(jl) .gt. 0 ) then
         ZRELH(JL) = 0.
         do jk=kcbot(jl),kctop(jl),-1
           ZRELH(JL)=ZRELH(JL)+ PQENH(JL,JK)/PQSENH(JL,JK)
         end do
         ZRELH(JL) = ZRELH(JL)/(kcbot(jl)-kctop(jl)+1)

         if(lndj(JL) .eq. 1) then
           CRIRH1 = CRIRH*0.8
         else
           CRIRH1 = CRIRH
         end if
         if(ZRELH(JL) .ge. CRIRH1) ktype(jl)  = 1
       end if
      end do

       end do ! end all cycles

      END SUBROUTINE CUTYPE

      REAL FUNCTION TLUCUA(TT)
!
!  Set up lookup tables for cloud ascent calculations.
!
      IMPLICIT NONE
      REAL ZCVM3,ZCVM4,TT
!
      IF(TT-TMELT.GT.0.) THEN
         ZCVM3=C3LES
         ZCVM4=C4LES
      ELSE
         ZCVM3=C3IES
         ZCVM4=C4IES
      END IF
      TLUCUA=C2ES*EXP(ZCVM3*(TT-TMELT)*(1./(TT-ZCVM4)))
!
      RETURN
      END FUNCTION TLUCUA


END MODULE module_cu_tiedtke
