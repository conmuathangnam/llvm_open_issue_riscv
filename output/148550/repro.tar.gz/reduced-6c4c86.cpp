# 1 "<built-in>"
# 1 "reduced.cpp"
typedef long unsigned int size_t;

namespace std {
struct nothrow_t {
  explicit nothrow_t() = default;
};
extern const nothrow_t nothrow;
}

void* operator new(size_t size, const std::nothrow_t&) noexcept {
  void* p = nullptr;
  try {
    p = ::operator new(size);
  } catch (...) {
  }
  return p;
}
