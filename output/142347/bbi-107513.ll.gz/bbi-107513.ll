define i16 @foo() {
entry:
  %sub = sub i16 0, -1
  %cmp = icmp eq i16 %sub, 1

  %sub1 = sub i16 0, -1
  %cmp2 = icmp eq i16 %sub1, 1
  %cond3 = select i1 %cmp2, i16 1, i16 0

  %sub5 = sub nsw i16 0, 0
  %cmp6 = icmp eq i16 %sub5, 0
  %cmp9 = icmp eq i16 %sub5, 0

  %sub12 = sub nsw i16 0, 0
  %cmp13 = icmp eq i16 %sub12, 0

  %sub16 = sub nsw i16 0, 0
  %cmp17 = icmp eq i16 %sub16, 0

  %sub20 = sub nsw i16 0, 0
  %cmp21 = icmp eq i16 %sub20, 0
  %cmp24 = icmp eq i16 %sub20, 0

  ret i16 %cond3
}

