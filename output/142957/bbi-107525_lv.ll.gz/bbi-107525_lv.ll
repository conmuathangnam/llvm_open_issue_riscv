@g_855 = global [16 x i64] zeroinitializer
@g_857 = global [16 x i64] zeroinitializer
@g_988 = global i16 16320

define i16 @main() {
entry:
  %shl = load i16, ptr @g_988                         ; 16320
  br label %for.body

for.body:                                         ; preds = %entry, %for.inc
  %il_395 = phi i16 [ 9, %entry ], [ %inc, %for.inc ] ; 9 10
  %cmp1 = icmp eq i16 %il_395, 10                     ; 0  1
  br i1 %cmp1, label %if.then, label %for.inc

if.then:                                          ; preds = %for.body
  %div3 = sdiv i16 24316, %shl                        ; 1
  %reass.sub = add i16 %il_395, 16383                 ; 10 + 16383 -> 16393
  %0 = shl i16 %div3, 14                              ; 1 << 14 -> 16384
  %sub6 = sub i16 %reass.sub, %0                      ; 16393 - 16384 = 9
  %arrayidx = getelementptr inbounds [16 x i64], ptr @g_855, i16 0, i16 %sub6
  %1 = load i64, ptr %arrayidx, align 1
  %arrayidx8 = getelementptr inbounds [16 x i64], ptr @g_857, i16 0, i16 %il_395
  store i64 %1, ptr %arrayidx8, align 1
  br label %for.inc

for.inc:                                          ; preds = %for.body, %if.then
  %inc = add i16 %il_395, 1                           ; 10 11
  %exitcond.not = icmp eq i16 %inc, 11                ; 0 1
  br i1 %exitcond.not, label %for.cond.cleanup, label %for.body, !llvm.loop !5

for.cond.cleanup:                                 ; preds = %for.inc
  ret i16 0
}

!0 = distinct !{!0, !1, !2, !3, !4}
!1 = !{!"llvm.loop.mustprogress"}
!2 = !{!"llvm.loop.unroll.disable"}
!3 = !{!"llvm.loop.vectorize.width", i32 2}
!4 = !{!"llvm.loop.vectorize.enable", i1 true}
!5 = distinct !{!5, !1, !2, !4, !3}

