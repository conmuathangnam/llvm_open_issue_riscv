; ModuleID = './reduced.ll'
source_filename = "./reduced.ll"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128-ni:1-p2:32:8:8:32-ni:2"
target triple = "x86_64-unknown-linux-gnu"

define void @wombat(ptr addrspace(1) %arg) #0 gc "statepoint-example" {
bb:
  %call = call i32 @llvm.ctpop.i32(i32 0)
  %call1 = call i32 @llvm.ctpop.i32(i32 0)
  %or = or i32 %call, %call1
  %call2 = call i32 @llvm.ctpop.i32(i32 0)
  %or3 = or i32 %or, %call2
  %call4 = call i32 @llvm.ctpop.i32(i32 0)
  %load = load i32, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 32), align 4
  store i32 %load, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 32), align 4
  %or5 = or i32 %or3, %call4
  %call6 = call i32 @llvm.ctpop.i32(i32 0)
  %or7 = or i32 %or5, %call6
  %call8 = call i32 @llvm.ctpop.i32(i32 0)
  %load9 = load i32, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 28), align 4
  store i32 %load9, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 28), align 4
  %or10 = or i32 %or7, %call8
  %call11 = call i32 @llvm.ctpop.i32(i32 %load)
  %or12 = or i32 %or10, %call11
  %call13 = call i32 @llvm.ctpop.i32(i32 0)
  %load14 = load i32, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 28), align 4
  store i32 %load14, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 28), align 4
  %load15 = load i32, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 24), align 4
  store i32 %load15, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 24), align 4
  %or16 = or i32 %or12, %call13
  %call17 = call i32 @llvm.ctpop.i32(i32 %load9)
  %or18 = or i32 %or16, %call17
  %call19 = call i32 @llvm.ctpop.i32(i32 %load14)
  %load20 = load i32, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 24), align 4
  store i32 %load20, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 24), align 4
  %load21 = load i32, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 20), align 4
  store i32 %load21, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 20), align 4
  %or22 = or i32 %or18, %call19
  %call23 = call i32 @llvm.ctpop.i32(i32 %load15)
  %or24 = or i32 %or22, %call23
  %call25 = call i32 @llvm.ctpop.i32(i32 %load20)
  %load26 = load i32, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 20), align 4
  store i32 %load26, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 20), align 4
  %load27 = load i32, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 16), align 4
  store i32 %load27, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 16), align 4
  %or28 = or i32 %or24, %call25
  %call29 = call i32 @llvm.ctpop.i32(i32 %load21)
  %or30 = or i32 %or28, %call29
  %call31 = call i32 @llvm.ctpop.i32(i32 %load26)
  %load32 = load i32, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 16), align 4
  store i32 %load32, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 16), align 4
  %load33 = load i32, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 12), align 4
  store i32 %load33, ptr addrspace(1) getelementptr inbounds nuw (i8, ptr addrspace(1) null, i64 12), align 4
  %or34 = or i32 %or30, %call31
  %call35 = call i32 @llvm.ctpop.i32(i32 %load27)
  %or36 = or i32 %or34, %call35
  %call37 = call i32 @llvm.ctpop.i32(i32 %load32)
  %or38 = or i32 %or36, %call37
  %call39 = call i32 @llvm.ctpop.i32(i32 %load33)
  %or40 = or i32 %or38, %call39
  %call41 = call i32 @llvm.ctpop.i32(i32 0)
  %or42 = or i32 %or40, %call41
  %call43 = call i32 @llvm.ctpop.i32(i32 0)
  %or44 = or i32 %or42, %call43
  %call45 = call i32 @llvm.ctpop.i32(i32 0)
  %or46 = or i32 %or44, %call45
  %call47 = call i32 @llvm.ctpop.i32(i32 0)
  %or48 = or i32 %or46, %call47
  %call49 = call i32 @llvm.ctpop.i32(i32 0)
  %or50 = or i32 %or48, %call49
  %call51 = call i32 @llvm.ctpop.i32(i32 0)
  %or52 = or i32 %or50, %call51
  %call53 = call i32 @llvm.ctpop.i32(i32 0)
  %or54 = or i32 %or52, %call53
  store i32 %or54, ptr addrspace(1) %arg, align 4
  ret void
}

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctpop.i32(i32) #1

attributes #0 = { "target-features"="+prfchw,-cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,-avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,-avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,-invpcid,+64bit,+xsavec,-avx512vpopcntdq,+cmov,-avx512vp2intersect,-avx512cd,+movbe,-avxvnniint8,-ccmp,-amx-int8,-kl,-sha512,-avxvnni,-rtm,+adx,+avx2,-hreset,-movdiri,-serialize,-vpclmulqdq,-avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,-amx-tile,+sse,-gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,-avx512f,-amx-bf16,-avx512bf16,-avx512vnni,-push2pop2,+cx8,-avx512bw,+sse3,-pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,+clzero,-mwaitx,-lwp,+lzcnt,+sha,-movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,-avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,-avx512vbmi2,-prefetchi,-amx-movrs,+rdpid,-fma4,-avx512vbmi,-shstk,-vaes,-waitpkg,-sgx,+fxsr,-avx512dq,+sse4a" }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) "target-features"="+prfchw,-cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,-avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,-avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,-invpcid,+64bit,+xsavec,-avx512vpopcntdq,+cmov,-avx512vp2intersect,-avx512cd,+movbe,-avxvnniint8,-ccmp,-amx-int8,-kl,-sha512,-avxvnni,-rtm,+adx,+avx2,-hreset,-movdiri,-serialize,-vpclmulqdq,-avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,-amx-tile,+sse,-gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,-avx512f,-amx-bf16,-avx512bf16,-avx512vnni,-push2pop2,+cx8,-avx512bw,+sse3,-pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,+clzero,-mwaitx,-lwp,+lzcnt,+sha,-movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,-avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,-avx512vbmi2,-prefetchi,-amx-movrs,+rdpid,-fma4,-avx512vbmi,-shstk,-vaes,-waitpkg,-sgx,+fxsr,-avx512dq,+sse4a" }
