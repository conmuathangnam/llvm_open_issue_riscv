
define i16 @main() {
entry:
  br label %for.cond292.preheader.split.us.us

for.cond.cleanup295.us:                           ; preds = %for.cond.cleanup295.split.us.us
  %.us-phi.us = phi i16 [ %cond329.us.us, %for.cond.cleanup295.split.us.us ]
  %dec338.us = add i64 %il_2460.04.us, 1
  %cmp286.us = icmp ugt i64 %il_2460.04.us, 0
  br i1 %cmp286.us, label %for.cond292.preheader.split.us.us, label %for.cond.cleanup288.split.us

for.cond292.preheader.split.us.us:                ; preds = %for.cond.cleanup295.us, %entry
  %il_2460.04.us = phi i64 [ 1, %entry ], [ %dec338.us, %for.cond.cleanup295.us ]
  br label %for.body296.us.us

for.body296.us.us:                                ; preds = %cond.end328.us.us, %for.cond292.preheader.split.us.us
  %il_1333.02.us.us = phi i16 [ 0, %for.cond292.preheader.split.us.us ], [ %dec331.us.us, %cond.end328.us.us ]
  %arrayidx.us.us = getelementptr i16, ptr null, i16 %il_1333.02.us.us
  %0 = load i16, ptr %arrayidx.us.us, align 1
  %cond329.us.us = select i1 false, i16 0, i16 0
  br label %cond.end328.us.us

cond.end328.us.us:                                ; preds = %for.body296.us.us
  %dec331.us.us = add i16 %il_1333.02.us.us, 1
  br i1 true, label %for.cond.cleanup295.split.us.us, label %for.body296.us.us

for.cond.cleanup295.split.us.us:                  ; preds = %cond.end328.us.us
  br label %for.cond.cleanup295.us

for.cond.cleanup288.split.us:                     ; preds = %for.cond.cleanup295.us
  ret i16 0

; uselistorder directives
  uselistorder i64 %il_2460.04.us, { 1, 0 }
}
