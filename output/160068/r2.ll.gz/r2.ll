@g_2350 = dso_local global i16 0, align 1
@g_2469 = dso_local global [15 x i16] zeroinitializer, align 1
@g_2391 = dso_local global i16 0, align 1

define dso_local i16 @main() {
entry:
  %0 = load i16, ptr @g_2350, align 1
  %cmp5 = icmp sgt i16 %0, 0
  %cmp7 = icmp slt i16 %0, 0
  br label %for.cond1.preheader

for.cond1.preheader:                              ; preds = %entry, %for.inc15
  %il_2460.019 = phi i16 [ 30, %entry ], [ %dec16, %for.inc15 ]
  br label %for.body4

for.body4:                                        ; preds = %for.cond1.preheader, %for.inc
  %il_1333.017 = phi i16 [ 5, %for.cond1.preheader ], [ %dec, %for.inc ]
  %arrayidx = getelementptr inbounds nuw i16, ptr @g_2469, i16 %il_1333.017
  %1 = load i16, ptr %arrayidx, align 1
  br i1 %cmp5, label %land.lhs.true, label %lor.lhs.false

land.lhs.true:                                    ; preds = %for.body4
  %add = add nsw i16 %1, 32767
  %cmp6 = icmp sgt i16 %0, %add
  br i1 %cmp6, label %for.inc, label %cond.false

lor.lhs.false:                                    ; preds = %for.body4
  br i1 %cmp7, label %land.lhs.true8, label %lor.lhs.false13

land.lhs.true8:                                   ; preds = %lor.lhs.false
  %cmp9 = icmp sgt i16 %1, 0
  br i1 %cmp9, label %land.lhs.true10, label %cond.false

land.lhs.true10:                                  ; preds = %land.lhs.true8
  %add11 = or disjoint i16 %1, -32768
  %cmp12 = icmp samesign ult i16 %0, %add11
  %cmp14.old = icmp eq i16 %1, 1
  %or.cond14 = or i1 %cmp14.old, %cmp12
  br i1 %or.cond14, label %for.inc, label %cond.false

lor.lhs.false13:                                  ; preds = %lor.lhs.false
  %cmp14.old.old = icmp eq i16 %1, 1
  br i1 %cmp14.old.old, label %for.inc, label %cond.false

cond.false:                                       ; preds = %land.lhs.true10, %land.lhs.true, %land.lhs.true8, %lor.lhs.false13
  %sub = sub nsw i16 %0, %1
  br label %for.inc

for.inc:                                          ; preds = %cond.false, %lor.lhs.false13, %land.lhs.true10, %land.lhs.true
  %cond = phi i16 [ %sub, %cond.false ], [ 0, %lor.lhs.false13 ], [ 0, %land.lhs.true10 ], [ 0, %land.lhs.true ]
  %dec = add nsw i16 %il_1333.017, -1
  %cmp2.not = icmp eq i16 %il_1333.017, 0
  br i1 %cmp2.not, label %for.inc15, label %for.body4

for.inc15:                                        ; preds = %for.inc
  %dec16 = add nsw i16 %il_2460.019, -1
  %cmp = icmp samesign ugt i16 %il_2460.019, 26
  br i1 %cmp, label %for.cond1.preheader, label %for.end17

for.end17:                                        ; preds = %for.inc15
  store i16 %cond, ptr @g_2391, align 1
  ret i16 0
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #0

attributes #0 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
