#include <stdint.h>

int g_2350;
int g_2391;
int g_2469[15];

int main(void)
{
    for (int il_2460 = 30; il_2460 >= 26; --il_2460)
    {
        for (int il_1333 = 5; il_1333 >= 0; --il_1333)
        {
          int y1 = g_2350;
          int y2 = g_2469[il_1333];
          g_2391 = (((y1 > 0) && (y1 > INT16_MAX + y2)) ||
                    ((y1 < 0) && (y2 > 0) && (y1 < INT16_MIN + y2)) ||
                    (y2 == 1)) ? 0 : y1 - y2;
        }
    }

    return 0;
}
