@g_2350 = dso_local global i16 0, align 1
@g_2469 = dso_local global [15 x i16] zeroinitializer, align 1
@g_2391 = dso_local global i16 0, align 1

define dso_local i16 @main() {
entry:
  %retval = alloca i16, align 1
  %il_2460 = alloca i16, align 1
  %cleanup.dest.slot = alloca i32, align 1
  %il_1333 = alloca i16, align 1
  %y1 = alloca i16, align 1
  %y2 = alloca i16, align 1
  store i16 0, ptr %retval, align 1
  call void @llvm.lifetime.start.p0(ptr %il_2460)
  store i16 30, ptr %il_2460, align 1
  br label %for.cond

for.cond:                                         ; preds = %for.inc15, %entry
  %0 = load i16, ptr %il_2460, align 1
  %cmp = icmp sge i16 %0, 26
  br i1 %cmp, label %for.body, label %for.cond.cleanup

for.cond.cleanup:                                 ; preds = %for.cond
  store i32 2, ptr %cleanup.dest.slot, align 1
  call void @llvm.lifetime.end.p0(ptr %il_2460)
  br label %for.end17

for.body:                                         ; preds = %for.cond
  call void @llvm.lifetime.start.p0(ptr %il_1333)
  store i16 5, ptr %il_1333, align 1
  br label %for.cond1

for.cond1:                                        ; preds = %for.inc, %for.body
  %1 = load i16, ptr %il_1333, align 1
  %cmp2 = icmp sge i16 %1, 0
  br i1 %cmp2, label %for.body4, label %for.cond.cleanup3

for.cond.cleanup3:                                ; preds = %for.cond1
  store i32 5, ptr %cleanup.dest.slot, align 1
  call void @llvm.lifetime.end.p0(ptr %il_1333)
  br label %for.end

for.body4:                                        ; preds = %for.cond1
  call void @llvm.lifetime.start.p0(ptr %y1)
  %2 = load i16, ptr @g_2350, align 1
  store i16 %2, ptr %y1, align 1
  call void @llvm.lifetime.start.p0(ptr %y2)
  %3 = load i16, ptr %il_1333, align 1
  %idxprom = sext i16 %3 to i32
  %arrayidx = getelementptr inbounds [15 x i16], ptr @g_2469, i32 0, i32 %idxprom
  %4 = load i16, ptr %arrayidx, align 1
  store i16 %4, ptr %y2, align 1
  %5 = load i16, ptr %y1, align 1
  %cmp5 = icmp sgt i16 %5, 0
  br i1 %cmp5, label %land.lhs.true, label %lor.lhs.false

land.lhs.true:                                    ; preds = %for.body4
  %6 = load i16, ptr %y1, align 1
  %7 = load i16, ptr %y2, align 1
  %add = add nsw i16 32767, %7
  %cmp6 = icmp sgt i16 %6, %add
  br i1 %cmp6, label %cond.true, label %lor.lhs.false

lor.lhs.false:                                    ; preds = %land.lhs.true, %for.body4
  %8 = load i16, ptr %y1, align 1
  %cmp7 = icmp slt i16 %8, 0
  br i1 %cmp7, label %land.lhs.true8, label %lor.lhs.false13

land.lhs.true8:                                   ; preds = %lor.lhs.false
  %9 = load i16, ptr %y2, align 1
  %cmp9 = icmp sgt i16 %9, 0
  br i1 %cmp9, label %land.lhs.true10, label %lor.lhs.false13

land.lhs.true10:                                  ; preds = %land.lhs.true8
  %10 = load i16, ptr %y1, align 1
  %11 = load i16, ptr %y2, align 1
  %add11 = add nsw i16 -32768, %11
  %cmp12 = icmp slt i16 %10, %add11
  br i1 %cmp12, label %cond.true, label %lor.lhs.false13

lor.lhs.false13:                                  ; preds = %land.lhs.true10, %land.lhs.true8, %lor.lhs.false
  %12 = load i16, ptr %y2, align 1
  %cmp14 = icmp eq i16 %12, 1
  br i1 %cmp14, label %cond.true, label %cond.false

cond.true:                                        ; preds = %lor.lhs.false13, %land.lhs.true10, %land.lhs.true
  br label %cond.end

cond.false:                                       ; preds = %lor.lhs.false13
  %13 = load i16, ptr %y1, align 1
  %14 = load i16, ptr %y2, align 1
  %sub = sub nsw i16 %13, %14
  br label %cond.end

cond.end:                                         ; preds = %cond.false, %cond.true
  %cond = phi i16 [ 0, %cond.true ], [ %sub, %cond.false ]
  store i16 %cond, ptr @g_2391, align 1
  call void @llvm.lifetime.end.p0(ptr %y2)
  call void @llvm.lifetime.end.p0(ptr %y1)
  br label %for.inc

for.inc:                                          ; preds = %cond.end
  %15 = load i16, ptr %il_1333, align 1
  %dec = add nsw i16 %15, -1
  store i16 %dec, ptr %il_1333, align 1
  br label %for.cond1

for.end:                                          ; preds = %for.cond.cleanup3
  br label %for.inc15

for.inc15:                                        ; preds = %for.end
  %16 = load i16, ptr %il_2460, align 1
  %dec16 = add nsw i16 %16, -1
  store i16 %dec16, ptr %il_2460, align 1
  br label %for.cond

for.end17:                                        ; preds = %for.cond.cleanup
  ret i16 0
}


