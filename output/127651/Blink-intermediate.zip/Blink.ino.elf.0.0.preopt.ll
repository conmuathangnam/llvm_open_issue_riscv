; ModuleID = 'Blink.ino.elf.0.0.preopt.bc'
source_filename = "ld-temp.o"
target datalayout = "e-P1-p:16:8-i8:8-i16:8-i32:8-i64:8-f32:8-f64:8-n8-a:8"
target triple = "avr"

@llvm.compiler.used = appending global [1 x ptr] [ptr addrspacecast (ptr addrspace(1) @__vector_23 to ptr)], section "llvm.metadata"
@timer0_overflow_count = dso_local global i32 0, align 1, !dbg !0
@timer0_millis = dso_local global i32 0, align 1, !dbg !13
@timer0_fract = internal unnamed_addr global i8 0, align 1, !dbg !18
@port_to_mode_PGM = dso_local constant [13 x i16] [i16 0, i16 33, i16 36, i16 39, i16 42, i16 45, i16 48, i16 51, i16 257, i16 0, i16 260, i16 263, i16 266], section ".progmem1.data", align 1, !dbg !20
@port_to_output_PGM = dso_local constant [13 x i16] [i16 0, i16 34, i16 37, i16 40, i16 43, i16 46, i16 49, i16 52, i16 258, i16 0, i16 261, i16 264, i16 267], section ".progmem1.data", align 1, !dbg !26
@digital_pin_to_port_PGM = dso_local constant [70 x i8] c"\05\05\05\05\07\05\08\08\08\08\02\02\02\02\0A\0A\08\08\04\04\04\04\01\01\01\01\01\01\01\01\03\03\03\03\03\03\03\03\04\07\07\07\0C\0C\0C\0C\0C\0C\0C\0C\02\02\02\02\06\06\06\06\06\06\06\06\0B\0B\0B\0B\0B\0B\0B\0B", section ".progmem1.data", align 1, !dbg !35
@digital_pin_to_bit_mask_PGM = dso_local constant [70 x i8] c"\01\02\10  \08\08\10 @\10 @\80\02\01\02\01\08\04\02\01\01\02\04\08\10 @\80\80@ \10\08\04\02\01\80\04\02\01\80@ \10\08\04\02\01\08\04\02\01\01\02\04\08\10 @\80\01\02\04\08\10 @\80", section ".progmem1.data", align 1, !dbg !41
@digital_pin_to_timer_PGM = dso_local constant <{ [47 x i8], [23 x i8] }> <{ [47 x i8] c"\00\00\0A\0B\02\09\0C\0D\0E\08\07\03\04\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\12\11\10", [23 x i8] zeroinitializer }>, section ".progmem1.data", align 1, !dbg !43

@yield = weak dso_local alias void (), ptr addrspace(1) @__empty

; Function Attrs: mustprogress nounwind optsize
define dso_local void @setup() local_unnamed_addr addrspace(1) #0 !dbg !90 {
entry:
  tail call addrspace(1) void @pinMode(i8 noundef zeroext 13, i8 noundef zeroext 1) #6, !dbg !94
  ret void, !dbg !95
}

; Function Attrs: mustprogress nounwind optsize
define dso_local void @loop() local_unnamed_addr addrspace(1) #0 !dbg !96 {
entry:
  tail call addrspace(1) void @digitalWrite(i8 noundef zeroext 13, i8 noundef zeroext 1) #6, !dbg !97
  tail call addrspace(1) void @delay(i32 noundef 1000) #6, !dbg !98
  tail call addrspace(1) void @digitalWrite(i8 noundef zeroext 13, i8 noundef zeroext 0) #6, !dbg !99
  tail call addrspace(1) void @delay(i32 noundef 1000) #6, !dbg !100
  ret void, !dbg !101
}

; Function Attrs: mustprogress nounwind optsize
define weak dso_local void @initVariant() local_unnamed_addr addrspace(1) #0 !dbg !102 {
entry:
  ret void, !dbg !104
}

; Function Attrs: mustprogress norecurse noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr addrspace(1) #1 !dbg !105 {
entry:
  tail call addrspace(1) void @init() #6, !dbg !109
  tail call addrspace(1) void @initVariant() #7, !dbg !110
  tail call addrspace(1) void @setup() #6, !dbg !111
  br label %for.cond, !dbg !112

for.cond:                                         ; preds = %for.cond, %entry
  tail call addrspace(1) void @loop() #6, !dbg !113
  tail call addrspace(1) void @_Z14serialEventRunv() #6, !dbg !117
  br label %for.cond, !dbg !119, !llvm.loop !120
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, argmem: none)
define dso_local void @__vector_23() addrspace(1) #2 !dbg !124 {
entry:
  %0 = load volatile i32, ptr @timer0_millis, align 1, !dbg !128, !tbaa !129
    #dbg_value(i32 %0, !126, !DIExpression(), !133)
  %1 = load i8, ptr @timer0_fract, align 1, !dbg !134, !tbaa !135
    #dbg_value(i8 %1, !127, !DIExpression(), !133)
    #dbg_value(i32 %0, !126, !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value), !133)
  %add1 = add i8 %1, 3, !dbg !136
    #dbg_value(i8 %add1, !127, !DIExpression(), !133)
  %cmp = icmp ugt i8 %add1, 124, !dbg !137
  %sub = add i8 %1, -122, !dbg !137
  %m.0.v = select i1 %cmp, i32 2, i32 1, !dbg !137
  %m.0 = add i32 %m.0.v, %0, !dbg !137
  %f.0 = select i1 %cmp, i8 %sub, i8 %add1, !dbg !137
    #dbg_value(i8 %f.0, !127, !DIExpression(), !133)
    #dbg_value(i32 %m.0, !126, !DIExpression(), !133)
  store i8 %f.0, ptr @timer0_fract, align 1, !dbg !139, !tbaa !135
  store volatile i32 %m.0, ptr @timer0_millis, align 1, !dbg !140, !tbaa !129
  %2 = load volatile i32, ptr @timer0_overflow_count, align 1, !dbg !141, !tbaa !129
  %inc = add i32 %2, 1, !dbg !141
  store volatile i32 %inc, ptr @timer0_overflow_count, align 1, !dbg !141, !tbaa !129
  ret void, !dbg !142
}

; Function Attrs: nounwind optsize
define dso_local void @delay(i32 noundef %ms) local_unnamed_addr addrspace(1) #3 !dbg !143 {
entry:
    #dbg_value(i32 %ms, !147, !DIExpression(), !150)
  %0 = load volatile i8, ptr inttoptr (i16 95 to ptr), align 1, !dbg !151, !tbaa !135
    #dbg_value(i8 %0, !157, !DIExpression(), !160)
  tail call addrspace(0) void asm sideeffect "cli", "~{memory}"() #8, !dbg !161, !srcloc !162
  %1 = load volatile i32, ptr @timer0_overflow_count, align 1, !dbg !163, !tbaa !129
    #dbg_value(i32 %1, !156, !DIExpression(), !160)
  %2 = load volatile i8, ptr inttoptr (i16 70 to ptr), align 2, !dbg !164, !tbaa !135
    #dbg_value(i8 %2, !158, !DIExpression(), !160)
  %3 = load volatile i8, ptr inttoptr (i16 53 to ptr), align 1, !dbg !165, !tbaa !135
    #dbg_value(!DIArgList(i32 poison, i1 poison), !156, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_plus, DW_OP_stack_value), !160)
  store volatile i8 %0, ptr inttoptr (i16 95 to ptr), align 1, !dbg !167, !tbaa !135
    #dbg_value(!DIArgList(i32 poison, i8 poison, i1 poison), !148, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_plus, DW_OP_constu, 10, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_or, DW_OP_stack_value), !150)
  %cmp.not19 = icmp eq i32 %ms, 0, !dbg !168
  br i1 %cmp.not19, label %while.end6, label %while.body.preheader, !dbg !169

while.body.preheader:                             ; preds = %entry
  %4 = and i8 %3, 1, !dbg !170
  %tobool.not.i = icmp ne i8 %4, 0, !dbg !170
  %cmp.not.i = icmp ne i8 %2, -1
  %or.cond.not.i = select i1 %tobool.not.i, i1 %cmp.not.i, i1 false, !dbg !171
    #dbg_value(!DIArgList(i32 %1, i1 %or.cond.not.i), !156, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_plus, DW_OP_stack_value), !160)
    #dbg_value(!DIArgList(i32 %1, i8 %2, i1 %or.cond.not.i), !148, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_plus, DW_OP_constu, 10, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_or, DW_OP_stack_value), !150)
  %inc.i = zext i1 %or.cond.not.i to i32, !dbg !171
    #dbg_value(!DIArgList(i32 %1, i32 %inc.i), !156, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value), !160)
    #dbg_value(!DIArgList(i32 %1, i8 %2, i32 %inc.i), !148, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 2, DW_OP_plus, DW_OP_constu, 10, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_or, DW_OP_stack_value), !150)
  %m.0.i = add i32 %1, %inc.i, !dbg !171
    #dbg_value(i32 %m.0.i, !156, !DIExpression(), !160)
    #dbg_value(!DIArgList(i32 %m.0.i, i8 %2), !148, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 10, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_or, DW_OP_stack_value), !150)
  %5 = shl i32 %m.0.i, 10, !dbg !172
    #dbg_value(!DIArgList(i32 %5, i8 %2), !148, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_or, DW_OP_stack_value), !150)
  %conv3.i = zext i8 %2 to i32, !dbg !173
    #dbg_value(!DIArgList(i32 %5, i32 %conv3.i), !148, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 2, DW_OP_shl, DW_OP_or, DW_OP_stack_value), !150)
  %6 = shl nuw nsw i32 %conv3.i, 2, !dbg !172
    #dbg_value(!DIArgList(i32 %5, i32 %6), !148, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value), !150)
  %mul.i = or disjoint i32 %5, %6, !dbg !172
    #dbg_value(i32 %mul.i, !148, !DIExpression(), !150)
  br label %while.body, !dbg !169

while.body:                                       ; preds = %land.rhs, %while.body.preheader
  %start.021 = phi i32 [ %mul.i, %while.body.preheader ], [ %start.118, %land.rhs ]
  %ms.addr.020 = phi i32 [ %ms, %while.body.preheader ], [ %ms.addr.117, %land.rhs ]
    #dbg_value(i32 %start.021, !148, !DIExpression(), !150)
    #dbg_value(i32 %ms.addr.020, !147, !DIExpression(), !150)
  tail call addrspace(1) void @yield() #6, !dbg !174
  br label %land.rhs, !dbg !176

land.rhs:                                         ; preds = %while.body5, %while.body
  %start.118 = phi i32 [ %start.021, %while.body ], [ %add, %while.body5 ]
  %ms.addr.117 = phi i32 [ %ms.addr.020, %while.body ], [ %dec, %while.body5 ]
    #dbg_value(i32 %start.118, !148, !DIExpression(), !150)
    #dbg_value(i32 %ms.addr.117, !147, !DIExpression(), !150)
  %7 = load volatile i8, ptr inttoptr (i16 95 to ptr), align 1, !dbg !177, !tbaa !135
    #dbg_value(i8 %7, !157, !DIExpression(), !179)
  tail call addrspace(0) void asm sideeffect "cli", "~{memory}"() #8, !dbg !180, !srcloc !162
  %8 = load volatile i32, ptr @timer0_overflow_count, align 1, !dbg !181, !tbaa !129
    #dbg_value(i32 %8, !156, !DIExpression(), !179)
  %9 = load volatile i8, ptr inttoptr (i16 70 to ptr), align 2, !dbg !182, !tbaa !135
    #dbg_value(i8 %9, !158, !DIExpression(), !179)
  %10 = load volatile i8, ptr inttoptr (i16 53 to ptr), align 1, !dbg !183, !tbaa !135
  %11 = and i8 %10, 1, !dbg !184
  %tobool.not.i10 = icmp ne i8 %11, 0, !dbg !184
  %cmp.not.i11 = icmp ne i8 %9, -1
  %or.cond.not.i12 = select i1 %tobool.not.i10, i1 %cmp.not.i11, i1 false, !dbg !185
  %inc.i13 = zext i1 %or.cond.not.i12 to i32, !dbg !185
  %m.0.i14 = add i32 %8, %inc.i13, !dbg !185
    #dbg_value(i32 %m.0.i14, !156, !DIExpression(), !179)
  store volatile i8 %7, ptr inttoptr (i16 95 to ptr), align 1, !dbg !186, !tbaa !135
  %conv3.i15 = zext i8 %9 to i32, !dbg !187
  %12 = shl i32 %m.0.i14, 10, !dbg !188
  %13 = shl nuw nsw i32 %conv3.i15, 2, !dbg !188
  %mul.i16 = sub i32 %13, %start.118, !dbg !188
  %sub = add i32 %mul.i16, %12, !dbg !189
  %cmp4 = icmp ugt i32 %sub, 999, !dbg !190
  br i1 %cmp4, label %while.body5, label %while.body, !dbg !191, !llvm.loop !192

while.body5:                                      ; preds = %land.rhs
  %dec = add i32 %ms.addr.117, -1, !dbg !194
    #dbg_value(i32 %dec, !147, !DIExpression(), !150)
  %add = add i32 %start.118, 1000, !dbg !196
    #dbg_value(i32 %add, !148, !DIExpression(), !150)
  %cmp2.not = icmp eq i32 %dec, 0, !dbg !197
  br i1 %cmp2.not, label %while.end6, label %land.rhs, !dbg !176, !llvm.loop !198

while.end6:                                       ; preds = %while.body5, %entry
  ret void, !dbg !200
}

; Function Attrs: nounwind optsize
define dso_local void @init() local_unnamed_addr addrspace(1) #3 !dbg !201 {
entry:
  tail call addrspace(0) void asm sideeffect "sei", "~{memory}"() #8, !dbg !202, !srcloc !203
  %0 = load volatile i8, ptr inttoptr (i16 68 to ptr), align 4, !dbg !204, !tbaa !135
  %1 = or i8 %0, 2, !dbg !204
  store volatile i8 %1, ptr inttoptr (i16 68 to ptr), align 4, !dbg !204, !tbaa !135
  %2 = load volatile i8, ptr inttoptr (i16 68 to ptr), align 4, !dbg !205, !tbaa !135
  %3 = or i8 %2, 1, !dbg !205
  store volatile i8 %3, ptr inttoptr (i16 68 to ptr), align 4, !dbg !205, !tbaa !135
  %4 = load volatile i8, ptr inttoptr (i16 69 to ptr), align 1, !dbg !206, !tbaa !135
  %5 = or i8 %4, 2, !dbg !206
  store volatile i8 %5, ptr inttoptr (i16 69 to ptr), align 1, !dbg !206, !tbaa !135
  %6 = load volatile i8, ptr inttoptr (i16 69 to ptr), align 1, !dbg !207, !tbaa !135
  %7 = or i8 %6, 1, !dbg !207
  store volatile i8 %7, ptr inttoptr (i16 69 to ptr), align 1, !dbg !207, !tbaa !135
  %8 = load volatile i8, ptr inttoptr (i16 110 to ptr), align 2, !dbg !208, !tbaa !135
  %9 = or i8 %8, 1, !dbg !208
  store volatile i8 %9, ptr inttoptr (i16 110 to ptr), align 2, !dbg !208, !tbaa !135
  store volatile i8 0, ptr inttoptr (i16 129 to ptr), align 1, !dbg !209, !tbaa !135
  %10 = load volatile i8, ptr inttoptr (i16 129 to ptr), align 1, !dbg !210, !tbaa !135
  %11 = or i8 %10, 2, !dbg !210
  store volatile i8 %11, ptr inttoptr (i16 129 to ptr), align 1, !dbg !210, !tbaa !135
  %12 = load volatile i8, ptr inttoptr (i16 129 to ptr), align 1, !dbg !211, !tbaa !135
  %13 = or i8 %12, 1, !dbg !211
  store volatile i8 %13, ptr inttoptr (i16 129 to ptr), align 1, !dbg !211, !tbaa !135
  %14 = load volatile i8, ptr inttoptr (i16 128 to ptr), align 128, !dbg !212, !tbaa !135
  %15 = or i8 %14, 1, !dbg !212
  store volatile i8 %15, ptr inttoptr (i16 128 to ptr), align 128, !dbg !212, !tbaa !135
  %16 = load volatile i8, ptr inttoptr (i16 177 to ptr), align 1, !dbg !213, !tbaa !135
  %17 = or i8 %16, 4, !dbg !213
  store volatile i8 %17, ptr inttoptr (i16 177 to ptr), align 1, !dbg !213, !tbaa !135
  %18 = load volatile i8, ptr inttoptr (i16 176 to ptr), align 16, !dbg !214, !tbaa !135
  %19 = or i8 %18, 1, !dbg !214
  store volatile i8 %19, ptr inttoptr (i16 176 to ptr), align 16, !dbg !214, !tbaa !135
  %20 = load volatile i8, ptr inttoptr (i16 145 to ptr), align 1, !dbg !215, !tbaa !135
  %21 = or i8 %20, 2, !dbg !215
  store volatile i8 %21, ptr inttoptr (i16 145 to ptr), align 1, !dbg !215, !tbaa !135
  %22 = load volatile i8, ptr inttoptr (i16 145 to ptr), align 1, !dbg !216, !tbaa !135
  %23 = or i8 %22, 1, !dbg !216
  store volatile i8 %23, ptr inttoptr (i16 145 to ptr), align 1, !dbg !216, !tbaa !135
  %24 = load volatile i8, ptr inttoptr (i16 144 to ptr), align 16, !dbg !217, !tbaa !135
  %25 = or i8 %24, 1, !dbg !217
  store volatile i8 %25, ptr inttoptr (i16 144 to ptr), align 16, !dbg !217, !tbaa !135
  %26 = load volatile i8, ptr inttoptr (i16 161 to ptr), align 1, !dbg !218, !tbaa !135
  %27 = or i8 %26, 2, !dbg !218
  store volatile i8 %27, ptr inttoptr (i16 161 to ptr), align 1, !dbg !218, !tbaa !135
  %28 = load volatile i8, ptr inttoptr (i16 161 to ptr), align 1, !dbg !219, !tbaa !135
  %29 = or i8 %28, 1, !dbg !219
  store volatile i8 %29, ptr inttoptr (i16 161 to ptr), align 1, !dbg !219, !tbaa !135
  %30 = load volatile i8, ptr inttoptr (i16 160 to ptr), align 32, !dbg !220, !tbaa !135
  %31 = or i8 %30, 1, !dbg !220
  store volatile i8 %31, ptr inttoptr (i16 160 to ptr), align 32, !dbg !220, !tbaa !135
  %32 = load volatile i8, ptr inttoptr (i16 289 to ptr), align 1, !dbg !221, !tbaa !135
  %33 = or i8 %32, 2, !dbg !221
  store volatile i8 %33, ptr inttoptr (i16 289 to ptr), align 1, !dbg !221, !tbaa !135
  %34 = load volatile i8, ptr inttoptr (i16 289 to ptr), align 1, !dbg !222, !tbaa !135
  %35 = or i8 %34, 1, !dbg !222
  store volatile i8 %35, ptr inttoptr (i16 289 to ptr), align 1, !dbg !222, !tbaa !135
  %36 = load volatile i8, ptr inttoptr (i16 288 to ptr), align 32, !dbg !223, !tbaa !135
  %37 = or i8 %36, 1, !dbg !223
  store volatile i8 %37, ptr inttoptr (i16 288 to ptr), align 32, !dbg !223, !tbaa !135
  %38 = load volatile i8, ptr inttoptr (i16 122 to ptr), align 2, !dbg !224, !tbaa !135
  %39 = or i8 %38, 4, !dbg !224
  store volatile i8 %39, ptr inttoptr (i16 122 to ptr), align 2, !dbg !224, !tbaa !135
  %40 = load volatile i8, ptr inttoptr (i16 122 to ptr), align 2, !dbg !225, !tbaa !135
  %41 = or i8 %40, 2, !dbg !225
  store volatile i8 %41, ptr inttoptr (i16 122 to ptr), align 2, !dbg !225, !tbaa !135
  %42 = load volatile i8, ptr inttoptr (i16 122 to ptr), align 2, !dbg !226, !tbaa !135
  %43 = or i8 %42, 1, !dbg !226
  store volatile i8 %43, ptr inttoptr (i16 122 to ptr), align 2, !dbg !226, !tbaa !135
  %44 = load volatile i8, ptr inttoptr (i16 122 to ptr), align 2, !dbg !227, !tbaa !135
  %45 = or i8 %44, -128, !dbg !227
  store volatile i8 %45, ptr inttoptr (i16 122 to ptr), align 2, !dbg !227, !tbaa !135
  store volatile i8 0, ptr inttoptr (i16 193 to ptr), align 1, !dbg !228, !tbaa !135
  ret void, !dbg !229
}

; Function Attrs: nounwind optsize
define dso_local void @pinMode(i8 noundef zeroext %pin, i8 noundef zeroext %mode) local_unnamed_addr addrspace(1) #3 !dbg !230 {
entry:
    #dbg_value(i8 %pin, !235, !DIExpression(), !261)
    #dbg_value(i8 %mode, !236, !DIExpression(), !261)
  %conv = zext i8 %pin to i16, !dbg !262
  %add.ptr = getelementptr inbounds nuw i8, ptr @digital_pin_to_bit_mask_PGM, i16 %conv, !dbg !262
  %0 = ptrtoint ptr %add.ptr to i16, !dbg !262
    #dbg_value(i16 %0, !238, !DIExpression(), !263)
  %1 = tail call addrspace(0) i8 asm sideeffect "lpm $0,${1:a}", "=r,z"(i16 %0) #8, !dbg !262, !srcloc !264
    #dbg_value(i8 %1, !240, !DIExpression(), !263)
    #dbg_value(i8 %1, !237, !DIExpression(), !261)
  %add.ptr3 = getelementptr inbounds nuw i8, ptr @digital_pin_to_port_PGM, i16 %conv, !dbg !265
  %2 = ptrtoint ptr %add.ptr3 to i16, !dbg !265
    #dbg_value(i16 %2, !242, !DIExpression(), !266)
  %3 = tail call addrspace(0) i8 asm sideeffect "lpm $0,${1:a}", "=r,z"(i16 %2) #8, !dbg !265, !srcloc !267
    #dbg_value(i8 %3, !244, !DIExpression(), !266)
    #dbg_value(i8 %3, !241, !DIExpression(), !261)
  %cmp = icmp eq i8 %3, 0, !dbg !268
  br i1 %cmp, label %cleanup, label %if.end, !dbg !268

if.end:                                           ; preds = %entry
  %conv6 = zext i8 %3 to i16, !dbg !270
  %add.ptr10 = getelementptr inbounds nuw i16, ptr @port_to_mode_PGM, i16 %conv6, !dbg !271
  %4 = ptrtoint ptr %add.ptr10 to i16, !dbg !271
    #dbg_value(i16 %4, !247, !DIExpression(), !272)
  %5 = tail call addrspace(0) { i16, i16 } asm sideeffect "lpm ${0:A},${1:a}+\0A\09lpm ${0:B},${1:a}+", "=r,=z,1"(i16 %4) #8, !dbg !271, !srcloc !273
  %asmresult = extractvalue { i16, i16 } %5, 0, !dbg !271
    #dbg_value(i16 %asmresult, !249, !DIExpression(), !272)
    #dbg_value(i16 poison, !247, !DIExpression(), !272)
  %6 = inttoptr i16 %asmresult to ptr, !dbg !274
    #dbg_value(ptr %6, !245, !DIExpression(), !261)
  %add.ptr16 = getelementptr inbounds nuw i16, ptr @port_to_output_PGM, i16 %conv6, !dbg !275
  %7 = ptrtoint ptr %add.ptr16 to i16, !dbg !275
    #dbg_value(i16 %7, !250, !DIExpression(), !276)
  %8 = tail call addrspace(0) { i16, i16 } asm sideeffect "lpm ${0:A},${1:a}+\0A\09lpm ${0:B},${1:a}+", "=r,=z,1"(i16 %7) #8, !dbg !275, !srcloc !277
  %asmresult18 = extractvalue { i16, i16 } %8, 0, !dbg !275
    #dbg_value(i16 %asmresult18, !252, !DIExpression(), !276)
    #dbg_value(i16 poison, !250, !DIExpression(), !276)
  %9 = inttoptr i16 %asmresult18 to ptr, !dbg !278
    #dbg_value(ptr %9, !246, !DIExpression(), !261)
  %10 = load volatile i8, ptr inttoptr (i16 95 to ptr), align 1, !dbg !279, !tbaa !135
  tail call addrspace(0) void asm sideeffect "cli", "~{memory}"() #8, !dbg !279
  switch i8 %mode, label %if.else46 [
    i8 0, label %if.then24
    i8 2, label %if.then36
  ], !dbg !280

if.then24:                                        ; preds = %if.end
    #dbg_value(i8 %10, !253, !DIExpression(), !281)
  %not = xor i8 %1, -1, !dbg !282
  %11 = load volatile i8, ptr %6, align 1, !dbg !283, !tbaa !135
  %conv27 = and i8 %11, %not, !dbg !283
  store volatile i8 %conv27, ptr %6, align 1, !dbg !283, !tbaa !135
  %12 = load volatile i8, ptr %9, align 1, !dbg !284, !tbaa !135
  %conv32 = and i8 %12, %not, !dbg !284
  store volatile i8 %conv32, ptr %9, align 1, !dbg !284, !tbaa !135
  br label %cleanup.sink.split, !dbg !285

if.then36:                                        ; preds = %if.end
    #dbg_value(i8 %10, !256, !DIExpression(), !286)
  %not39 = xor i8 %1, -1, !dbg !287
  %13 = load volatile i8, ptr %6, align 1, !dbg !288, !tbaa !135
  %and41 = and i8 %13, %not39, !dbg !288
  store volatile i8 %and41, ptr %6, align 1, !dbg !288, !tbaa !135
  %14 = load volatile i8, ptr %9, align 1, !dbg !289, !tbaa !135
  %or69 = or i8 %14, %1, !dbg !289
  store volatile i8 %or69, ptr %9, align 1, !dbg !289, !tbaa !135
  br label %cleanup.sink.split, !dbg !290

if.else46:                                        ; preds = %if.end
    #dbg_value(i8 %10, !259, !DIExpression(), !291)
  %15 = load volatile i8, ptr %6, align 1, !dbg !292, !tbaa !135
  %or5068 = or i8 %15, %1, !dbg !292
  store volatile i8 %or5068, ptr %6, align 1, !dbg !292, !tbaa !135
  br label %cleanup.sink.split

cleanup.sink.split:                               ; preds = %if.else46, %if.then36, %if.then24
  store volatile i8 %10, ptr inttoptr (i16 95 to ptr), align 1, !dbg !279, !tbaa !135
  br label %cleanup, !dbg !293

cleanup:                                          ; preds = %cleanup.sink.split, %entry
  ret void, !dbg !293
}

; Function Attrs: nounwind optsize
define dso_local void @digitalWrite(i8 noundef zeroext %pin, i8 noundef zeroext %val) local_unnamed_addr addrspace(1) #3 !dbg !294 {
entry:
    #dbg_value(i8 %pin, !296, !DIExpression(), !315)
    #dbg_value(i8 %val, !297, !DIExpression(), !315)
  %conv = zext i8 %pin to i16, !dbg !316
  %add.ptr = getelementptr inbounds nuw i8, ptr @digital_pin_to_timer_PGM, i16 %conv, !dbg !316
  %0 = ptrtoint ptr %add.ptr to i16, !dbg !316
    #dbg_value(i16 %0, !299, !DIExpression(), !317)
  %1 = tail call addrspace(0) i8 asm sideeffect "lpm $0,${1:a}", "=r,z"(i16 %0) #8, !dbg !316, !srcloc !318
    #dbg_value(i8 %1, !301, !DIExpression(), !317)
    #dbg_value(i8 %1, !298, !DIExpression(), !315)
  %add.ptr3 = getelementptr inbounds nuw i8, ptr @digital_pin_to_bit_mask_PGM, i16 %conv, !dbg !319
  %2 = ptrtoint ptr %add.ptr3 to i16, !dbg !319
    #dbg_value(i16 %2, !303, !DIExpression(), !320)
  %3 = tail call addrspace(0) i8 asm sideeffect "lpm $0,${1:a}", "=r,z"(i16 %2) #8, !dbg !319, !srcloc !321
    #dbg_value(i8 %3, !305, !DIExpression(), !320)
    #dbg_value(i8 %3, !302, !DIExpression(), !315)
  %add.ptr8 = getelementptr inbounds nuw i8, ptr @digital_pin_to_port_PGM, i16 %conv, !dbg !322
  %4 = ptrtoint ptr %add.ptr8 to i16, !dbg !322
    #dbg_value(i16 %4, !307, !DIExpression(), !323)
  %5 = tail call addrspace(0) i8 asm sideeffect "lpm $0,${1:a}", "=r,z"(i16 %4) #8, !dbg !322, !srcloc !324
    #dbg_value(i8 %5, !309, !DIExpression(), !323)
    #dbg_value(i8 %5, !306, !DIExpression(), !315)
  %conv11 = zext i8 %5 to i16, !dbg !325
  %cmp = icmp eq i8 %5, 0, !dbg !327
  br i1 %cmp, label %cleanup, label %if.end, !dbg !327

if.end:                                           ; preds = %entry
  %cmp14.not = icmp eq i8 %1, 0, !dbg !328
  br i1 %cmp14.not, label %if.end17, label %if.then16, !dbg !328

if.then16:                                        ; preds = %if.end
  tail call fastcc addrspace(1) void @turnOffPWM(i8 noundef zeroext %1) #7, !dbg !330
  br label %if.end17, !dbg !330

if.end17:                                         ; preds = %if.then16, %if.end
  %add.ptr20 = getelementptr inbounds nuw i16, ptr @port_to_output_PGM, i16 %conv11, !dbg !331
  %6 = ptrtoint ptr %add.ptr20 to i16, !dbg !331
    #dbg_value(i16 %6, !311, !DIExpression(), !332)
  %7 = tail call addrspace(0) { i16, i16 } asm sideeffect "lpm ${0:A},${1:a}+\0A\09lpm ${0:B},${1:a}+", "=r,=z,1"(i16 %6) #8, !dbg !331, !srcloc !333
  %asmresult = extractvalue { i16, i16 } %7, 0, !dbg !331
    #dbg_value(i16 %asmresult, !313, !DIExpression(), !332)
    #dbg_value(i16 poison, !311, !DIExpression(), !332)
  %8 = inttoptr i16 %asmresult to ptr, !dbg !334
    #dbg_value(ptr %8, !310, !DIExpression(), !315)
  %9 = load volatile i8, ptr inttoptr (i16 95 to ptr), align 1, !dbg !335, !tbaa !135
    #dbg_value(i8 %9, !314, !DIExpression(), !315)
  tail call addrspace(0) void asm sideeffect "cli", "~{memory}"() #8, !dbg !336, !srcloc !337
  %cmp25 = icmp eq i8 %val, 0, !dbg !338
  br i1 %cmp25, label %if.then27, label %if.else, !dbg !338

if.then27:                                        ; preds = %if.end17
  %not = xor i8 %3, -1, !dbg !340
  %10 = load volatile i8, ptr %8, align 1, !dbg !342, !tbaa !135
  %and = and i8 %10, %not, !dbg !342
  br label %if.end34, !dbg !343

if.else:                                          ; preds = %if.end17
  %11 = load volatile i8, ptr %8, align 1, !dbg !344, !tbaa !135
  %or44 = or i8 %11, %3, !dbg !344
  br label %if.end34

if.end34:                                         ; preds = %if.else, %if.then27
  %or44.sink = phi i8 [ %or44, %if.else ], [ %and, %if.then27 ]
  store volatile i8 %or44.sink, ptr %8, align 1, !dbg !346, !tbaa !135
  store volatile i8 %9, ptr inttoptr (i16 95 to ptr), align 1, !dbg !347, !tbaa !135
  br label %cleanup, !dbg !348

cleanup:                                          ; preds = %if.end34, %entry
  ret void, !dbg !348
}

; Function Attrs: nofree norecurse nounwind optsize
define internal fastcc void @turnOffPWM(i8 noundef zeroext %timer) unnamed_addr addrspace(1) #4 !dbg !349 {
entry:
    #dbg_value(i8 %timer, !353, !DIExpression(), !354)
  switch i8 %timer, label %sw.epilog [
    i8 3, label %sw.epilog.sink.split
    i8 4, label %sw.bb3
    i8 5, label %sw.bb7
    i8 1, label %sw.bb11
    i8 2, label %sw.bb15
    i8 7, label %sw.bb19
    i8 8, label %sw.bb23
    i8 9, label %sw.bb27
    i8 10, label %sw.bb31
    i8 11, label %sw.bb35
    i8 12, label %sw.bb39
    i8 13, label %sw.bb43
    i8 14, label %sw.bb47
    i8 16, label %sw.bb51
    i8 17, label %sw.bb55
    i8 18, label %sw.bb59
  ], !dbg !355

sw.bb3:                                           ; preds = %entry
  br label %sw.epilog.sink.split, !dbg !356

sw.bb7:                                           ; preds = %entry
  br label %sw.epilog.sink.split, !dbg !358

sw.bb11:                                          ; preds = %entry
  br label %sw.epilog.sink.split, !dbg !359

sw.bb15:                                          ; preds = %entry
  br label %sw.epilog.sink.split, !dbg !360

sw.bb19:                                          ; preds = %entry
  br label %sw.epilog.sink.split, !dbg !361

sw.bb23:                                          ; preds = %entry
  br label %sw.epilog.sink.split, !dbg !362

sw.bb27:                                          ; preds = %entry
  br label %sw.epilog.sink.split, !dbg !363

sw.bb31:                                          ; preds = %entry
  br label %sw.epilog.sink.split, !dbg !364

sw.bb35:                                          ; preds = %entry
  br label %sw.epilog.sink.split, !dbg !365

sw.bb39:                                          ; preds = %entry
  br label %sw.epilog.sink.split, !dbg !366

sw.bb43:                                          ; preds = %entry
  br label %sw.epilog.sink.split, !dbg !367

sw.bb47:                                          ; preds = %entry
  br label %sw.epilog.sink.split, !dbg !368

sw.bb51:                                          ; preds = %entry
  br label %sw.epilog.sink.split, !dbg !369

sw.bb55:                                          ; preds = %entry
  br label %sw.epilog.sink.split, !dbg !370

sw.bb59:                                          ; preds = %entry
  br label %sw.epilog.sink.split, !dbg !371

sw.epilog.sink.split:                             ; preds = %sw.bb59, %sw.bb55, %sw.bb51, %sw.bb47, %sw.bb43, %sw.bb39, %sw.bb35, %sw.bb31, %sw.bb27, %sw.bb23, %sw.bb19, %sw.bb15, %sw.bb11, %sw.bb7, %sw.bb3, %entry
  %.sink = phi ptr [ inttoptr (i16 288 to ptr), %sw.bb59 ], [ inttoptr (i16 288 to ptr), %sw.bb55 ], [ inttoptr (i16 288 to ptr), %sw.bb51 ], [ inttoptr (i16 160 to ptr), %sw.bb47 ], [ inttoptr (i16 160 to ptr), %sw.bb43 ], [ inttoptr (i16 160 to ptr), %sw.bb39 ], [ inttoptr (i16 144 to ptr), %sw.bb35 ], [ inttoptr (i16 144 to ptr), %sw.bb31 ], [ inttoptr (i16 144 to ptr), %sw.bb27 ], [ inttoptr (i16 176 to ptr), %sw.bb23 ], [ inttoptr (i16 176 to ptr), %sw.bb19 ], [ inttoptr (i16 68 to ptr), %sw.bb15 ], [ inttoptr (i16 68 to ptr), %sw.bb11 ], [ inttoptr (i16 128 to ptr), %sw.bb7 ], [ inttoptr (i16 128 to ptr), %sw.bb3 ], [ inttoptr (i16 128 to ptr), %entry ]
  %.sink65 = phi i8 [ -9, %sw.bb59 ], [ -33, %sw.bb55 ], [ 127, %sw.bb51 ], [ -9, %sw.bb47 ], [ -33, %sw.bb43 ], [ 127, %sw.bb39 ], [ -9, %sw.bb35 ], [ -33, %sw.bb31 ], [ 127, %sw.bb27 ], [ -33, %sw.bb23 ], [ 127, %sw.bb19 ], [ -33, %sw.bb15 ], [ 127, %sw.bb11 ], [ -9, %sw.bb7 ], [ -33, %sw.bb3 ], [ 127, %entry ]
  %0 = load volatile i8, ptr %.sink, align 4, !dbg !372, !tbaa !135
  %1 = and i8 %0, %.sink65, !dbg !372
  store volatile i8 %1, ptr %.sink, align 4, !dbg !372, !tbaa !135
  br label %sw.epilog, !dbg !373

sw.epilog:                                        ; preds = %sw.epilog.sink.split, %entry
  ret void, !dbg !373
}

; Function Attrs: mustprogress nounwind optsize
define weak dso_local void @_Z11serialEventv() addrspace(1) #0 !dbg !374 {
entry:
  ret void, !dbg !376
}

; Function Attrs: mustprogress nounwind optsize
define weak dso_local noundef i1 @_Z17Serial0_availablev() addrspace(1) #0 !dbg !377 {
entry:
  ret i1 false, !dbg !381
}

; Function Attrs: mustprogress nounwind optsize
define weak dso_local void @_Z12serialEvent1v() addrspace(1) #0 !dbg !382 {
entry:
  ret void, !dbg !383
}

; Function Attrs: mustprogress nounwind optsize
define weak dso_local noundef i1 @_Z17Serial1_availablev() addrspace(1) #0 !dbg !384 {
entry:
  ret i1 false, !dbg !385
}

; Function Attrs: mustprogress nounwind optsize
define weak dso_local void @_Z12serialEvent2v() addrspace(1) #0 !dbg !386 {
entry:
  ret void, !dbg !387
}

; Function Attrs: mustprogress nounwind optsize
define weak dso_local noundef i1 @_Z17Serial2_availablev() addrspace(1) #0 !dbg !388 {
entry:
  ret i1 false, !dbg !389
}

; Function Attrs: mustprogress nounwind optsize
define weak dso_local void @_Z12serialEvent3v() addrspace(1) #0 !dbg !390 {
entry:
  ret void, !dbg !391
}

; Function Attrs: mustprogress nounwind optsize
define weak dso_local noundef i1 @_Z17Serial3_availablev() addrspace(1) #0 !dbg !392 {
entry:
  ret i1 false, !dbg !393
}

; Function Attrs: mustprogress nounwind optsize
define dso_local void @_Z14serialEventRunv() local_unnamed_addr addrspace(1) #0 !dbg !394 {
entry:
  %tobool = icmp ne ptr addrspace(1) @_Z17Serial0_availablev, null, !dbg !395
  %tobool1 = icmp ne ptr addrspace(1) @_Z11serialEventv, null
  %or.cond = and i1 %tobool, %tobool1, !dbg !397
  br i1 %or.cond, label %land.lhs.true2, label %if.end, !dbg !397

land.lhs.true2:                                   ; preds = %entry
  %call = tail call noundef addrspace(1) i1 @_Z17Serial0_availablev() #7, !dbg !398
  br i1 %call, label %if.then, label %if.end, !dbg !399

if.then:                                          ; preds = %land.lhs.true2
  tail call addrspace(1) void @_Z11serialEventv() #7, !dbg !400
  br label %if.end, !dbg !400

if.end:                                           ; preds = %if.then, %land.lhs.true2, %entry
  %tobool3 = icmp ne ptr addrspace(1) @_Z17Serial1_availablev, null, !dbg !401
  %tobool5 = icmp ne ptr addrspace(1) @_Z12serialEvent1v, null
  %or.cond24 = and i1 %tobool3, %tobool5, !dbg !403
  br i1 %or.cond24, label %land.lhs.true6, label %if.end9, !dbg !403

land.lhs.true6:                                   ; preds = %if.end
  %call7 = tail call noundef addrspace(1) i1 @_Z17Serial1_availablev() #7, !dbg !404
  br i1 %call7, label %if.then8, label %if.end9, !dbg !405

if.then8:                                         ; preds = %land.lhs.true6
  tail call addrspace(1) void @_Z12serialEvent1v() #7, !dbg !406
  br label %if.end9, !dbg !406

if.end9:                                          ; preds = %if.then8, %land.lhs.true6, %if.end
  %tobool10 = icmp ne ptr addrspace(1) @_Z17Serial2_availablev, null, !dbg !407
  %tobool12 = icmp ne ptr addrspace(1) @_Z12serialEvent2v, null
  %or.cond25 = and i1 %tobool10, %tobool12, !dbg !409
  br i1 %or.cond25, label %land.lhs.true13, label %if.end16, !dbg !409

land.lhs.true13:                                  ; preds = %if.end9
  %call14 = tail call noundef addrspace(1) i1 @_Z17Serial2_availablev() #7, !dbg !410
  br i1 %call14, label %if.then15, label %if.end16, !dbg !411

if.then15:                                        ; preds = %land.lhs.true13
  tail call addrspace(1) void @_Z12serialEvent2v() #7, !dbg !412
  br label %if.end16, !dbg !412

if.end16:                                         ; preds = %if.then15, %land.lhs.true13, %if.end9
  %tobool17 = icmp ne ptr addrspace(1) @_Z17Serial3_availablev, null, !dbg !413
  %tobool19 = icmp ne ptr addrspace(1) @_Z12serialEvent3v, null
  %or.cond26 = and i1 %tobool17, %tobool19, !dbg !415
  br i1 %or.cond26, label %land.lhs.true20, label %if.end23, !dbg !415

land.lhs.true20:                                  ; preds = %if.end16
  %call21 = tail call noundef addrspace(1) i1 @_Z17Serial3_availablev() #7, !dbg !416
  br i1 %call21, label %if.then22, label %if.end23, !dbg !417

if.then22:                                        ; preds = %land.lhs.true20
  tail call addrspace(1) void @_Z12serialEvent3v() #7, !dbg !418
  br label %if.end23, !dbg !418

if.end23:                                         ; preds = %if.then22, %land.lhs.true20, %if.end16
  ret void, !dbg !419
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none)
define internal void @__empty() addrspace(1) #5 !dbg !420 {
entry:
  ret void, !dbg !422
}

attributes #0 = { mustprogress nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="atmega2560" }
attributes #1 = { mustprogress norecurse noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="atmega2560" }
attributes #2 = { nofree norecurse nounwind optsize memory(readwrite, argmem: none) "frame-pointer"="all" "no-trapping-math"="true" "signal" "stack-protector-buffer-size"="8" "target-cpu"="atmega2560" }
attributes #3 = { nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="atmega2560" }
attributes #4 = { nofree norecurse nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="atmega2560" }
attributes #5 = { mustprogress nofree norecurse nosync nounwind optsize willreturn memory(none) "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="atmega2560" }
attributes #6 = { nounwind optsize }
attributes #7 = { optsize }
attributes #8 = { nounwind }

!llvm.dbg.cu = !{!45, !47, !2, !22, !49, !54, !79, !81}
!llvm.ident = !{!83, !83, !83, !83, !83, !83, !83, !83}
!llvm.module.flags = !{!84, !85, !86, !87, !88, !89}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "timer0_overflow_count", scope: !2, file: !15, line: 38, type: !16, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !12, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/home/dakkshesh/.arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/wiring.c", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "994415fa64a48bd96f4d61f0e982be72")
!4 = !{!5, !10}
!5 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 16)
!6 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !7)
!7 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !8, line: 126, baseType: !9)
!8 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/tools/cba-avr-sysroot/12022025/lib/gcc/avr/14.2.0/../../../../avr/include/stdint.h", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "348d903c92cfc3abd32b2860a57bc71f")
!9 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint16_t", file: !8, line: 128, baseType: !11)
!11 = !DIBasicType(name: "unsigned int", size: 16, encoding: DW_ATE_unsigned)
!12 = !{!0, !13, !18}
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "timer0_millis", scope: !2, file: !15, line: 39, type: !16, isLocal: false, isDefinition: true)
!15 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/wiring.c", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "994415fa64a48bd96f4d61f0e982be72")
!16 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !17)
!17 = !DIBasicType(name: "unsigned long", size: 32, encoding: DW_ATE_unsigned)
!18 = !DIGlobalVariableExpression(var: !19, expr: !DIExpression())
!19 = distinct !DIGlobalVariable(name: "timer0_fract", scope: !2, file: !15, line: 40, type: !9, isLocal: true, isDefinition: true)
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(name: "port_to_mode_PGM", scope: !22, file: !28, line: 114, type: !29, isLocal: false, isDefinition: true)
!22 = distinct !DICompileUnit(language: DW_LANG_C11, file: !23, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !24, globals: !25, splitDebugInlining: false, nameTableKind: None)
!23 = !DIFile(filename: "/home/dakkshesh/.arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/wiring_digital.c", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "39c33a7b95d6d6678b30c1d00a612dd3")
!24 = !{!10, !5}
!25 = !{!20, !26, !33, !35, !41, !43}
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "port_to_output_PGM", scope: !22, file: !28, line: 130, type: !29, isLocal: false, isDefinition: true)
!28 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/variants/mega/pins_arduino.h", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "998eebdbc89691f6a084383d393e1144")
!29 = !DICompositeType(tag: DW_TAG_array_type, baseType: !30, size: 208, elements: !31)
!30 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !10)
!31 = !{!32}
!32 = !DISubrange(count: 13)
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "port_to_input_PGM", scope: !22, file: !28, line: 146, type: !29, isLocal: false, isDefinition: true)
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "digital_pin_to_port_PGM", scope: !22, file: !28, line: 162, type: !37, isLocal: false, isDefinition: true)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !38, size: 560, elements: !39)
!38 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !7)
!39 = !{!40}
!40 = !DISubrange(count: 70)
!41 = !DIGlobalVariableExpression(var: !42, expr: !DIExpression())
!42 = distinct !DIGlobalVariable(name: "digital_pin_to_bit_mask_PGM", scope: !22, file: !28, line: 237, type: !37, isLocal: false, isDefinition: true)
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "digital_pin_to_timer_PGM", scope: !22, file: !28, line: 312, type: !37, isLocal: false, isDefinition: true)
!45 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_11, file: !46, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!46 = !DIFile(filename: "/home/dakkshesh/.cache/arduino/sketches/0A3424900B1B32407700B6A1409F8FE7/sketch/Blink.ino.cpp", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "2d2bf6bde7b076cad176b3c03737c627")
!47 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_11, file: !48, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!48 = !DIFile(filename: "/home/dakkshesh/.arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/main.cpp", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "e51b97ee7aa9b47fc852f0cf5785e5bb")
!49 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_11, file: !50, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !51, splitDebugInlining: false, nameTableKind: None)
!50 = !DIFile(filename: "/home/dakkshesh/.arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/HardwareSerial.cpp", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "5c2790dc3d3fc22ab0920c4c2fd9aef6")
!51 = !{!5, !10, !11, !52}
!52 = !DIDerivedType(tag: DW_TAG_typedef, name: "rx_buffer_index_t", file: !53, line: 64, baseType: !7)
!53 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/HardwareSerial.h", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "438cf3249079c995d56c243216bb9ad9")
!54 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_11, file: !55, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !56, globals: !63, splitDebugInlining: false, nameTableKind: None)
!55 = !DIFile(filename: "/home/dakkshesh/.arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/Print.cpp", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "ed8a582bc90c37e7b4edf417ff05c32c")
!56 = !{!57, !10, !17, !60, !61, !11, !62}
!57 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !58, size: 16)
!58 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !59)
!59 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!60 = !DIBasicType(name: "long", size: 32, encoding: DW_ATE_signed)
!61 = !DIBasicType(name: "double", size: 32, encoding: DW_ATE_float)
!62 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !38, size: 16)
!63 = !{!64, !70, !75, !77}
!64 = !DIGlobalVariableExpression(var: !65, expr: !DIExpression())
!65 = distinct !DIGlobalVariable(scope: null, file: !66, line: 128, type: !67, isLocal: true, isDefinition: true)
!66 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/Print.cpp", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "ed8a582bc90c37e7b4edf417ff05c32c")
!67 = !DICompositeType(tag: DW_TAG_array_type, baseType: !58, size: 24, elements: !68)
!68 = !{!69}
!69 = !DISubrange(count: 3)
!70 = !DIGlobalVariableExpression(var: !71, expr: !DIExpression())
!71 = distinct !DIGlobalVariable(scope: null, file: !66, line: 227, type: !72, isLocal: true, isDefinition: true)
!72 = !DICompositeType(tag: DW_TAG_array_type, baseType: !58, size: 32, elements: !73)
!73 = !{!74}
!74 = !DISubrange(count: 4)
!75 = !DIGlobalVariableExpression(var: !76, expr: !DIExpression())
!76 = distinct !DIGlobalVariable(scope: null, file: !66, line: 228, type: !72, isLocal: true, isDefinition: true)
!77 = !DIGlobalVariableExpression(var: !78, expr: !DIExpression())
!78 = distinct !DIGlobalVariable(scope: null, file: !66, line: 229, type: !72, isLocal: true, isDefinition: true)
!79 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_11, file: !80, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!80 = !DIFile(filename: "/home/dakkshesh/.arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/abi.cpp", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "f183939813882133c44065b78cb69cc5")
!81 = distinct !DICompileUnit(language: DW_LANG_C11, file: !82, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!82 = !DIFile(filename: "/home/dakkshesh/.arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/hooks.c", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "a13a341b0b6939f30312b1fbabff8511")
!83 = !{!"ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)"}
!84 = !{i32 7, !"Dwarf Version", i32 5}
!85 = !{i32 2, !"Debug Info Version", i32 3}
!86 = !{i32 1, !"wchar_size", i32 2}
!87 = !{i32 7, !"frame-pointer", i32 2}
!88 = !{i32 1, !"ThinLTO", i32 0}
!89 = !{i32 1, !"EnableSplitLTOUnit", i32 1}
!90 = distinct !DISubprogram(name: "setup", scope: !91, file: !91, line: 2, type: !92, scopeLine: 2, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !45)
!91 = !DIFile(filename: "Blink/Blink.ino", directory: "/home/dakkshesh/arduio-cbl")
!92 = !DISubroutineType(types: !93)
!93 = !{null}
!94 = !DILocation(line: 3, column: 3, scope: !90)
!95 = !DILocation(line: 4, column: 1, scope: !90)
!96 = distinct !DISubprogram(name: "loop", scope: !91, file: !91, line: 6, type: !92, scopeLine: 6, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !45)
!97 = !DILocation(line: 7, column: 3, scope: !96)
!98 = !DILocation(line: 8, column: 3, scope: !96)
!99 = !DILocation(line: 9, column: 3, scope: !96)
!100 = !DILocation(line: 10, column: 3, scope: !96)
!101 = !DILocation(line: 11, column: 1, scope: !96)
!102 = distinct !DISubprogram(name: "initVariant", scope: !103, file: !103, line: 28, type: !92, scopeLine: 28, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !47)
!103 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/main.cpp", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "e51b97ee7aa9b47fc852f0cf5785e5bb")
!104 = !DILocation(line: 28, column: 22, scope: !102)
!105 = distinct !DISubprogram(name: "main", scope: !103, file: !103, line: 33, type: !106, scopeLine: 34, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !47)
!106 = !DISubroutineType(types: !107)
!107 = !{!108}
!108 = !DIBasicType(name: "int", size: 16, encoding: DW_ATE_signed)
!109 = !DILocation(line: 35, column: 2, scope: !105)
!110 = !DILocation(line: 37, column: 2, scope: !105)
!111 = !DILocation(line: 43, column: 2, scope: !105)
!112 = !DILocation(line: 45, column: 2, scope: !105)
!113 = !DILocation(line: 46, column: 3, scope: !114)
!114 = distinct !DILexicalBlock(scope: !115, file: !103, line: 45, column: 11)
!115 = distinct !DILexicalBlock(scope: !116, file: !103, line: 45, column: 2)
!116 = distinct !DILexicalBlock(scope: !105, file: !103, line: 45, column: 2)
!117 = !DILocation(line: 47, column: 23, scope: !118)
!118 = distinct !DILexicalBlock(scope: !114, file: !103, line: 47, column: 7)
!119 = !DILocation(line: 45, column: 2, scope: !115)
!120 = distinct !{!120, !121, !122, !123}
!121 = !DILocation(line: 45, column: 2, scope: !116)
!122 = !DILocation(line: 48, column: 2, scope: !116)
!123 = !{!"llvm.loop.mustprogress"}
!124 = distinct !DISubprogram(name: "__vector_23", scope: !15, file: !15, line: 45, type: !92, scopeLine: 47, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !125)
!125 = !{!126, !127}
!126 = !DILocalVariable(name: "m", scope: !124, file: !15, line: 50, type: !17)
!127 = !DILocalVariable(name: "f", scope: !124, file: !15, line: 51, type: !9)
!128 = !DILocation(line: 50, column: 20, scope: !124)
!129 = !{!130, !130, i64 0}
!130 = !{!"long", !131, i64 0}
!131 = !{!"omnipotent char", !132, i64 0}
!132 = !{!"Simple C/C++ TBAA"}
!133 = !DILocation(line: 0, scope: !124)
!134 = !DILocation(line: 51, column: 20, scope: !124)
!135 = !{!131, !131, i64 0}
!136 = !DILocation(line: 54, column: 4, scope: !124)
!137 = !DILocation(line: 55, column: 8, scope: !138)
!138 = distinct !DILexicalBlock(scope: !124, file: !15, line: 55, column: 6)
!139 = !DILocation(line: 60, column: 15, scope: !124)
!140 = !DILocation(line: 61, column: 16, scope: !124)
!141 = !DILocation(line: 62, column: 23, scope: !124)
!142 = !DILocation(line: 63, column: 1, scope: !124)
!143 = distinct !DISubprogram(name: "delay", scope: !15, file: !15, line: 106, type: !144, scopeLine: 107, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !146)
!144 = !DISubroutineType(types: !145)
!145 = !{null, !17}
!146 = !{!147, !148}
!147 = !DILocalVariable(name: "ms", arg: 1, scope: !143, file: !15, line: 106, type: !17)
!148 = !DILocalVariable(name: "start", scope: !143, file: !15, line: 108, type: !149)
!149 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !8, line: 130, baseType: !17)
!150 = !DILocation(line: 0, scope: !143)
!151 = !DILocation(line: 81, column: 20, scope: !152, inlinedAt: !159)
!152 = distinct !DISubprogram(name: "micros", scope: !15, file: !15, line: 79, type: !153, scopeLine: 79, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !155)
!153 = !DISubroutineType(types: !154)
!154 = !{!17}
!155 = !{!156, !157, !158}
!156 = !DILocalVariable(name: "m", scope: !152, file: !15, line: 80, type: !17)
!157 = !DILocalVariable(name: "oldSREG", scope: !152, file: !15, line: 81, type: !7)
!158 = !DILocalVariable(name: "t", scope: !152, file: !15, line: 81, type: !7)
!159 = distinct !DILocation(line: 108, column: 19, scope: !143)
!160 = !DILocation(line: 0, scope: !152, inlinedAt: !159)
!161 = !DILocation(line: 83, column: 2, scope: !152, inlinedAt: !159)
!162 = !{i64 2148006487}
!163 = !DILocation(line: 84, column: 6, scope: !152, inlinedAt: !159)
!164 = !DILocation(line: 86, column: 6, scope: !152, inlinedAt: !159)
!165 = !DILocation(line: 94, column: 7, scope: !166, inlinedAt: !159)
!166 = distinct !DILexicalBlock(scope: !152, file: !15, line: 94, column: 6)
!167 = !DILocation(line: 101, column: 7, scope: !152, inlinedAt: !159)
!168 = !DILocation(line: 110, column: 12, scope: !143)
!169 = !DILocation(line: 110, column: 2, scope: !143)
!170 = !DILocation(line: 94, column: 13, scope: !166, inlinedAt: !159)
!171 = !DILocation(line: 94, column: 26, scope: !166, inlinedAt: !159)
!172 = !DILocation(line: 103, column: 24, scope: !152, inlinedAt: !159)
!173 = !DILocation(line: 103, column: 21, scope: !152, inlinedAt: !159)
!174 = !DILocation(line: 111, column: 3, scope: !175)
!175 = distinct !DILexicalBlock(scope: !143, file: !15, line: 110, column: 17)
!176 = !DILocation(line: 112, column: 18, scope: !175)
!177 = !DILocation(line: 81, column: 20, scope: !152, inlinedAt: !178)
!178 = distinct !DILocation(line: 112, column: 22, scope: !175)
!179 = !DILocation(line: 0, scope: !152, inlinedAt: !178)
!180 = !DILocation(line: 83, column: 2, scope: !152, inlinedAt: !178)
!181 = !DILocation(line: 84, column: 6, scope: !152, inlinedAt: !178)
!182 = !DILocation(line: 86, column: 6, scope: !152, inlinedAt: !178)
!183 = !DILocation(line: 94, column: 7, scope: !166, inlinedAt: !178)
!184 = !DILocation(line: 94, column: 13, scope: !166, inlinedAt: !178)
!185 = !DILocation(line: 94, column: 26, scope: !166, inlinedAt: !178)
!186 = !DILocation(line: 101, column: 7, scope: !152, inlinedAt: !178)
!187 = !DILocation(line: 103, column: 21, scope: !152, inlinedAt: !178)
!188 = !DILocation(line: 103, column: 24, scope: !152, inlinedAt: !178)
!189 = !DILocation(line: 112, column: 31, scope: !175)
!190 = !DILocation(line: 112, column: 40, scope: !175)
!191 = !DILocation(line: 112, column: 3, scope: !175)
!192 = distinct !{!192, !169, !193, !123}
!193 = !DILocation(line: 116, column: 2, scope: !143)
!194 = !DILocation(line: 113, column: 6, scope: !195)
!195 = distinct !DILexicalBlock(scope: !175, file: !15, line: 112, column: 49)
!196 = !DILocation(line: 114, column: 10, scope: !195)
!197 = !DILocation(line: 112, column: 14, scope: !175)
!198 = distinct !{!198, !191, !199, !123}
!199 = !DILocation(line: 115, column: 3, scope: !175)
!200 = !DILocation(line: 117, column: 1, scope: !143)
!201 = distinct !DISubprogram(name: "init", scope: !15, file: !15, line: 241, type: !92, scopeLine: 242, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!202 = !DILocation(line: 245, column: 2, scope: !201)
!203 = !{i64 2148006943}
!204 = !DILocation(line: 251, column: 2, scope: !201)
!205 = !DILocation(line: 252, column: 2, scope: !201)
!206 = !DILocation(line: 265, column: 2, scope: !201)
!207 = !DILocation(line: 266, column: 2, scope: !201)
!208 = !DILocation(line: 279, column: 2, scope: !201)
!209 = !DILocation(line: 290, column: 9, scope: !201)
!210 = !DILocation(line: 293, column: 2, scope: !201)
!211 = !DILocation(line: 295, column: 2, scope: !201)
!212 = !DILocation(line: 305, column: 2, scope: !201)
!213 = !DILocation(line: 312, column: 2, scope: !201)
!214 = !DILocation(line: 321, column: 2, scope: !201)
!215 = !DILocation(line: 327, column: 2, scope: !201)
!216 = !DILocation(line: 328, column: 2, scope: !201)
!217 = !DILocation(line: 329, column: 2, scope: !201)
!218 = !DILocation(line: 341, column: 2, scope: !201)
!219 = !DILocation(line: 342, column: 2, scope: !201)
!220 = !DILocation(line: 343, column: 2, scope: !201)
!221 = !DILocation(line: 348, column: 2, scope: !201)
!222 = !DILocation(line: 349, column: 2, scope: !201)
!223 = !DILocation(line: 350, column: 2, scope: !201)
!224 = !DILocation(line: 356, column: 3, scope: !201)
!225 = !DILocation(line: 357, column: 3, scope: !201)
!226 = !DILocation(line: 358, column: 3, scope: !201)
!227 = !DILocation(line: 381, column: 2, scope: !201)
!228 = !DILocation(line: 390, column: 9, scope: !201)
!229 = !DILocation(line: 392, column: 1, scope: !201)
!230 = distinct !DISubprogram(name: "pinMode", scope: !231, file: !231, line: 29, type: !232, scopeLine: 30, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !22, retainedNodes: !234)
!231 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/wiring_digital.c", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "39c33a7b95d6d6678b30c1d00a612dd3")
!232 = !DISubroutineType(types: !233)
!233 = !{null, !7, !7}
!234 = !{!235, !236, !237, !238, !240, !241, !242, !244, !245, !246, !247, !249, !250, !252, !253, !256, !259}
!235 = !DILocalVariable(name: "pin", arg: 1, scope: !230, file: !231, line: 29, type: !7)
!236 = !DILocalVariable(name: "mode", arg: 2, scope: !230, file: !231, line: 29, type: !7)
!237 = !DILocalVariable(name: "bit", scope: !230, file: !231, line: 31, type: !7)
!238 = !DILocalVariable(name: "__addr16", scope: !239, file: !231, line: 31, type: !10)
!239 = distinct !DILexicalBlock(scope: !230, file: !231, line: 31, column: 16)
!240 = !DILocalVariable(name: "__result", scope: !239, file: !231, line: 31, type: !7)
!241 = !DILocalVariable(name: "port", scope: !230, file: !231, line: 32, type: !7)
!242 = !DILocalVariable(name: "__addr16", scope: !243, file: !231, line: 32, type: !10)
!243 = distinct !DILexicalBlock(scope: !230, file: !231, line: 32, column: 17)
!244 = !DILocalVariable(name: "__result", scope: !243, file: !231, line: 32, type: !7)
!245 = !DILocalVariable(name: "reg", scope: !230, file: !231, line: 33, type: !5)
!246 = !DILocalVariable(name: "out", scope: !230, file: !231, line: 33, type: !5)
!247 = !DILocalVariable(name: "__addr16", scope: !248, file: !231, line: 38, type: !10)
!248 = distinct !DILexicalBlock(scope: !230, file: !231, line: 38, column: 8)
!249 = !DILocalVariable(name: "__result", scope: !248, file: !231, line: 38, type: !10)
!250 = !DILocalVariable(name: "__addr16", scope: !251, file: !231, line: 39, type: !10)
!251 = distinct !DILexicalBlock(scope: !230, file: !231, line: 39, column: 8)
!252 = !DILocalVariable(name: "__result", scope: !251, file: !231, line: 39, type: !10)
!253 = !DILocalVariable(name: "oldSREG", scope: !254, file: !231, line: 42, type: !7)
!254 = distinct !DILexicalBlock(scope: !255, file: !231, line: 41, column: 21)
!255 = distinct !DILexicalBlock(scope: !230, file: !231, line: 41, column: 6)
!256 = !DILocalVariable(name: "oldSREG", scope: !257, file: !231, line: 48, type: !7)
!257 = distinct !DILexicalBlock(scope: !258, file: !231, line: 47, column: 35)
!258 = distinct !DILexicalBlock(scope: !255, file: !231, line: 47, column: 13)
!259 = !DILocalVariable(name: "oldSREG", scope: !260, file: !231, line: 54, type: !7)
!260 = distinct !DILexicalBlock(scope: !258, file: !231, line: 53, column: 9)
!261 = !DILocation(line: 0, scope: !230)
!262 = !DILocation(line: 31, column: 16, scope: !239)
!263 = !DILocation(line: 0, scope: !239)
!264 = !{i64 2148004195}
!265 = !DILocation(line: 32, column: 17, scope: !243)
!266 = !DILocation(line: 0, scope: !243)
!267 = !{i64 2148004795}
!268 = !DILocation(line: 35, column: 11, scope: !269)
!269 = distinct !DILexicalBlock(scope: !230, file: !231, line: 35, column: 6)
!270 = !DILocation(line: 35, column: 6, scope: !269)
!271 = !DILocation(line: 38, column: 8, scope: !248)
!272 = !DILocation(line: 0, scope: !248)
!273 = !{i64 2148005400, i64 2148005429}
!274 = !DILocation(line: 38, column: 8, scope: !230)
!275 = !DILocation(line: 39, column: 8, scope: !251)
!276 = !DILocation(line: 0, scope: !251)
!277 = !{i64 2148006069, i64 2148006098}
!278 = !DILocation(line: 39, column: 8, scope: !230)
!279 = !DILocation(line: 0, scope: !255)
!280 = !DILocation(line: 41, column: 11, scope: !255)
!281 = !DILocation(line: 0, scope: !254)
!282 = !DILocation(line: 44, column: 11, scope: !254)
!283 = !DILocation(line: 44, column: 8, scope: !254)
!284 = !DILocation(line: 45, column: 8, scope: !254)
!285 = !DILocation(line: 47, column: 2, scope: !254)
!286 = !DILocation(line: 0, scope: !257)
!287 = !DILocation(line: 50, column: 11, scope: !257)
!288 = !DILocation(line: 50, column: 8, scope: !257)
!289 = !DILocation(line: 51, column: 8, scope: !257)
!290 = !DILocation(line: 53, column: 2, scope: !257)
!291 = !DILocation(line: 0, scope: !260)
!292 = !DILocation(line: 56, column: 8, scope: !260)
!293 = !DILocation(line: 59, column: 1, scope: !230)
!294 = distinct !DISubprogram(name: "digitalWrite", scope: !231, file: !231, line: 138, type: !232, scopeLine: 139, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !22, retainedNodes: !295)
!295 = !{!296, !297, !298, !299, !301, !302, !303, !305, !306, !307, !309, !310, !311, !313, !314}
!296 = !DILocalVariable(name: "pin", arg: 1, scope: !294, file: !231, line: 138, type: !7)
!297 = !DILocalVariable(name: "val", arg: 2, scope: !294, file: !231, line: 138, type: !7)
!298 = !DILocalVariable(name: "timer", scope: !294, file: !231, line: 140, type: !7)
!299 = !DILocalVariable(name: "__addr16", scope: !300, file: !231, line: 140, type: !10)
!300 = distinct !DILexicalBlock(scope: !294, file: !231, line: 140, column: 18)
!301 = !DILocalVariable(name: "__result", scope: !300, file: !231, line: 140, type: !7)
!302 = !DILocalVariable(name: "bit", scope: !294, file: !231, line: 141, type: !7)
!303 = !DILocalVariable(name: "__addr16", scope: !304, file: !231, line: 141, type: !10)
!304 = distinct !DILexicalBlock(scope: !294, file: !231, line: 141, column: 16)
!305 = !DILocalVariable(name: "__result", scope: !304, file: !231, line: 141, type: !7)
!306 = !DILocalVariable(name: "port", scope: !294, file: !231, line: 142, type: !7)
!307 = !DILocalVariable(name: "__addr16", scope: !308, file: !231, line: 142, type: !10)
!308 = distinct !DILexicalBlock(scope: !294, file: !231, line: 142, column: 17)
!309 = !DILocalVariable(name: "__result", scope: !308, file: !231, line: 142, type: !7)
!310 = !DILocalVariable(name: "out", scope: !294, file: !231, line: 143, type: !5)
!311 = !DILocalVariable(name: "__addr16", scope: !312, file: !231, line: 151, type: !10)
!312 = distinct !DILexicalBlock(scope: !294, file: !231, line: 151, column: 8)
!313 = !DILocalVariable(name: "__result", scope: !312, file: !231, line: 151, type: !10)
!314 = !DILocalVariable(name: "oldSREG", scope: !294, file: !231, line: 153, type: !7)
!315 = !DILocation(line: 0, scope: !294)
!316 = !DILocation(line: 140, column: 18, scope: !300)
!317 = !DILocation(line: 0, scope: !300)
!318 = !{i64 2148014301}
!319 = !DILocation(line: 141, column: 16, scope: !304)
!320 = !DILocation(line: 0, scope: !304)
!321 = !{i64 2148014917}
!322 = !DILocation(line: 142, column: 17, scope: !308)
!323 = !DILocation(line: 0, scope: !308)
!324 = !{i64 2148015517}
!325 = !DILocation(line: 145, column: 6, scope: !326)
!326 = distinct !DILexicalBlock(scope: !294, file: !231, line: 145, column: 6)
!327 = !DILocation(line: 145, column: 11, scope: !326)
!328 = !DILocation(line: 149, column: 12, scope: !329)
!329 = distinct !DILexicalBlock(scope: !294, file: !231, line: 149, column: 6)
!330 = !DILocation(line: 149, column: 29, scope: !329)
!331 = !DILocation(line: 151, column: 8, scope: !312)
!332 = !DILocation(line: 0, scope: !312)
!333 = !{i64 2148016132, i64 2148016161}
!334 = !DILocation(line: 151, column: 8, scope: !294)
!335 = !DILocation(line: 153, column: 20, scope: !294)
!336 = !DILocation(line: 154, column: 2, scope: !294)
!337 = !{i64 2148016427}
!338 = !DILocation(line: 156, column: 10, scope: !339)
!339 = distinct !DILexicalBlock(scope: !294, file: !231, line: 156, column: 6)
!340 = !DILocation(line: 157, column: 11, scope: !341)
!341 = distinct !DILexicalBlock(scope: !339, file: !231, line: 156, column: 18)
!342 = !DILocation(line: 157, column: 8, scope: !341)
!343 = !DILocation(line: 158, column: 2, scope: !341)
!344 = !DILocation(line: 159, column: 8, scope: !345)
!345 = distinct !DILexicalBlock(scope: !339, file: !231, line: 158, column: 9)
!346 = !DILocation(line: 0, scope: !339)
!347 = !DILocation(line: 162, column: 7, scope: !294)
!348 = !DILocation(line: 163, column: 1, scope: !294)
!349 = distinct !DISubprogram(name: "turnOffPWM", scope: !231, file: !231, line: 75, type: !350, scopeLine: 76, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !22, retainedNodes: !352)
!350 = !DISubroutineType(types: !351)
!351 = !{null, !7}
!352 = !{!353}
!353 = !DILocalVariable(name: "timer", arg: 1, scope: !349, file: !231, line: 75, type: !7)
!354 = !DILocation(line: 0, scope: !349)
!355 = !DILocation(line: 77, column: 2, scope: !349)
!356 = !DILocation(line: 83, column: 43, scope: !357)
!357 = distinct !DILexicalBlock(scope: !349, file: !231, line: 78, column: 2)
!358 = !DILocation(line: 86, column: 43, scope: !357)
!359 = !DILocation(line: 94, column: 43, scope: !357)
!360 = !DILocation(line: 98, column: 43, scope: !357)
!361 = !DILocation(line: 101, column: 43, scope: !357)
!362 = !DILocation(line: 104, column: 43, scope: !357)
!363 = !DILocation(line: 108, column: 43, scope: !357)
!364 = !DILocation(line: 111, column: 43, scope: !357)
!365 = !DILocation(line: 114, column: 43, scope: !357)
!366 = !DILocation(line: 118, column: 43, scope: !357)
!367 = !DILocation(line: 121, column: 43, scope: !357)
!368 = !DILocation(line: 124, column: 43, scope: !357)
!369 = !DILocation(line: 131, column: 43, scope: !357)
!370 = !DILocation(line: 132, column: 43, scope: !357)
!371 = !DILocation(line: 133, column: 43, scope: !357)
!372 = !DILocation(line: 0, scope: !357)
!373 = !DILocation(line: 136, column: 1, scope: !349)
!374 = distinct !DISubprogram(name: "serialEvent", linkageName: "_Z11serialEventv", scope: !375, file: !375, line: 48, type: !92, scopeLine: 48, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49)
!375 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/HardwareSerial.cpp", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "5c2790dc3d3fc22ab0920c4c2fd9aef6")
!376 = !DILocation(line: 48, column: 24, scope: !374)
!377 = distinct !DISubprogram(name: "Serial0_available", linkageName: "_Z17Serial0_availablev", scope: !375, file: !375, line: 49, type: !378, scopeLine: 49, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49)
!378 = !DISubroutineType(types: !379)
!379 = !{!380}
!380 = !DIBasicType(name: "bool", size: 8, encoding: DW_ATE_boolean)
!381 = !DILocation(line: 49, column: 30, scope: !377)
!382 = distinct !DISubprogram(name: "serialEvent1", linkageName: "_Z12serialEvent1v", scope: !375, file: !375, line: 56, type: !92, scopeLine: 56, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49)
!383 = !DILocation(line: 56, column: 25, scope: !382)
!384 = distinct !DISubprogram(name: "Serial1_available", linkageName: "_Z17Serial1_availablev", scope: !375, file: !375, line: 57, type: !378, scopeLine: 57, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49)
!385 = !DILocation(line: 57, column: 30, scope: !384)
!386 = distinct !DISubprogram(name: "serialEvent2", linkageName: "_Z12serialEvent2v", scope: !375, file: !375, line: 64, type: !92, scopeLine: 64, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49)
!387 = !DILocation(line: 64, column: 25, scope: !386)
!388 = distinct !DISubprogram(name: "Serial2_available", linkageName: "_Z17Serial2_availablev", scope: !375, file: !375, line: 65, type: !378, scopeLine: 65, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49)
!389 = !DILocation(line: 65, column: 30, scope: !388)
!390 = distinct !DISubprogram(name: "serialEvent3", linkageName: "_Z12serialEvent3v", scope: !375, file: !375, line: 72, type: !92, scopeLine: 72, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49)
!391 = !DILocation(line: 72, column: 25, scope: !390)
!392 = distinct !DISubprogram(name: "Serial3_available", linkageName: "_Z17Serial3_availablev", scope: !375, file: !375, line: 73, type: !378, scopeLine: 73, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49)
!393 = !DILocation(line: 73, column: 30, scope: !392)
!394 = distinct !DISubprogram(name: "serialEventRun", linkageName: "_Z14serialEventRunv", scope: !375, file: !375, line: 76, type: !92, scopeLine: 77, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !49)
!395 = !DILocation(line: 79, column: 7, scope: !396)
!396 = distinct !DILexicalBlock(scope: !394, file: !375, line: 79, column: 7)
!397 = !DILocation(line: 79, column: 25, scope: !396)
!398 = !DILocation(line: 79, column: 43, scope: !396)
!399 = !DILocation(line: 79, column: 40, scope: !396)
!400 = !DILocation(line: 79, column: 64, scope: !396)
!401 = !DILocation(line: 82, column: 7, scope: !402)
!402 = distinct !DILexicalBlock(scope: !394, file: !375, line: 82, column: 7)
!403 = !DILocation(line: 82, column: 25, scope: !402)
!404 = !DILocation(line: 82, column: 44, scope: !402)
!405 = !DILocation(line: 82, column: 41, scope: !402)
!406 = !DILocation(line: 82, column: 65, scope: !402)
!407 = !DILocation(line: 85, column: 7, scope: !408)
!408 = distinct !DILexicalBlock(scope: !394, file: !375, line: 85, column: 7)
!409 = !DILocation(line: 85, column: 25, scope: !408)
!410 = !DILocation(line: 85, column: 44, scope: !408)
!411 = !DILocation(line: 85, column: 41, scope: !408)
!412 = !DILocation(line: 85, column: 65, scope: !408)
!413 = !DILocation(line: 88, column: 7, scope: !414)
!414 = distinct !DILexicalBlock(scope: !394, file: !375, line: 88, column: 7)
!415 = !DILocation(line: 88, column: 25, scope: !414)
!416 = !DILocation(line: 88, column: 44, scope: !414)
!417 = !DILocation(line: 88, column: 41, scope: !414)
!418 = !DILocation(line: 88, column: 65, scope: !414)
!419 = !DILocation(line: 90, column: 1, scope: !394)
!420 = distinct !DISubprogram(name: "__empty", scope: !421, file: !421, line: 28, type: !92, scopeLine: 28, flags: DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !81)
!421 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/hooks.c", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "a13a341b0b6939f30312b1fbabff8511")
!422 = !DILocation(line: 30, column: 1, scope: !420)
