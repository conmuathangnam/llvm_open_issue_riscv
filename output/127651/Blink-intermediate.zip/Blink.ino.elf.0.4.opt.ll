; ModuleID = 'Blink.ino.elf.0.4.opt.bc'
source_filename = "ld-temp.o"
target datalayout = "e-P1-p:16:8-i8:8-i16:8-i32:8-i64:8-f32:8-f64:8-n8-a:8"
target triple = "avr"

@timer0_overflow_count = internal global i32 0, align 1, !dbg !0
@timer0_millis = internal global i32 0, align 1, !dbg !13
@timer0_fract = internal unnamed_addr global i8 0, align 1, !dbg !18
@port_to_mode_PGM = internal constant [13 x i16] [i16 0, i16 33, i16 36, i16 39, i16 42, i16 45, i16 48, i16 51, i16 257, i16 0, i16 260, i16 263, i16 266], section ".progmem1.data", align 1, !dbg !20
@port_to_output_PGM = internal constant [13 x i16] [i16 0, i16 34, i16 37, i16 40, i16 43, i16 46, i16 49, i16 52, i16 258, i16 0, i16 261, i16 264, i16 267], section ".progmem1.data", align 1, !dbg !26
@digital_pin_to_port_PGM = internal constant [70 x i8] c"\05\05\05\05\07\05\08\08\08\08\02\02\02\02\0A\0A\08\08\04\04\04\04\01\01\01\01\01\01\01\01\03\03\03\03\03\03\03\03\04\07\07\07\0C\0C\0C\0C\0C\0C\0C\0C\02\02\02\02\06\06\06\06\06\06\06\06\0B\0B\0B\0B\0B\0B\0B\0B", section ".progmem1.data", align 1, !dbg !35
@digital_pin_to_bit_mask_PGM = internal constant [70 x i8] c"\01\02\10  \08\08\10 @\10 @\80\02\01\02\01\08\04\02\01\01\02\04\08\10 @\80\80@ \10\08\04\02\01\80\04\02\01\80@ \10\08\04\02\01\08\04\02\01\01\02\04\08\10 @\80\01\02\04\08\10 @\80", section ".progmem1.data", align 1, !dbg !41
@digital_pin_to_timer_PGM = internal constant <{ [47 x i8], [23 x i8] }> <{ [47 x i8] c"\00\00\0A\0B\02\09\0C\0D\0E\08\07\03\04\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\12\11\10", [23 x i8] zeroinitializer }>, section ".progmem1.data", align 1, !dbg !43
@llvm.compiler.used = appending global [1 x ptr] [ptr addrspacecast (ptr addrspace(1) @__vector_23 to ptr)], section "llvm.metadata"

; Function Attrs: norecurse noreturn nounwind optsize
define dso_local noundef i16 @main() local_unnamed_addr addrspace(1) #0 !dbg !90 {
entry:
  tail call addrspace(0) void asm sideeffect "sei", "~{memory}"() #3, !dbg !95, !srcloc !100
  %0 = load volatile i8, ptr inttoptr (i16 68 to ptr), align 4, !dbg !101, !tbaa !102
  %1 = or i8 %0, 2, !dbg !101
  store volatile i8 %1, ptr inttoptr (i16 68 to ptr), align 4, !dbg !101, !tbaa !102
  %2 = load volatile i8, ptr inttoptr (i16 68 to ptr), align 4, !dbg !105, !tbaa !102
  %3 = or i8 %2, 1, !dbg !105
  store volatile i8 %3, ptr inttoptr (i16 68 to ptr), align 4, !dbg !105, !tbaa !102
  %4 = load volatile i8, ptr inttoptr (i16 69 to ptr), align 1, !dbg !106, !tbaa !102
  %5 = or i8 %4, 2, !dbg !106
  store volatile i8 %5, ptr inttoptr (i16 69 to ptr), align 1, !dbg !106, !tbaa !102
  %6 = load volatile i8, ptr inttoptr (i16 69 to ptr), align 1, !dbg !107, !tbaa !102
  %7 = or i8 %6, 1, !dbg !107
  store volatile i8 %7, ptr inttoptr (i16 69 to ptr), align 1, !dbg !107, !tbaa !102
  %8 = load volatile i8, ptr inttoptr (i16 110 to ptr), align 2, !dbg !108, !tbaa !102
  %9 = or i8 %8, 1, !dbg !108
  store volatile i8 %9, ptr inttoptr (i16 110 to ptr), align 2, !dbg !108, !tbaa !102
  store volatile i8 0, ptr inttoptr (i16 129 to ptr), align 1, !dbg !109, !tbaa !102
  %10 = load volatile i8, ptr inttoptr (i16 129 to ptr), align 1, !dbg !110, !tbaa !102
  %11 = or i8 %10, 2, !dbg !110
  store volatile i8 %11, ptr inttoptr (i16 129 to ptr), align 1, !dbg !110, !tbaa !102
  %12 = load volatile i8, ptr inttoptr (i16 129 to ptr), align 1, !dbg !111, !tbaa !102
  %13 = or i8 %12, 1, !dbg !111
  store volatile i8 %13, ptr inttoptr (i16 129 to ptr), align 1, !dbg !111, !tbaa !102
  %14 = load volatile i8, ptr inttoptr (i16 128 to ptr), align 128, !dbg !112, !tbaa !102
  %15 = or i8 %14, 1, !dbg !112
  store volatile i8 %15, ptr inttoptr (i16 128 to ptr), align 128, !dbg !112, !tbaa !102
  %16 = load volatile i8, ptr inttoptr (i16 177 to ptr), align 1, !dbg !113, !tbaa !102
  %17 = or i8 %16, 4, !dbg !113
  store volatile i8 %17, ptr inttoptr (i16 177 to ptr), align 1, !dbg !113, !tbaa !102
  %18 = load volatile i8, ptr inttoptr (i16 176 to ptr), align 16, !dbg !114, !tbaa !102
  %19 = or i8 %18, 1, !dbg !114
  store volatile i8 %19, ptr inttoptr (i16 176 to ptr), align 16, !dbg !114, !tbaa !102
  %20 = load volatile i8, ptr inttoptr (i16 145 to ptr), align 1, !dbg !115, !tbaa !102
  %21 = or i8 %20, 2, !dbg !115
  store volatile i8 %21, ptr inttoptr (i16 145 to ptr), align 1, !dbg !115, !tbaa !102
  %22 = load volatile i8, ptr inttoptr (i16 145 to ptr), align 1, !dbg !116, !tbaa !102
  %23 = or i8 %22, 1, !dbg !116
  store volatile i8 %23, ptr inttoptr (i16 145 to ptr), align 1, !dbg !116, !tbaa !102
  %24 = load volatile i8, ptr inttoptr (i16 144 to ptr), align 16, !dbg !117, !tbaa !102
  %25 = or i8 %24, 1, !dbg !117
  store volatile i8 %25, ptr inttoptr (i16 144 to ptr), align 16, !dbg !117, !tbaa !102
  %26 = load volatile i8, ptr inttoptr (i16 161 to ptr), align 1, !dbg !118, !tbaa !102
  %27 = or i8 %26, 2, !dbg !118
  store volatile i8 %27, ptr inttoptr (i16 161 to ptr), align 1, !dbg !118, !tbaa !102
  %28 = load volatile i8, ptr inttoptr (i16 161 to ptr), align 1, !dbg !119, !tbaa !102
  %29 = or i8 %28, 1, !dbg !119
  store volatile i8 %29, ptr inttoptr (i16 161 to ptr), align 1, !dbg !119, !tbaa !102
  %30 = load volatile i8, ptr inttoptr (i16 160 to ptr), align 32, !dbg !120, !tbaa !102
  %31 = or i8 %30, 1, !dbg !120
  store volatile i8 %31, ptr inttoptr (i16 160 to ptr), align 32, !dbg !120, !tbaa !102
  %32 = load volatile i8, ptr inttoptr (i16 289 to ptr), align 1, !dbg !121, !tbaa !102
  %33 = or i8 %32, 2, !dbg !121
  store volatile i8 %33, ptr inttoptr (i16 289 to ptr), align 1, !dbg !121, !tbaa !102
  %34 = load volatile i8, ptr inttoptr (i16 289 to ptr), align 1, !dbg !122, !tbaa !102
  %35 = or i8 %34, 1, !dbg !122
  store volatile i8 %35, ptr inttoptr (i16 289 to ptr), align 1, !dbg !122, !tbaa !102
  %36 = load volatile i8, ptr inttoptr (i16 288 to ptr), align 32, !dbg !123, !tbaa !102
  %37 = or i8 %36, 1, !dbg !123
  store volatile i8 %37, ptr inttoptr (i16 288 to ptr), align 32, !dbg !123, !tbaa !102
  %38 = load volatile i8, ptr inttoptr (i16 122 to ptr), align 2, !dbg !124, !tbaa !102
  %39 = or i8 %38, 4, !dbg !124
  store volatile i8 %39, ptr inttoptr (i16 122 to ptr), align 2, !dbg !124, !tbaa !102
  %40 = load volatile i8, ptr inttoptr (i16 122 to ptr), align 2, !dbg !125, !tbaa !102
  %41 = or i8 %40, 2, !dbg !125
  store volatile i8 %41, ptr inttoptr (i16 122 to ptr), align 2, !dbg !125, !tbaa !102
  %42 = load volatile i8, ptr inttoptr (i16 122 to ptr), align 2, !dbg !126, !tbaa !102
  %43 = or i8 %42, 1, !dbg !126
  store volatile i8 %43, ptr inttoptr (i16 122 to ptr), align 2, !dbg !126, !tbaa !102
  %44 = load volatile i8, ptr inttoptr (i16 122 to ptr), align 2, !dbg !127, !tbaa !102
  %45 = or i8 %44, -128, !dbg !127
  store volatile i8 %45, ptr inttoptr (i16 122 to ptr), align 2, !dbg !127, !tbaa !102
  store volatile i8 0, ptr inttoptr (i16 193 to ptr), align 1, !dbg !128, !tbaa !102
    #dbg_value(i8 13, !129, !DIExpression(), !160)
    #dbg_value(i8 1, !135, !DIExpression(), !160)
    #dbg_value(i16 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @digital_pin_to_bit_mask_PGM, i16 13) to i16), !137, !DIExpression(), !165)
  %46 = tail call addrspace(0) i8 asm sideeffect "lpm $0,${1:a}", "=r,z"(i16 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @digital_pin_to_bit_mask_PGM, i16 13) to i16)) #3, !dbg !166, !srcloc !167
    #dbg_value(i8 %46, !139, !DIExpression(), !165)
    #dbg_value(i8 %46, !136, !DIExpression(), !160)
    #dbg_value(i16 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @digital_pin_to_port_PGM, i16 13) to i16), !141, !DIExpression(), !168)
  %47 = tail call addrspace(0) i8 asm sideeffect "lpm $0,${1:a}", "=r,z"(i16 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @digital_pin_to_port_PGM, i16 13) to i16)) #3, !dbg !169, !srcloc !170
    #dbg_value(i8 %47, !143, !DIExpression(), !168)
    #dbg_value(i8 %47, !140, !DIExpression(), !160)
  %cmp.i.i = icmp eq i8 %47, 0, !dbg !171
  br i1 %cmp.i.i, label %for.cond.preheader, label %if.end.i.i, !dbg !171

if.end.i.i:                                       ; preds = %entry
  %conv6.i.i = zext i8 %47 to i16, !dbg !173
  %add.ptr10.i.i = getelementptr inbounds nuw i16, ptr @port_to_mode_PGM, i16 %conv6.i.i, !dbg !174
  %48 = ptrtoint ptr %add.ptr10.i.i to i16, !dbg !174
    #dbg_value(i16 %48, !146, !DIExpression(), !175)
  %49 = tail call addrspace(0) { i16, i16 } asm sideeffect "lpm ${0:A},${1:a}+\0A\09lpm ${0:B},${1:a}+", "=r,=z,1"(i16 %48) #3, !dbg !174, !srcloc !176
    #dbg_value(i16 poison, !148, !DIExpression(), !175)
    #dbg_value(i16 poison, !146, !DIExpression(), !175)
    #dbg_value(i16 poison, !144, !DIExpression(), !160)
  %add.ptr16.i.i = getelementptr inbounds nuw i16, ptr @port_to_output_PGM, i16 %conv6.i.i, !dbg !177
  %50 = ptrtoint ptr %add.ptr16.i.i to i16, !dbg !177
    #dbg_value(i16 %50, !149, !DIExpression(), !178)
  %51 = tail call addrspace(0) { i16, i16 } asm sideeffect "lpm ${0:A},${1:a}+\0A\09lpm ${0:B},${1:a}+", "=r,=z,1"(i16 %50) #3, !dbg !177, !srcloc !179
    #dbg_value(i16 poison, !151, !DIExpression(), !178)
    #dbg_value(i16 poison, !149, !DIExpression(), !178)
    #dbg_value(i16 poison, !145, !DIExpression(), !160)
  %52 = load volatile i8, ptr inttoptr (i16 95 to ptr), align 1, !dbg !180, !tbaa !102
  tail call addrspace(0) void asm sideeffect "cli", "~{memory}"() #3, !dbg !180
  %asmresult.i.i = extractvalue { i16, i16 } %49, 0, !dbg !174
    #dbg_value(i16 %asmresult.i.i, !148, !DIExpression(), !175)
    #dbg_value(i16 %asmresult.i.i, !144, !DIExpression(), !160)
  %53 = inttoptr i16 %asmresult.i.i to ptr, !dbg !181
    #dbg_value(ptr %53, !144, !DIExpression(), !160)
    #dbg_value(i8 %52, !158, !DIExpression(), !182)
  %54 = load volatile i8, ptr %53, align 1, !dbg !183, !tbaa !102
  %or5068.i.i = or i8 %54, %46, !dbg !183
  store volatile i8 %or5068.i.i, ptr %53, align 1, !dbg !183, !tbaa !102
  store volatile i8 %52, ptr inttoptr (i16 95 to ptr), align 1, !dbg !180, !tbaa !102
  br label %for.cond.preheader, !dbg !184

for.cond.preheader:                               ; preds = %if.end.i.i, %entry
  br label %for.cond, !dbg !185

for.cond:                                         ; preds = %for.cond, %for.cond.preheader
  tail call fastcc addrspace(1) void @digitalWrite(i8 noundef zeroext 1) #4, !dbg !187
  tail call fastcc addrspace(1) void @delay() #4, !dbg !192
  tail call fastcc addrspace(1) void @digitalWrite(i8 noundef zeroext 0) #4, !dbg !193
  tail call fastcc addrspace(1) void @delay() #4, !dbg !194
  br label %for.cond, !dbg !195, !llvm.loop !196
}

; Function Attrs: nofree norecurse nounwind optsize memory(readwrite, argmem: none)
define dso_local void @__vector_23() addrspace(1) #1 !dbg !199 {
entry:
  %0 = load volatile i32, ptr @timer0_millis, align 1, !dbg !203, !tbaa !204
    #dbg_value(i32 %0, !201, !DIExpression(), !206)
  %1 = load i8, ptr @timer0_fract, align 1, !dbg !207, !tbaa !102
    #dbg_value(i8 %1, !202, !DIExpression(), !206)
    #dbg_value(i32 %0, !201, !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value), !206)
  %add1 = add i8 %1, 3, !dbg !208
    #dbg_value(i8 %add1, !202, !DIExpression(), !206)
  %cmp = icmp ugt i8 %add1, 124, !dbg !209
  %sub = add i8 %1, -122, !dbg !209
  %m.0.v = select i1 %cmp, i32 2, i32 1, !dbg !209
  %m.0 = add i32 %m.0.v, %0, !dbg !209
  %f.0 = select i1 %cmp, i8 %sub, i8 %add1, !dbg !209
    #dbg_value(i8 %f.0, !202, !DIExpression(), !206)
    #dbg_value(i32 %m.0, !201, !DIExpression(), !206)
  store i8 %f.0, ptr @timer0_fract, align 1, !dbg !211, !tbaa !102
  store volatile i32 %m.0, ptr @timer0_millis, align 1, !dbg !212, !tbaa !204
  %2 = load volatile i32, ptr @timer0_overflow_count, align 1, !dbg !213, !tbaa !204
  %inc = add i32 %2, 1, !dbg !213
  store volatile i32 %inc, ptr @timer0_overflow_count, align 1, !dbg !213, !tbaa !204
  ret void, !dbg !214
}

; Function Attrs: norecurse nounwind optsize
define internal fastcc void @delay() unnamed_addr addrspace(1) #2 !dbg !215 {
while.body.preheader:
    #dbg_value(i32 1000, !219, !DIExpression(), !222)
  %0 = load volatile i8, ptr inttoptr (i16 95 to ptr), align 1, !dbg !223, !tbaa !102
    #dbg_value(i8 %0, !229, !DIExpression(), !232)
  tail call addrspace(0) void asm sideeffect "cli", "~{memory}"() #3, !dbg !233, !srcloc !234
  %1 = load volatile i32, ptr @timer0_overflow_count, align 1, !dbg !235, !tbaa !204
    #dbg_value(i32 %1, !228, !DIExpression(), !232)
  %2 = load volatile i8, ptr inttoptr (i16 70 to ptr), align 2, !dbg !236, !tbaa !102
    #dbg_value(i8 %2, !230, !DIExpression(), !232)
  %3 = load volatile i8, ptr inttoptr (i16 53 to ptr), align 1, !dbg !237, !tbaa !102
    #dbg_value(!DIArgList(i32 poison, i1 poison), !228, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_plus, DW_OP_stack_value), !232)
  store volatile i8 %0, ptr inttoptr (i16 95 to ptr), align 1, !dbg !239, !tbaa !102
    #dbg_value(!DIArgList(i32 poison, i8 poison, i1 poison), !220, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_plus, DW_OP_constu, 10, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_or, DW_OP_stack_value), !222)
  %4 = and i8 %3, 1, !dbg !240
  %tobool.not.i = icmp ne i8 %4, 0, !dbg !240
  %cmp.not.i = icmp ne i8 %2, -1
  %or.cond.not.i = select i1 %tobool.not.i, i1 %cmp.not.i, i1 false, !dbg !241
    #dbg_value(!DIArgList(i32 %1, i1 %or.cond.not.i), !228, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_plus, DW_OP_stack_value), !232)
    #dbg_value(!DIArgList(i32 %1, i8 %2, i1 %or.cond.not.i), !220, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 2, DW_OP_LLVM_convert, 1, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_plus, DW_OP_constu, 10, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_or, DW_OP_stack_value), !222)
  %inc.i = zext i1 %or.cond.not.i to i32, !dbg !241
    #dbg_value(!DIArgList(i32 %1, i32 %inc.i), !228, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_plus, DW_OP_stack_value), !232)
    #dbg_value(!DIArgList(i32 %1, i8 %2, i32 %inc.i), !220, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 2, DW_OP_plus, DW_OP_constu, 10, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_or, DW_OP_stack_value), !222)
  %m.0.i = add i32 %1, %inc.i, !dbg !241
    #dbg_value(i32 %m.0.i, !228, !DIExpression(), !232)
    #dbg_value(!DIArgList(i32 %m.0.i, i8 %2), !220, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 10, DW_OP_shl, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_or, DW_OP_stack_value), !222)
  %5 = shl i32 %m.0.i, 10, !dbg !242
    #dbg_value(!DIArgList(i32 %5, i8 %2), !220, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 8, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2, DW_OP_shl, DW_OP_or, DW_OP_stack_value), !222)
  %conv3.i = zext i8 %2 to i32, !dbg !243
    #dbg_value(!DIArgList(i32 %5, i32 %conv3.i), !220, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_constu, 2, DW_OP_shl, DW_OP_or, DW_OP_stack_value), !222)
  %6 = shl nuw nsw i32 %conv3.i, 2, !dbg !242
    #dbg_value(!DIArgList(i32 %5, i32 %6), !220, !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value), !222)
  %mul.i = or disjoint i32 %5, %6, !dbg !242
    #dbg_value(i32 %mul.i, !220, !DIExpression(), !222)
  br label %land.rhs.outer, !dbg !244

land.rhs.outer:                                   ; preds = %while.body5, %while.body.preheader
  %start.118.ph = phi i32 [ %mul.i, %while.body.preheader ], [ %add, %while.body5 ]
  %ms.addr.117.ph = phi i32 [ 1000, %while.body.preheader ], [ %dec, %while.body5 ]
  br label %land.rhs, !dbg !245

land.rhs:                                         ; preds = %land.rhs, %land.rhs.outer
    #dbg_value(i32 %start.118.ph, !220, !DIExpression(), !222)
    #dbg_value(i32 %ms.addr.117.ph, !219, !DIExpression(), !222)
  %7 = load volatile i8, ptr inttoptr (i16 95 to ptr), align 1, !dbg !247, !tbaa !102
    #dbg_value(i8 %7, !229, !DIExpression(), !249)
  tail call addrspace(0) void asm sideeffect "cli", "~{memory}"() #3, !dbg !250, !srcloc !234
  %8 = load volatile i32, ptr @timer0_overflow_count, align 1, !dbg !251, !tbaa !204
    #dbg_value(i32 %8, !228, !DIExpression(), !249)
  %9 = load volatile i8, ptr inttoptr (i16 70 to ptr), align 2, !dbg !252, !tbaa !102
    #dbg_value(i8 %9, !230, !DIExpression(), !249)
  %10 = load volatile i8, ptr inttoptr (i16 53 to ptr), align 1, !dbg !253, !tbaa !102
  %11 = and i8 %10, 1, !dbg !254
  %tobool.not.i10 = icmp ne i8 %11, 0, !dbg !254
  %cmp.not.i11 = icmp ne i8 %9, -1
  %or.cond.not.i12 = select i1 %tobool.not.i10, i1 %cmp.not.i11, i1 false, !dbg !255
  %inc.i13 = zext i1 %or.cond.not.i12 to i32, !dbg !255
  %m.0.i14 = add i32 %8, %inc.i13, !dbg !255
    #dbg_value(i32 %m.0.i14, !228, !DIExpression(), !249)
  store volatile i8 %7, ptr inttoptr (i16 95 to ptr), align 1, !dbg !256, !tbaa !102
  %conv3.i15 = zext i8 %9 to i32, !dbg !257
  %12 = shl i32 %m.0.i14, 10, !dbg !258
  %13 = shl nuw nsw i32 %conv3.i15, 2, !dbg !258
  %mul.i16 = sub i32 %13, %start.118.ph, !dbg !258
  %sub = add i32 %mul.i16, %12, !dbg !259
  %cmp4 = icmp ugt i32 %sub, 999, !dbg !260
  br i1 %cmp4, label %while.body5, label %land.rhs, !dbg !245, !llvm.loop !261

while.body5:                                      ; preds = %land.rhs
  %dec = add i32 %ms.addr.117.ph, -1, !dbg !263
    #dbg_value(i32 %dec, !219, !DIExpression(), !222)
  %add = add i32 %start.118.ph, 1000, !dbg !265
    #dbg_value(i32 %add, !220, !DIExpression(), !222)
  %cmp2.not = icmp eq i32 %dec, 0, !dbg !266
  br i1 %cmp2.not, label %while.end6, label %land.rhs.outer, !dbg !267, !llvm.loop !268

while.end6:                                       ; preds = %while.body5
  ret void, !dbg !270
}

; Function Attrs: norecurse nounwind optsize
define internal fastcc void @digitalWrite(i8 noundef zeroext range(i8 0, 2) %val) unnamed_addr addrspace(1) #2 !dbg !271 {
entry:
    #dbg_value(i8 13, !273, !DIExpression(), !292)
    #dbg_value(i8 %val, !274, !DIExpression(), !292)
    #dbg_value(i16 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @digital_pin_to_timer_PGM, i16 13) to i16), !276, !DIExpression(), !293)
  %0 = tail call addrspace(0) i8 asm sideeffect "lpm $0,${1:a}", "=r,z"(i16 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @digital_pin_to_timer_PGM, i16 13) to i16)) #3, !dbg !294, !srcloc !295
    #dbg_value(i8 %0, !278, !DIExpression(), !293)
    #dbg_value(i8 %0, !275, !DIExpression(), !292)
    #dbg_value(i16 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @digital_pin_to_bit_mask_PGM, i16 13) to i16), !280, !DIExpression(), !296)
  %1 = tail call addrspace(0) i8 asm sideeffect "lpm $0,${1:a}", "=r,z"(i16 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @digital_pin_to_bit_mask_PGM, i16 13) to i16)) #3, !dbg !297, !srcloc !298
    #dbg_value(i8 %1, !282, !DIExpression(), !296)
    #dbg_value(i8 %1, !279, !DIExpression(), !292)
    #dbg_value(i16 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @digital_pin_to_port_PGM, i16 13) to i16), !284, !DIExpression(), !299)
  %2 = tail call addrspace(0) i8 asm sideeffect "lpm $0,${1:a}", "=r,z"(i16 ptrtoint (ptr getelementptr inbounds nuw (i8, ptr @digital_pin_to_port_PGM, i16 13) to i16)) #3, !dbg !300, !srcloc !301
    #dbg_value(i8 %2, !286, !DIExpression(), !299)
    #dbg_value(i8 %2, !283, !DIExpression(), !292)
  %conv11 = zext i8 %2 to i16, !dbg !302
  %cmp = icmp eq i8 %2, 0, !dbg !304
  br i1 %cmp, label %cleanup, label %if.end, !dbg !304

if.end:                                           ; preds = %entry
  switch i8 %0, label %if.end17 [
    i8 18, label %sw.bb59.i
    i8 3, label %sw.epilog.sink.split.i
    i8 4, label %sw.bb3.i
    i8 5, label %sw.bb7.i
    i8 1, label %sw.bb11.i
    i8 2, label %sw.bb15.i
    i8 7, label %sw.bb19.i
    i8 8, label %sw.bb23.i
    i8 9, label %sw.bb27.i
    i8 10, label %sw.bb31.i
    i8 11, label %sw.bb35.i
    i8 12, label %sw.bb39.i
    i8 13, label %sw.bb43.i
    i8 14, label %sw.bb47.i
    i8 16, label %sw.bb51.i
    i8 17, label %sw.bb55.i
  ], !dbg !305

sw.bb3.i:                                         ; preds = %if.end
  br label %sw.epilog.sink.split.i, !dbg !307

sw.bb7.i:                                         ; preds = %if.end
  br label %sw.epilog.sink.split.i, !dbg !315

sw.bb11.i:                                        ; preds = %if.end
  br label %sw.epilog.sink.split.i, !dbg !316

sw.bb15.i:                                        ; preds = %if.end
  br label %sw.epilog.sink.split.i, !dbg !317

sw.bb19.i:                                        ; preds = %if.end
  br label %sw.epilog.sink.split.i, !dbg !318

sw.bb23.i:                                        ; preds = %if.end
  br label %sw.epilog.sink.split.i, !dbg !319

sw.bb27.i:                                        ; preds = %if.end
  br label %sw.epilog.sink.split.i, !dbg !320

sw.bb31.i:                                        ; preds = %if.end
  br label %sw.epilog.sink.split.i, !dbg !321

sw.bb35.i:                                        ; preds = %if.end
  br label %sw.epilog.sink.split.i, !dbg !322

sw.bb39.i:                                        ; preds = %if.end
  br label %sw.epilog.sink.split.i, !dbg !323

sw.bb43.i:                                        ; preds = %if.end
  br label %sw.epilog.sink.split.i, !dbg !324

sw.bb47.i:                                        ; preds = %if.end
  br label %sw.epilog.sink.split.i, !dbg !325

sw.bb51.i:                                        ; preds = %if.end
  br label %sw.epilog.sink.split.i, !dbg !326

sw.bb55.i:                                        ; preds = %if.end
  br label %sw.epilog.sink.split.i, !dbg !327

sw.bb59.i:                                        ; preds = %if.end
  br label %sw.epilog.sink.split.i, !dbg !328

sw.epilog.sink.split.i:                           ; preds = %sw.bb59.i, %sw.bb55.i, %sw.bb51.i, %sw.bb47.i, %sw.bb43.i, %sw.bb39.i, %sw.bb35.i, %sw.bb31.i, %sw.bb27.i, %sw.bb23.i, %sw.bb19.i, %sw.bb15.i, %sw.bb11.i, %sw.bb7.i, %sw.bb3.i, %if.end
  %.sink.i = phi ptr [ inttoptr (i16 288 to ptr), %sw.bb59.i ], [ inttoptr (i16 288 to ptr), %sw.bb55.i ], [ inttoptr (i16 288 to ptr), %sw.bb51.i ], [ inttoptr (i16 160 to ptr), %sw.bb47.i ], [ inttoptr (i16 160 to ptr), %sw.bb43.i ], [ inttoptr (i16 160 to ptr), %sw.bb39.i ], [ inttoptr (i16 144 to ptr), %sw.bb35.i ], [ inttoptr (i16 144 to ptr), %sw.bb31.i ], [ inttoptr (i16 144 to ptr), %sw.bb27.i ], [ inttoptr (i16 176 to ptr), %sw.bb23.i ], [ inttoptr (i16 176 to ptr), %sw.bb19.i ], [ inttoptr (i16 68 to ptr), %sw.bb15.i ], [ inttoptr (i16 68 to ptr), %sw.bb11.i ], [ inttoptr (i16 128 to ptr), %sw.bb7.i ], [ inttoptr (i16 128 to ptr), %sw.bb3.i ], [ inttoptr (i16 128 to ptr), %if.end ]
  %.sink65.i = phi i8 [ -9, %sw.bb59.i ], [ -33, %sw.bb55.i ], [ 127, %sw.bb51.i ], [ -9, %sw.bb47.i ], [ -33, %sw.bb43.i ], [ 127, %sw.bb39.i ], [ -9, %sw.bb35.i ], [ -33, %sw.bb31.i ], [ 127, %sw.bb27.i ], [ -33, %sw.bb23.i ], [ 127, %sw.bb19.i ], [ -33, %sw.bb15.i ], [ 127, %sw.bb11.i ], [ -9, %sw.bb7.i ], [ -33, %sw.bb3.i ], [ 127, %if.end ]
  %3 = load volatile i8, ptr %.sink.i, align 4, !dbg !329, !tbaa !102
  %4 = and i8 %3, %.sink65.i, !dbg !329
  store volatile i8 %4, ptr %.sink.i, align 4, !dbg !329, !tbaa !102
  br label %if.end17, !dbg !330

if.end17:                                         ; preds = %sw.epilog.sink.split.i, %if.end
  %add.ptr20 = getelementptr inbounds nuw i16, ptr @port_to_output_PGM, i16 %conv11, !dbg !331
  %5 = ptrtoint ptr %add.ptr20 to i16, !dbg !331
    #dbg_value(i16 %5, !288, !DIExpression(), !332)
  %6 = tail call addrspace(0) { i16, i16 } asm sideeffect "lpm ${0:A},${1:a}+\0A\09lpm ${0:B},${1:a}+", "=r,=z,1"(i16 %5) #3, !dbg !331, !srcloc !333
  %asmresult = extractvalue { i16, i16 } %6, 0, !dbg !331
    #dbg_value(i16 %asmresult, !290, !DIExpression(), !332)
    #dbg_value(i16 poison, !288, !DIExpression(), !332)
  %7 = inttoptr i16 %asmresult to ptr, !dbg !334
    #dbg_value(ptr %7, !287, !DIExpression(), !292)
  %8 = load volatile i8, ptr inttoptr (i16 95 to ptr), align 1, !dbg !335, !tbaa !102
    #dbg_value(i8 %8, !291, !DIExpression(), !292)
  tail call addrspace(0) void asm sideeffect "cli", "~{memory}"() #3, !dbg !336, !srcloc !337
  %cmp25 = icmp eq i8 %val, 0, !dbg !338
  br i1 %cmp25, label %if.then27, label %if.else, !dbg !338

if.then27:                                        ; preds = %if.end17
  %not = xor i8 %1, -1, !dbg !340
  %9 = load volatile i8, ptr %7, align 1, !dbg !342, !tbaa !102
  %and = and i8 %9, %not, !dbg !342
  br label %if.end34, !dbg !343

if.else:                                          ; preds = %if.end17
  %10 = load volatile i8, ptr %7, align 1, !dbg !344, !tbaa !102
  %or44 = or i8 %10, %1, !dbg !344
  br label %if.end34

if.end34:                                         ; preds = %if.else, %if.then27
  %or44.sink = phi i8 [ %or44, %if.else ], [ %and, %if.then27 ]
  store volatile i8 %or44.sink, ptr %7, align 1, !dbg !346, !tbaa !102
  store volatile i8 %8, ptr inttoptr (i16 95 to ptr), align 1, !dbg !347, !tbaa !102
  br label %cleanup, !dbg !348

cleanup:                                          ; preds = %if.end34, %entry
  ret void, !dbg !348
}

attributes #0 = { norecurse noreturn nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="atmega2560" }
attributes #1 = { nofree norecurse nounwind optsize memory(readwrite, argmem: none) "frame-pointer"="all" "no-trapping-math"="true" "signal" "stack-protector-buffer-size"="8" "target-cpu"="atmega2560" }
attributes #2 = { norecurse nounwind optsize "frame-pointer"="all" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="atmega2560" }
attributes #3 = { nounwind }
attributes #4 = { nounwind optsize }

!llvm.dbg.cu = !{!45, !47, !2, !22, !49, !54, !79, !81}
!llvm.ident = !{!83, !83, !83, !83, !83, !83, !83, !83}
!llvm.module.flags = !{!84, !85, !86, !87, !88, !89}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "timer0_overflow_count", scope: !2, file: !15, line: 38, type: !16, isLocal: false, isDefinition: true)
!2 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !4, globals: !12, splitDebugInlining: false, nameTableKind: None)
!3 = !DIFile(filename: "/home/dakkshesh/.arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/wiring.c", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "994415fa64a48bd96f4d61f0e982be72")
!4 = !{!5, !10}
!5 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 16)
!6 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !7)
!7 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint8_t", file: !8, line: 126, baseType: !9)
!8 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/tools/cba-avr-sysroot/12022025/lib/gcc/avr/14.2.0/../../../../avr/include/stdint.h", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "348d903c92cfc3abd32b2860a57bc71f")
!9 = !DIBasicType(name: "unsigned char", size: 8, encoding: DW_ATE_unsigned_char)
!10 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint16_t", file: !8, line: 128, baseType: !11)
!11 = !DIBasicType(name: "unsigned int", size: 16, encoding: DW_ATE_unsigned)
!12 = !{!0, !13, !18}
!13 = !DIGlobalVariableExpression(var: !14, expr: !DIExpression())
!14 = distinct !DIGlobalVariable(name: "timer0_millis", scope: !2, file: !15, line: 39, type: !16, isLocal: false, isDefinition: true)
!15 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/wiring.c", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "994415fa64a48bd96f4d61f0e982be72")
!16 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !17)
!17 = !DIBasicType(name: "unsigned long", size: 32, encoding: DW_ATE_unsigned)
!18 = !DIGlobalVariableExpression(var: !19, expr: !DIExpression())
!19 = distinct !DIGlobalVariable(name: "timer0_fract", scope: !2, file: !15, line: 40, type: !9, isLocal: true, isDefinition: true)
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(name: "port_to_mode_PGM", scope: !22, file: !28, line: 114, type: !29, isLocal: false, isDefinition: true)
!22 = distinct !DICompileUnit(language: DW_LANG_C11, file: !23, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !24, globals: !25, splitDebugInlining: false, nameTableKind: None)
!23 = !DIFile(filename: "/home/dakkshesh/.arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/wiring_digital.c", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "39c33a7b95d6d6678b30c1d00a612dd3")
!24 = !{!10, !5}
!25 = !{!20, !26, !33, !35, !41, !43}
!26 = !DIGlobalVariableExpression(var: !27, expr: !DIExpression())
!27 = distinct !DIGlobalVariable(name: "port_to_output_PGM", scope: !22, file: !28, line: 130, type: !29, isLocal: false, isDefinition: true)
!28 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/variants/mega/pins_arduino.h", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "998eebdbc89691f6a084383d393e1144")
!29 = !DICompositeType(tag: DW_TAG_array_type, baseType: !30, size: 208, elements: !31)
!30 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !10)
!31 = !{!32}
!32 = !DISubrange(count: 13)
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "port_to_input_PGM", scope: !22, file: !28, line: 146, type: !29, isLocal: false, isDefinition: true)
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "digital_pin_to_port_PGM", scope: !22, file: !28, line: 162, type: !37, isLocal: false, isDefinition: true)
!37 = !DICompositeType(tag: DW_TAG_array_type, baseType: !38, size: 560, elements: !39)
!38 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !7)
!39 = !{!40}
!40 = !DISubrange(count: 70)
!41 = !DIGlobalVariableExpression(var: !42, expr: !DIExpression())
!42 = distinct !DIGlobalVariable(name: "digital_pin_to_bit_mask_PGM", scope: !22, file: !28, line: 237, type: !37, isLocal: false, isDefinition: true)
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "digital_pin_to_timer_PGM", scope: !22, file: !28, line: 312, type: !37, isLocal: false, isDefinition: true)
!45 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_11, file: !46, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!46 = !DIFile(filename: "/home/dakkshesh/.cache/arduino/sketches/0A3424900B1B32407700B6A1409F8FE7/sketch/Blink.ino.cpp", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "2d2bf6bde7b076cad176b3c03737c627")
!47 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_11, file: !48, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!48 = !DIFile(filename: "/home/dakkshesh/.arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/main.cpp", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "e51b97ee7aa9b47fc852f0cf5785e5bb")
!49 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_11, file: !50, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !51, splitDebugInlining: false, nameTableKind: None)
!50 = !DIFile(filename: "/home/dakkshesh/.arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/HardwareSerial.cpp", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "5c2790dc3d3fc22ab0920c4c2fd9aef6")
!51 = !{!5, !10, !11, !52}
!52 = !DIDerivedType(tag: DW_TAG_typedef, name: "rx_buffer_index_t", file: !53, line: 64, baseType: !7)
!53 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/HardwareSerial.h", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "438cf3249079c995d56c243216bb9ad9")
!54 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_11, file: !55, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !56, globals: !63, splitDebugInlining: false, nameTableKind: None)
!55 = !DIFile(filename: "/home/dakkshesh/.arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/Print.cpp", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "ed8a582bc90c37e7b4edf417ff05c32c")
!56 = !{!57, !10, !17, !60, !61, !11, !62}
!57 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !58, size: 16)
!58 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !59)
!59 = !DIBasicType(name: "char", size: 8, encoding: DW_ATE_signed_char)
!60 = !DIBasicType(name: "long", size: 32, encoding: DW_ATE_signed)
!61 = !DIBasicType(name: "double", size: 32, encoding: DW_ATE_float)
!62 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !38, size: 16)
!63 = !{!64, !70, !75, !77}
!64 = !DIGlobalVariableExpression(var: !65, expr: !DIExpression())
!65 = distinct !DIGlobalVariable(scope: null, file: !66, line: 128, type: !67, isLocal: true, isDefinition: true)
!66 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/Print.cpp", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "ed8a582bc90c37e7b4edf417ff05c32c")
!67 = !DICompositeType(tag: DW_TAG_array_type, baseType: !58, size: 24, elements: !68)
!68 = !{!69}
!69 = !DISubrange(count: 3)
!70 = !DIGlobalVariableExpression(var: !71, expr: !DIExpression())
!71 = distinct !DIGlobalVariable(scope: null, file: !66, line: 227, type: !72, isLocal: true, isDefinition: true)
!72 = !DICompositeType(tag: DW_TAG_array_type, baseType: !58, size: 32, elements: !73)
!73 = !{!74}
!74 = !DISubrange(count: 4)
!75 = !DIGlobalVariableExpression(var: !76, expr: !DIExpression())
!76 = distinct !DIGlobalVariable(scope: null, file: !66, line: 228, type: !72, isLocal: true, isDefinition: true)
!77 = !DIGlobalVariableExpression(var: !78, expr: !DIExpression())
!78 = distinct !DIGlobalVariable(scope: null, file: !66, line: 229, type: !72, isLocal: true, isDefinition: true)
!79 = distinct !DICompileUnit(language: DW_LANG_C_plus_plus_11, file: !80, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!80 = !DIFile(filename: "/home/dakkshesh/.arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/abi.cpp", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "f183939813882133c44065b78cb69cc5")
!81 = distinct !DICompileUnit(language: DW_LANG_C11, file: !82, producer: "ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!82 = !DIFile(filename: "/home/dakkshesh/.arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/hooks.c", directory: "/home/dakkshesh/arduio-cbl", checksumkind: CSK_MD5, checksum: "a13a341b0b6939f30312b1fbabff8511")
!83 = !{!"ClangBuiltArduino clang version 21.0.0git (https://github.com/llvm/llvm-project.git febcf439852bd03b4c647b8a102cf541996c575e)"}
!84 = !{i32 7, !"Dwarf Version", i32 5}
!85 = !{i32 2, !"Debug Info Version", i32 3}
!86 = !{i32 1, !"wchar_size", i32 2}
!87 = !{i32 7, !"frame-pointer", i32 2}
!88 = !{i32 1, !"ThinLTO", i32 0}
!89 = !{i32 1, !"EnableSplitLTOUnit", i32 1}
!90 = distinct !DISubprogram(name: "main", scope: !91, file: !91, line: 33, type: !92, scopeLine: 34, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !47)
!91 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/main.cpp", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "e51b97ee7aa9b47fc852f0cf5785e5bb")
!92 = !DISubroutineType(types: !93)
!93 = !{!94}
!94 = !DIBasicType(name: "int", size: 16, encoding: DW_ATE_signed)
!95 = !DILocation(line: 245, column: 2, scope: !96, inlinedAt: !99)
!96 = distinct !DISubprogram(name: "init", scope: !15, file: !15, line: 241, type: !97, scopeLine: 242, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2)
!97 = !DISubroutineType(types: !98)
!98 = !{null}
!99 = distinct !DILocation(line: 35, column: 2, scope: !90)
!100 = !{i64 2148006943}
!101 = !DILocation(line: 251, column: 2, scope: !96, inlinedAt: !99)
!102 = !{!103, !103, i64 0}
!103 = !{!"omnipotent char", !104, i64 0}
!104 = !{!"Simple C/C++ TBAA"}
!105 = !DILocation(line: 252, column: 2, scope: !96, inlinedAt: !99)
!106 = !DILocation(line: 265, column: 2, scope: !96, inlinedAt: !99)
!107 = !DILocation(line: 266, column: 2, scope: !96, inlinedAt: !99)
!108 = !DILocation(line: 279, column: 2, scope: !96, inlinedAt: !99)
!109 = !DILocation(line: 290, column: 9, scope: !96, inlinedAt: !99)
!110 = !DILocation(line: 293, column: 2, scope: !96, inlinedAt: !99)
!111 = !DILocation(line: 295, column: 2, scope: !96, inlinedAt: !99)
!112 = !DILocation(line: 305, column: 2, scope: !96, inlinedAt: !99)
!113 = !DILocation(line: 312, column: 2, scope: !96, inlinedAt: !99)
!114 = !DILocation(line: 321, column: 2, scope: !96, inlinedAt: !99)
!115 = !DILocation(line: 327, column: 2, scope: !96, inlinedAt: !99)
!116 = !DILocation(line: 328, column: 2, scope: !96, inlinedAt: !99)
!117 = !DILocation(line: 329, column: 2, scope: !96, inlinedAt: !99)
!118 = !DILocation(line: 341, column: 2, scope: !96, inlinedAt: !99)
!119 = !DILocation(line: 342, column: 2, scope: !96, inlinedAt: !99)
!120 = !DILocation(line: 343, column: 2, scope: !96, inlinedAt: !99)
!121 = !DILocation(line: 348, column: 2, scope: !96, inlinedAt: !99)
!122 = !DILocation(line: 349, column: 2, scope: !96, inlinedAt: !99)
!123 = !DILocation(line: 350, column: 2, scope: !96, inlinedAt: !99)
!124 = !DILocation(line: 356, column: 3, scope: !96, inlinedAt: !99)
!125 = !DILocation(line: 357, column: 3, scope: !96, inlinedAt: !99)
!126 = !DILocation(line: 358, column: 3, scope: !96, inlinedAt: !99)
!127 = !DILocation(line: 381, column: 2, scope: !96, inlinedAt: !99)
!128 = !DILocation(line: 390, column: 9, scope: !96, inlinedAt: !99)
!129 = !DILocalVariable(name: "pin", arg: 1, scope: !130, file: !131, line: 29, type: !7)
!130 = distinct !DISubprogram(name: "pinMode", scope: !131, file: !131, line: 29, type: !132, scopeLine: 30, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !22, retainedNodes: !134)
!131 = !DIFile(filename: ".arduino15/packages/ClangBuiltArduino/hardware/avr/1.0.1/cores/arduino/wiring_digital.c", directory: "/home/dakkshesh", checksumkind: CSK_MD5, checksum: "39c33a7b95d6d6678b30c1d00a612dd3")
!132 = !DISubroutineType(cc: DW_CC_nocall, types: !133)
!133 = !{null, !7, !7}
!134 = !{!129, !135, !136, !137, !139, !140, !141, !143, !144, !145, !146, !148, !149, !151, !152, !155, !158}
!135 = !DILocalVariable(name: "mode", arg: 2, scope: !130, file: !131, line: 29, type: !7)
!136 = !DILocalVariable(name: "bit", scope: !130, file: !131, line: 31, type: !7)
!137 = !DILocalVariable(name: "__addr16", scope: !138, file: !131, line: 31, type: !10)
!138 = distinct !DILexicalBlock(scope: !130, file: !131, line: 31, column: 16)
!139 = !DILocalVariable(name: "__result", scope: !138, file: !131, line: 31, type: !7)
!140 = !DILocalVariable(name: "port", scope: !130, file: !131, line: 32, type: !7)
!141 = !DILocalVariable(name: "__addr16", scope: !142, file: !131, line: 32, type: !10)
!142 = distinct !DILexicalBlock(scope: !130, file: !131, line: 32, column: 17)
!143 = !DILocalVariable(name: "__result", scope: !142, file: !131, line: 32, type: !7)
!144 = !DILocalVariable(name: "reg", scope: !130, file: !131, line: 33, type: !5)
!145 = !DILocalVariable(name: "out", scope: !130, file: !131, line: 33, type: !5)
!146 = !DILocalVariable(name: "__addr16", scope: !147, file: !131, line: 38, type: !10)
!147 = distinct !DILexicalBlock(scope: !130, file: !131, line: 38, column: 8)
!148 = !DILocalVariable(name: "__result", scope: !147, file: !131, line: 38, type: !10)
!149 = !DILocalVariable(name: "__addr16", scope: !150, file: !131, line: 39, type: !10)
!150 = distinct !DILexicalBlock(scope: !130, file: !131, line: 39, column: 8)
!151 = !DILocalVariable(name: "__result", scope: !150, file: !131, line: 39, type: !10)
!152 = !DILocalVariable(name: "oldSREG", scope: !153, file: !131, line: 42, type: !7)
!153 = distinct !DILexicalBlock(scope: !154, file: !131, line: 41, column: 21)
!154 = distinct !DILexicalBlock(scope: !130, file: !131, line: 41, column: 6)
!155 = !DILocalVariable(name: "oldSREG", scope: !156, file: !131, line: 48, type: !7)
!156 = distinct !DILexicalBlock(scope: !157, file: !131, line: 47, column: 35)
!157 = distinct !DILexicalBlock(scope: !154, file: !131, line: 47, column: 13)
!158 = !DILocalVariable(name: "oldSREG", scope: !159, file: !131, line: 54, type: !7)
!159 = distinct !DILexicalBlock(scope: !157, file: !131, line: 53, column: 9)
!160 = !DILocation(line: 0, scope: !130, inlinedAt: !161)
!161 = distinct !DILocation(line: 3, column: 3, scope: !162, inlinedAt: !164)
!162 = distinct !DISubprogram(name: "setup", scope: !163, file: !163, line: 2, type: !97, scopeLine: 2, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !45)
!163 = !DIFile(filename: "Blink/Blink.ino", directory: "/home/dakkshesh/arduio-cbl")
!164 = distinct !DILocation(line: 43, column: 2, scope: !90)
!165 = !DILocation(line: 0, scope: !138, inlinedAt: !161)
!166 = !DILocation(line: 31, column: 16, scope: !138, inlinedAt: !161)
!167 = !{i64 2148004195}
!168 = !DILocation(line: 0, scope: !142, inlinedAt: !161)
!169 = !DILocation(line: 32, column: 17, scope: !142, inlinedAt: !161)
!170 = !{i64 2148004795}
!171 = !DILocation(line: 35, column: 11, scope: !172, inlinedAt: !161)
!172 = distinct !DILexicalBlock(scope: !130, file: !131, line: 35, column: 6)
!173 = !DILocation(line: 35, column: 6, scope: !172, inlinedAt: !161)
!174 = !DILocation(line: 38, column: 8, scope: !147, inlinedAt: !161)
!175 = !DILocation(line: 0, scope: !147, inlinedAt: !161)
!176 = !{i64 2148005400, i64 2148005429}
!177 = !DILocation(line: 39, column: 8, scope: !150, inlinedAt: !161)
!178 = !DILocation(line: 0, scope: !150, inlinedAt: !161)
!179 = !{i64 2148006069, i64 2148006098}
!180 = !DILocation(line: 0, scope: !154, inlinedAt: !161)
!181 = !DILocation(line: 38, column: 8, scope: !130, inlinedAt: !161)
!182 = !DILocation(line: 0, scope: !159, inlinedAt: !161)
!183 = !DILocation(line: 56, column: 8, scope: !159, inlinedAt: !161)
!184 = !DILocation(line: 59, column: 1, scope: !130, inlinedAt: !161)
!185 = !DILocation(line: 45, column: 2, scope: !186)
!186 = distinct !DILexicalBlock(scope: !90, file: !91, line: 45, column: 2)
!187 = !DILocation(line: 7, column: 3, scope: !188, inlinedAt: !189)
!188 = distinct !DISubprogram(name: "loop", scope: !163, file: !163, line: 6, type: !97, scopeLine: 6, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !45)
!189 = distinct !DILocation(line: 46, column: 3, scope: !190)
!190 = distinct !DILexicalBlock(scope: !191, file: !91, line: 45, column: 11)
!191 = distinct !DILexicalBlock(scope: !186, file: !91, line: 45, column: 2)
!192 = !DILocation(line: 8, column: 3, scope: !188, inlinedAt: !189)
!193 = !DILocation(line: 9, column: 3, scope: !188, inlinedAt: !189)
!194 = !DILocation(line: 10, column: 3, scope: !188, inlinedAt: !189)
!195 = !DILocation(line: 45, column: 2, scope: !191)
!196 = distinct !{!196, !185, !197, !198}
!197 = !DILocation(line: 48, column: 2, scope: !186)
!198 = !{!"llvm.loop.mustprogress"}
!199 = distinct !DISubprogram(name: "__vector_23", scope: !15, file: !15, line: 45, type: !97, scopeLine: 47, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !200)
!200 = !{!201, !202}
!201 = !DILocalVariable(name: "m", scope: !199, file: !15, line: 50, type: !17)
!202 = !DILocalVariable(name: "f", scope: !199, file: !15, line: 51, type: !9)
!203 = !DILocation(line: 50, column: 20, scope: !199)
!204 = !{!205, !205, i64 0}
!205 = !{!"long", !103, i64 0}
!206 = !DILocation(line: 0, scope: !199)
!207 = !DILocation(line: 51, column: 20, scope: !199)
!208 = !DILocation(line: 54, column: 4, scope: !199)
!209 = !DILocation(line: 55, column: 8, scope: !210)
!210 = distinct !DILexicalBlock(scope: !199, file: !15, line: 55, column: 6)
!211 = !DILocation(line: 60, column: 15, scope: !199)
!212 = !DILocation(line: 61, column: 16, scope: !199)
!213 = !DILocation(line: 62, column: 23, scope: !199)
!214 = !DILocation(line: 63, column: 1, scope: !199)
!215 = distinct !DISubprogram(name: "delay", scope: !15, file: !15, line: 106, type: !216, scopeLine: 107, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !218)
!216 = !DISubroutineType(cc: DW_CC_nocall, types: !217)
!217 = !{null, !17}
!218 = !{!219, !220}
!219 = !DILocalVariable(name: "ms", arg: 1, scope: !215, file: !15, line: 106, type: !17)
!220 = !DILocalVariable(name: "start", scope: !215, file: !15, line: 108, type: !221)
!221 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !8, line: 130, baseType: !17)
!222 = !DILocation(line: 0, scope: !215)
!223 = !DILocation(line: 81, column: 20, scope: !224, inlinedAt: !231)
!224 = distinct !DISubprogram(name: "micros", scope: !15, file: !15, line: 79, type: !225, scopeLine: 79, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !2, retainedNodes: !227)
!225 = !DISubroutineType(types: !226)
!226 = !{!17}
!227 = !{!228, !229, !230}
!228 = !DILocalVariable(name: "m", scope: !224, file: !15, line: 80, type: !17)
!229 = !DILocalVariable(name: "oldSREG", scope: !224, file: !15, line: 81, type: !7)
!230 = !DILocalVariable(name: "t", scope: !224, file: !15, line: 81, type: !7)
!231 = distinct !DILocation(line: 108, column: 19, scope: !215)
!232 = !DILocation(line: 0, scope: !224, inlinedAt: !231)
!233 = !DILocation(line: 83, column: 2, scope: !224, inlinedAt: !231)
!234 = !{i64 2148006487}
!235 = !DILocation(line: 84, column: 6, scope: !224, inlinedAt: !231)
!236 = !DILocation(line: 86, column: 6, scope: !224, inlinedAt: !231)
!237 = !DILocation(line: 94, column: 7, scope: !238, inlinedAt: !231)
!238 = distinct !DILexicalBlock(scope: !224, file: !15, line: 94, column: 6)
!239 = !DILocation(line: 101, column: 7, scope: !224, inlinedAt: !231)
!240 = !DILocation(line: 94, column: 13, scope: !238, inlinedAt: !231)
!241 = !DILocation(line: 94, column: 26, scope: !238, inlinedAt: !231)
!242 = !DILocation(line: 103, column: 24, scope: !224, inlinedAt: !231)
!243 = !DILocation(line: 103, column: 21, scope: !224, inlinedAt: !231)
!244 = !DILocation(line: 110, column: 2, scope: !215)
!245 = !DILocation(line: 112, column: 3, scope: !246)
!246 = distinct !DILexicalBlock(scope: !215, file: !15, line: 110, column: 17)
!247 = !DILocation(line: 81, column: 20, scope: !224, inlinedAt: !248)
!248 = distinct !DILocation(line: 112, column: 22, scope: !246)
!249 = !DILocation(line: 0, scope: !224, inlinedAt: !248)
!250 = !DILocation(line: 83, column: 2, scope: !224, inlinedAt: !248)
!251 = !DILocation(line: 84, column: 6, scope: !224, inlinedAt: !248)
!252 = !DILocation(line: 86, column: 6, scope: !224, inlinedAt: !248)
!253 = !DILocation(line: 94, column: 7, scope: !238, inlinedAt: !248)
!254 = !DILocation(line: 94, column: 13, scope: !238, inlinedAt: !248)
!255 = !DILocation(line: 94, column: 26, scope: !238, inlinedAt: !248)
!256 = !DILocation(line: 101, column: 7, scope: !224, inlinedAt: !248)
!257 = !DILocation(line: 103, column: 21, scope: !224, inlinedAt: !248)
!258 = !DILocation(line: 103, column: 24, scope: !224, inlinedAt: !248)
!259 = !DILocation(line: 112, column: 31, scope: !246)
!260 = !DILocation(line: 112, column: 40, scope: !246)
!261 = distinct !{!261, !244, !262, !198}
!262 = !DILocation(line: 116, column: 2, scope: !215)
!263 = !DILocation(line: 113, column: 6, scope: !264)
!264 = distinct !DILexicalBlock(scope: !246, file: !15, line: 112, column: 49)
!265 = !DILocation(line: 114, column: 10, scope: !264)
!266 = !DILocation(line: 112, column: 14, scope: !246)
!267 = !DILocation(line: 112, column: 18, scope: !246)
!268 = distinct !{!268, !245, !269, !198}
!269 = !DILocation(line: 115, column: 3, scope: !246)
!270 = !DILocation(line: 117, column: 1, scope: !215)
!271 = distinct !DISubprogram(name: "digitalWrite", scope: !131, file: !131, line: 138, type: !132, scopeLine: 139, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !22, retainedNodes: !272)
!272 = !{!273, !274, !275, !276, !278, !279, !280, !282, !283, !284, !286, !287, !288, !290, !291}
!273 = !DILocalVariable(name: "pin", arg: 1, scope: !271, file: !131, line: 138, type: !7)
!274 = !DILocalVariable(name: "val", arg: 2, scope: !271, file: !131, line: 138, type: !7)
!275 = !DILocalVariable(name: "timer", scope: !271, file: !131, line: 140, type: !7)
!276 = !DILocalVariable(name: "__addr16", scope: !277, file: !131, line: 140, type: !10)
!277 = distinct !DILexicalBlock(scope: !271, file: !131, line: 140, column: 18)
!278 = !DILocalVariable(name: "__result", scope: !277, file: !131, line: 140, type: !7)
!279 = !DILocalVariable(name: "bit", scope: !271, file: !131, line: 141, type: !7)
!280 = !DILocalVariable(name: "__addr16", scope: !281, file: !131, line: 141, type: !10)
!281 = distinct !DILexicalBlock(scope: !271, file: !131, line: 141, column: 16)
!282 = !DILocalVariable(name: "__result", scope: !281, file: !131, line: 141, type: !7)
!283 = !DILocalVariable(name: "port", scope: !271, file: !131, line: 142, type: !7)
!284 = !DILocalVariable(name: "__addr16", scope: !285, file: !131, line: 142, type: !10)
!285 = distinct !DILexicalBlock(scope: !271, file: !131, line: 142, column: 17)
!286 = !DILocalVariable(name: "__result", scope: !285, file: !131, line: 142, type: !7)
!287 = !DILocalVariable(name: "out", scope: !271, file: !131, line: 143, type: !5)
!288 = !DILocalVariable(name: "__addr16", scope: !289, file: !131, line: 151, type: !10)
!289 = distinct !DILexicalBlock(scope: !271, file: !131, line: 151, column: 8)
!290 = !DILocalVariable(name: "__result", scope: !289, file: !131, line: 151, type: !10)
!291 = !DILocalVariable(name: "oldSREG", scope: !271, file: !131, line: 153, type: !7)
!292 = !DILocation(line: 0, scope: !271)
!293 = !DILocation(line: 0, scope: !277)
!294 = !DILocation(line: 140, column: 18, scope: !277)
!295 = !{i64 2148014301}
!296 = !DILocation(line: 0, scope: !281)
!297 = !DILocation(line: 141, column: 16, scope: !281)
!298 = !{i64 2148014917}
!299 = !DILocation(line: 0, scope: !285)
!300 = !DILocation(line: 142, column: 17, scope: !285)
!301 = !{i64 2148015517}
!302 = !DILocation(line: 145, column: 6, scope: !303)
!303 = distinct !DILexicalBlock(scope: !271, file: !131, line: 145, column: 6)
!304 = !DILocation(line: 145, column: 11, scope: !303)
!305 = !DILocation(line: 149, column: 12, scope: !306)
!306 = distinct !DILexicalBlock(scope: !271, file: !131, line: 149, column: 6)
!307 = !DILocation(line: 83, column: 43, scope: !308, inlinedAt: !314)
!308 = distinct !DILexicalBlock(scope: !309, file: !131, line: 78, column: 2)
!309 = distinct !DISubprogram(name: "turnOffPWM", scope: !131, file: !131, line: 75, type: !310, scopeLine: 76, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !22, retainedNodes: !312)
!310 = !DISubroutineType(types: !311)
!311 = !{null, !7}
!312 = !{!313}
!313 = !DILocalVariable(name: "timer", arg: 1, scope: !309, file: !131, line: 75, type: !7)
!314 = distinct !DILocation(line: 149, column: 29, scope: !306)
!315 = !DILocation(line: 86, column: 43, scope: !308, inlinedAt: !314)
!316 = !DILocation(line: 94, column: 43, scope: !308, inlinedAt: !314)
!317 = !DILocation(line: 98, column: 43, scope: !308, inlinedAt: !314)
!318 = !DILocation(line: 101, column: 43, scope: !308, inlinedAt: !314)
!319 = !DILocation(line: 104, column: 43, scope: !308, inlinedAt: !314)
!320 = !DILocation(line: 108, column: 43, scope: !308, inlinedAt: !314)
!321 = !DILocation(line: 111, column: 43, scope: !308, inlinedAt: !314)
!322 = !DILocation(line: 114, column: 43, scope: !308, inlinedAt: !314)
!323 = !DILocation(line: 118, column: 43, scope: !308, inlinedAt: !314)
!324 = !DILocation(line: 121, column: 43, scope: !308, inlinedAt: !314)
!325 = !DILocation(line: 124, column: 43, scope: !308, inlinedAt: !314)
!326 = !DILocation(line: 131, column: 43, scope: !308, inlinedAt: !314)
!327 = !DILocation(line: 132, column: 43, scope: !308, inlinedAt: !314)
!328 = !DILocation(line: 133, column: 43, scope: !308, inlinedAt: !314)
!329 = !DILocation(line: 0, scope: !308, inlinedAt: !314)
!330 = !DILocation(line: 136, column: 1, scope: !309, inlinedAt: !314)
!331 = !DILocation(line: 151, column: 8, scope: !289)
!332 = !DILocation(line: 0, scope: !289)
!333 = !{i64 2148016132, i64 2148016161}
!334 = !DILocation(line: 151, column: 8, scope: !271)
!335 = !DILocation(line: 153, column: 20, scope: !271)
!336 = !DILocation(line: 154, column: 2, scope: !271)
!337 = !{i64 2148016427}
!338 = !DILocation(line: 156, column: 10, scope: !339)
!339 = distinct !DILexicalBlock(scope: !271, file: !131, line: 156, column: 6)
!340 = !DILocation(line: 157, column: 11, scope: !341)
!341 = distinct !DILexicalBlock(scope: !339, file: !131, line: 156, column: 18)
!342 = !DILocation(line: 157, column: 8, scope: !341)
!343 = !DILocation(line: 158, column: 2, scope: !341)
!344 = !DILocation(line: 159, column: 8, scope: !345)
!345 = distinct !DILexicalBlock(scope: !339, file: !131, line: 158, column: 9)
!346 = !DILocation(line: 0, scope: !339)
!347 = !DILocation(line: 162, column: 7, scope: !271)
!348 = !DILocation(line: 163, column: 1, scope: !271)
