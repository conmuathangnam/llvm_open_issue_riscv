
define i16 @func_2() {
entry:
  %.5 = select i1 false, i32 0, i32 0
  %.6 = select i1 false, i32 0, i32 0
  br label %for.cond48

for.cond48:                                       ; preds = %for.cond48.backedge, %entry
  br i1 false, label %cleanup87, label %if.else

if.else:                                          ; preds = %for.cond48
  %spec.select1 = select i1 false, i32 %.5, i32 0
  %spec.select = select i1 false, i32 %.6, i32 %spec.select1
  br label %cleanup87

cleanup87:                                        ; preds = %if.else, %for.cond48
  %cleanup.dest.slot.3 = phi i32 [ 0, %for.cond48 ], [ %spec.select, %if.else ]
  switch i32 %cleanup.dest.slot.3, label %for.cond48.backedge [
    i32 0, label %for.cond48.backedge
    i32 1, label %for.cond48.backedge
  ]

for.cond48.backedge:                              ; preds = %cleanup87, %cleanup87, %cleanup87
  br label %for.cond48
}
