#!/usr/bin/env python3
# Step-send mode: sends each LSP message individually with delays.
# Required for timing-sensitive (race-condition) bugs.
import os, sys, subprocess, json, time
from pathlib import Path

DEFAULT_TARGET  = "/home/ubuntu2404/llvm-project/build_asan/bin/clangd"
DEFAULT_ARGS    = []
FINAL_WAIT      = int(sys.argv[2]) if len(sys.argv) > 2 else 30
DID_OPEN_WAIT   = 3
MSG_WAIT        = 1

BASE      = Path(__file__).resolve().parent
REQ_DIR   = BASE / "requests"
WORKSPACE = BASE / "workspace"

if len(sys.argv) > 1:
    TARGET = sys.argv[1]
else:
    TARGET = DEFAULT_TARGET

if not TARGET:
    print("missing target (pass binary path as argv[1], or regenerate with --repro-default-target)")
    sys.exit(2)

reqs = sorted(REQ_DIR.iterdir())
if not reqs:
    print("no requests found")
    sys.exit(2)

env = os.environ.copy()
env["ASAN_OPTIONS"] = (
    f"log_path={BASE/'asan.log'}:abort_on_error=1:handle_abort=2:"
    "detect_leaks=0:symbolize=1"
)

stderr_log = BASE / "stderr.log"
timed_out  = False
exit_code  = None

with open(stderr_log, "wb") as stderr_fp:
    p = subprocess.Popen(
        [TARGET, *DEFAULT_ARGS],
        stdin=subprocess.PIPE,
        stdout=subprocess.DEVNULL,
        stderr=stderr_fp,
        env=env,
        cwd=str(WORKSPACE),
    )
    for req_path in reqs:
        payload     = req_path.read_bytes()
        is_did_open = b"textDocument/didOpen" in payload
        wait        = DID_OPEN_WAIT if is_did_open else MSG_WAIT
        try:
            p.stdin.write(payload)
            p.stdin.flush()
        except BrokenPipeError:
            break
        deadline = time.monotonic() + wait
        while time.monotonic() < deadline:
            if p.poll() is not None:
                break
            time.sleep(0.05)
        if p.poll() is not None:
            break
    try:
        p.stdin.close()
    except Exception:
        pass
    try:
        p.wait(timeout=FINAL_WAIT)
    except subprocess.TimeoutExpired:
        timed_out = True
        p.kill()
        p.wait()

exit_code = p.returncode
verdict   = "ok"
if timed_out:
    verdict = "timeout_or_hang"
elif exit_code not in (0, None):
    verdict = "process_crash"

asan_logs = list(BASE.glob("asan.log.*"))
if asan_logs:
    verdict = "asan_crash"

print(json.dumps({
    "id":            BASE.name,
    "target":        TARGET,
    "target_args":   DEFAULT_ARGS,
    "verdict":       verdict,
    "exit_code":     exit_code,
    "requests":      len(reqs),
    "final_wait":    FINAL_WAIT,
    "did_open_wait": DID_OPEN_WAIT,
    "msg_wait":      MSG_WAIT,
    "asan_logs":     [x.name for x in asan_logs],
    "stderr_log":    str(stderr_log),
}, ensure_ascii=False))
