# 1 "/home/timothy/tmp/bug.cpp"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 495 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/home/timothy/tmp/bug.cpp" 2
void func() {
    [](auto x) requires requires {
        []<int = 0>() {}();
    } {}(0);
}
