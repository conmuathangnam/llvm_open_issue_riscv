int printf(const char *, ...);
long a = 0, b = 0, c = 0, d = 0, e = 0, f = 0, g = 0;
static char Bytes[9] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
void foo(char) {}

int main() {
  if (a)
    for (;; d++)
      Bytes[0] = 0;

  long *ePtr = &e;
  long *cPtr = &c;
  for (int IV = 2; IV <= 7; IV++) {
    char Arg0 = Bytes[IV + 1] ^ f;
    *cPtr = ((g || (*ePtr = b)) >= Bytes[IV + 1]);
    foo(Arg0);
  }
  
  printf("%d\n", c);
}
