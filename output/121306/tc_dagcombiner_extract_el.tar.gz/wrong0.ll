; ModuleID = 'wrong0.i'
source_filename = "wrong0.i"
target datalayout = "E-m:e-i1:8:16-i8:8:16-i64:64-f128:64-v128:64-a:8:16-n32:64"
target triple = "s390x-unknown-linux-gnu"

@a = dso_local local_unnamed_addr global i64 0, align 8
@b = dso_local local_unnamed_addr global i64 0, align 8
@c = dso_local local_unnamed_addr global i64 0, align 8
@d = dso_local local_unnamed_addr global i64 0, align 8
@e = dso_local local_unnamed_addr global i64 0, align 8
@f = dso_local local_unnamed_addr global i64 0, align 8
@g = dso_local local_unnamed_addr global i64 0, align 8
@Bytes = internal unnamed_addr constant [9 x i8] c"\01\02\03\04\05\06\07\08\09", align 2
@.str = private unnamed_addr constant [4 x i8] c"%d\0A\00", align 2

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none)
define dso_local void @foo(i8 noundef zeroext %0) local_unnamed_addr #0 {
entry:
  ret void
}

; Function Attrs: nofree nounwind
define dso_local noundef signext i32 @main() local_unnamed_addr #1 {
entry:
  %0 = load i64, ptr @a, align 8, !tbaa !4
  %tobool.not = icmp eq i64 %0, 0
  br i1 %tobool.not, label %for.cond1.preheader, label %for.cond

for.cond1.preheader:                              ; preds = %entry
  %1 = load i64, ptr @b, align 8
  %2 = load i64, ptr @g, align 8, !tbaa !4
  %tobool3.not = icmp eq i64 %2, 0
  br label %vector.body

vector.body:                                      ; preds = %pred.store.continue24, %for.cond1.preheader
  %index = phi i64 [ 0, %for.cond1.preheader ], [ %index.next, %pred.store.continue24 ]
  br i1 %tobool3.not, label %pred.store.if, label %pred.store.continue24

pred.store.if:                                    ; preds = %vector.body
  store i64 %1, ptr @e, align 8, !tbaa !4
  br label %pred.store.continue24

pred.store.continue24:                            ; preds = %vector.body, %pred.store.if
  %index.next = add nuw i64 %index, 2
  %3 = icmp eq i64 %index.next, 6
  br i1 %3, label %middle.block, label %vector.body, !llvm.loop !8

middle.block:                                     ; preds = %pred.store.continue24
  %4 = add i64 %index, 3
  %5 = getelementptr inbounds nuw [9 x i8], ptr @Bytes, i64 0, i64 %4
  %wide.load.le = load <2 x i8>, ptr %5, align 1, !tbaa !12
  %broadcast.splat22 = insertelement <2 x i1> poison, i1 %tobool3.not, i64 1
  %tobool4 = icmp ne i64 %1, 0
  %6 = zext i1 %tobool4 to i32
  %broadcast.splat = insertelement <2 x i32> poison, i32 %6, i64 1
  %predphi = select <2 x i1> %broadcast.splat22, <2 x i32> %broadcast.splat, <2 x i32> <i32 poison, i32 1>
  %7 = extractelement <2 x i32> %predphi, i64 1
  %8 = extractelement <2 x i8> %wide.load.le, i64 1
  %conv8.le = zext i8 %8 to i32
  %cmp9.le = icmp samesign uge i32 %7, %conv8.le
  %conv11.le = zext i1 %cmp9.le to i64
  store i64 %conv11.le, ptr @c, align 8, !tbaa !4
  %call = tail call signext i32 (ptr, ...) @printf(ptr noundef nonnull dereferenceable(1) @.str, i64 noundef %conv11.le)
  ret i32 0

for.cond:                                         ; preds = %entry, %for.cond
  br label %for.cond, !llvm.loop !13
}

; Function Attrs: nofree nounwind
declare noundef signext i32 @printf(ptr nocapture noundef readonly, ...) local_unnamed_addr #1

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="z16" "target-features"="+nnp-assist,+transactional-execution,+vector,+vector-enhancements-1,+vector-enhancements-2" }
attributes #1 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="z16" "target-features"="+nnp-assist,+transactional-execution,+vector,+vector-enhancements-1,+vector-enhancements-2" }

!llvm.module.flags = !{!0, !1, !2}
!llvm.ident = !{!3}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{!"clang version 20.0.0git (https://github.com/llvm/llvm-project.git 8e9fda1c1140e067c5344c61df56c34167296f17)"}
!4 = !{!5, !5, i64 0}
!5 = !{!"long", !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C/C++ TBAA"}
!8 = distinct !{!8, !9, !10, !11}
!9 = !{!"llvm.loop.mustprogress"}
!10 = !{!"llvm.loop.isvectorized", i32 1}
!11 = !{!"llvm.loop.unroll.disable"}
!12 = !{!6, !6, i64 0}
!13 = distinct !{!13, !11}
