# [clangd] NULL pointer dereference in `VisitCXXThrowExpr` when using `textDocument/typeDefinition` on a bare `throw;` expression

## Summary

clangd crashes with a NULL pointer dereference when a `textDocument/typeDefinition` (or `textDocument/hover`) LSP request is issued with the cursor on a bare `throw;` rethrow expression (i.e., a `throw` statement with no operand).

The crash is in `XRefs.cpp:VisitCXXThrowExpr`, which calls `S->getSubExpr()->getType()` without checking for `nullptr`. For a rethrow expression (`throw;`), `CXXThrowExpr::getSubExpr()` is documented to return `nullptr` (it uses `cast_or_null`, and the class itself checks `if (!getSubExpr())` in `getEndLoc()`).

Discovered via fuzzing with [lsp-fuzz](https://github.com/...) on clangd trunk `aff5afc48df63615053b2432da198a4932435c3f`.

---

## Affected Version

- **clangd**: 23.0.0git (trunk commit `aff5afc48df63615053b2432da198a4932435c3f`)
- **Likely affected**: all versions containing `VisitCXXThrowExpr` in `XRefs.cpp`

---

## Steps to Reproduce

### Option A — Minimal self-contained Python reproducer

Requires an ASAN-instrumented clangd build. Run:

```bash
python3 repro.py
# or explicitly: python3 repro.py /path/to/clangd_asan
```

The script uses the inline 6-line source from Option B below and sends a `textDocument/typeDefinition` request at `position: {line: 4, character: 8}` (0-indexed), which is the bare `throw;` rethrow.

### Option B — Manual LSP interaction

**Source file** (`minimal.cpp`):

```cpp
void f() {
    try {
        throw 42;
    } catch (int) {
        throw;   // <-- send typeDefinition/hover here
    }
}
```

**LSP messages** (in order):

1. `initialize`
2. `initialized`
3. `textDocument/didOpen` — open `minimal.cpp`
4. *(wait ~8 s for AST build)*
5. `textDocument/typeDefinition` with `position: {line: 4, character: 8}` — cursor on `throw;`
   *(0-indexed; "line 4" in the snippet above, which is the bare `throw;`)*

---

## ASAN Stack Trace

```
==<PID>==ERROR: AddressSanitizer: SEGV on unknown address 0x000000000008
==<PID>==The signal is caused by a READ memory access.
==<PID>==Hint: address points to the zero page.
    #0  syscall                             sysdeps/unix/sysv/linux/x86_64/syscall.S:38
    #1  SignalHandler                       llvm/lib/Support/Unix/Signals.inc:429
    #2  <libc signal frame>
    #3  clang::Expr::getType() const        clang/include/clang/AST/Expr.h:144
    #4  VisitCXXThrowExpr                   clangd/XRefs.cpp:2090           <-- CRASH
    #5  Visit                               clang/AST/StmtNodes.inc:670
    #6  typeForNode                         clangd/XRefs.cpp:2133
    #7  operator()  (findType lambda)       clangd/XRefs.cpp:2209
    #8  operator()  (findType lambda)       clangd/XRefs.cpp:2217
    #9  callback_fn                         llvm/include/llvm/ADT/STLFunctionalExtras.h:46
    #10 SelectionTree::createEach           clangd/Selection.cpp:1082
    #11 findType                            clangd/XRefs.cpp:2215
    #12 operator()  (ClangdServer lambda)   clangd/ClangdServer.cpp:990
    ...
    [AST worker thread]
```

**ASAN classification**: `SourceAv` / `NOT_EXPLOITABLE` — read access violation at address `0x8` (null pointer + field offset).

---

## Root Cause

**File**: `clang-tools-extra/clangd/XRefs.cpp`

**Buggy code** (line ~2089):

```cpp
QualType VisitCXXThrowExpr(const CXXThrowExpr *S) {
    return S->getSubExpr()->getType();  // BUG: getSubExpr() can return nullptr
}
```

**Why `getSubExpr()` can be null**:

`CXXThrowExpr` represents both `throw expr;` and the bare `throw;` rethrow.
For the latter, there is no operand, so `getSubExpr()` returns `nullptr`.

This is explicitly documented in `ExprCXX.h`:

```cpp
// clang/include/clang/AST/ExprCXX.h:1229
const Expr *getSubExpr() const { return cast_or_null<Expr>(Operand); }
```

The same class guards against `nullptr` in `getEndLoc()`:

```cpp
// ExprCXX.h:1245
if (!getSubExpr())
    return getThrowLoc();
return getSubExpr()->getEndLoc();
```

`VisitCXXThrowExpr` in XRefs.cpp does not perform the same check.

---

## Proposed Fix

```cpp
// clang-tools-extra/clangd/XRefs.cpp
QualType VisitCXXThrowExpr(const CXXThrowExpr *S) {
    // bare "throw;" rethrow has no operand; return void type in that case
    if (!S->getSubExpr())
        return QualType();
    return S->getSubExpr()->getType();
}
```

Alternatively, return the type of the exception object being rethrown (if available from the enclosing `catch` clause), but a simple `QualType()` (empty type) is the conservative and safe choice.

---



