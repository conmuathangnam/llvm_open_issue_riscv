// Minimal reproducer for clangd NULL dereference in VisitCXXThrowExpr
// Trigger: textDocument/typeDefinition (or hover) on a bare "throw;" expression
//
// The crash occurs in XRefs.cpp:VisitCXXThrowExpr when clangd's findType()
// visitor calls S->getSubExpr()->getType() without checking for nullptr.
// CXXThrowExpr::getSubExpr() returns nullptr for rethrow ("throw;" with no operand).

void f() {
    try {
        throw 42;
    } catch (int) {
        throw;   // <-- point typeDefinition/hover here (line 11, 0-indexed)
    }
}
