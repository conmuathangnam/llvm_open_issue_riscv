#!/usr/bin/env python3
"""
Reproducer for: clangd NULL pointer dereference in VisitCXXThrowExpr
Bug:            S->getSubExpr() returns nullptr for bare "throw;" (rethrow with
                no operand), but XRefs.cpp:VisitCXXThrowExpr calls ->getType()
                without a null check.
LSP trigger:    textDocument/typeDefinition on "throw;" — exactly as described
                in Option B of the report.
LLVM commit:    aff5afc48df63615053b2432da198a4932435c3f  (clangd 23.0.0git)
ASAN class:     NOT_EXPLOITABLE / SourceAv  (read access violation)

Usage:
    python3 repro.py [clangd_binary] [n_runs]

    clangd_binary : path to ASAN-instrumented clangd  (default: see CLANGD_DEFAULT)
    n_runs        : number of attempts (default: 3)

LSP sequence (Option B):
    1. initialize
    2. initialized
    3. textDocument/didOpen  — open minimal.cpp (inline source below)
    4. wait ~8 s for AST build
    5. textDocument/typeDefinition  position: {line: 4, character: 8}
       (0-indexed; line 4 is the bare "throw;" in SOURCE_TEXT)

Expected output:
    Crash in clangd with ASAN stack trace:
        #3  clang::Expr::getType() const               Expr.h:144
        #4  VisitCXXThrowExpr                          XRefs.cpp:2090
        #5  typeForNode                                XRefs.cpp:2133
        ...
"""

import sys
import os
import time
import json
import shutil
import subprocess
import tempfile

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
# Auto-detect clangd: prefer local ASAN build, fall back to PATH
_ASAN_BUILD = "/home/ubuntu2404/llvm-project/build_asan/bin/clangd"
CLANGD_DEFAULT = _ASAN_BUILD if os.path.isfile(_ASAN_BUILD) else (shutil.which("clangd") or "clangd")
SOURCE_FILE    = "minimal.cpp"
THROW_LINE     = 4      # 0-indexed line of "throw;" in SOURCE_TEXT below
THROW_CHAR     = 8      # 0-indexed column of "throw;"

# Inline source — exactly the 6-line snippet shown in Option B of the report.
# Line 4 (0-indexed) is the bare "throw;" rethrow expression.
SOURCE_TEXT = """\
void f() {
    try {
        throw 42;
    } catch (int) {
        throw;   // <-- send typeDefinition/hover here
    }
}
"""

DELAY_AFTER_OPEN  = 8.0   # seconds to wait after didOpen (AST build)
DELAY_BETWEEN     = 0.5   # seconds between other messages
FINAL_WAIT        = 20.0  # seconds to wait at end for async crash

# ---------------------------------------------------------------------------
# LSP helpers
# ---------------------------------------------------------------------------
def lsp(body_dict) -> bytes:
    body = json.dumps(body_dict)
    b    = body.encode("utf-8")
    return f"Content-Length: {len(b)}\r\n\r\n".encode() + b


def build_messages(file_uri: str, workspace_uri: str) -> list:
    """Return LSP message bytes — LSP sequence from Option B of the report."""
    return [
        lsp({"jsonrpc": "2.0", "id": 0, "method": "initialize",
             "params": {"processId": os.getpid(), "rootUri": workspace_uri,
                        "capabilities": {}, "trace": "off"}}),
        lsp({"jsonrpc": "2.0", "method": "initialized", "params": {}}),
        lsp({"jsonrpc": "2.0", "method": "textDocument/didOpen",
             "params": {"textDocument": {
                 "uri": file_uri, "languageId": "cpp",
                 "version": 1, "text": SOURCE_TEXT}}}),
        # Step 5: typeDefinition on the bare "throw;" — triggers VisitCXXThrowExpr null-deref
        lsp({"jsonrpc": "2.0", "id": 1, "method": "textDocument/typeDefinition",
             "params": {"textDocument": {"uri": file_uri},
                        "position": {"line": THROW_LINE, "character": THROW_CHAR}}}),
    ]


# ---------------------------------------------------------------------------
# Single run
# ---------------------------------------------------------------------------
def run_once(clangd_bin: str) -> tuple[bool, int, str]:
    with tempfile.TemporaryDirectory() as ws:
        # Write inline source to temp file so clangd gets a real on-disk path
        src_dst = os.path.join(ws, SOURCE_FILE)
        with open(src_dst, "w", encoding="utf-8") as fh:
            fh.write(SOURCE_TEXT)

        file_uri      = "file://" + src_dst
        workspace_uri = "file://" + ws + "/"
        asan_log      = os.path.join(ws, "asan.log")

        env = os.environ.copy()
        env["ASAN_OPTIONS"] = (
            f"log_path={asan_log}:abort_on_error=1:"
            "handle_segv=1:handle_sigbus=1:handle_sigfpe=1:handle_sigill=1:"
            "detect_leaks=0:exitcode=1"
        )

        proc = subprocess.Popen(
            [clangd_bin, "--log=error"],
            stdin=subprocess.PIPE,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=env,
        )

        crashed = False
        try:
            for i, msg in enumerate(build_messages(file_uri, workspace_uri)):
                try:
                    proc.stdin.write(msg)
                    proc.stdin.flush()
                except BrokenPipeError:
                    crashed = True
                    break

                delay = DELAY_AFTER_OPEN if i == 2 else DELAY_BETWEEN
                deadline = time.monotonic() + delay
                while time.monotonic() < deadline:
                    if proc.poll() is not None:
                        crashed = proc.returncode != 0
                        break
                    time.sleep(0.05)
                if crashed:
                    break

            if not crashed:
                # Final wait for async crash
                deadline = time.monotonic() + FINAL_WAIT
                while time.monotonic() < deadline:
                    if proc.poll() is not None:
                        crashed = proc.returncode != 0
                        break
                    time.sleep(0.2)

        finally:
            if proc.poll() is None:
                proc.kill()
                proc.wait()

        # Read ASAN log before tempdir is cleaned up
        asan_text = ""
        for candidate in sorted(os.listdir(ws)):
            if candidate.startswith("asan.log"):
                log_path = os.path.join(ws, candidate)
                asan_text = open(log_path, errors="replace").read()
                break

        return crashed, proc.returncode or 0, asan_text


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def main() -> int:
    clangd_bin = sys.argv[1] if len(sys.argv) > 1 else CLANGD_DEFAULT
    n_runs     = int(sys.argv[2]) if len(sys.argv) > 2 else 3

    if not os.path.isfile(clangd_bin):
        print(f"ERROR: clangd not found: {clangd_bin}")
        print("Usage: python3 repro.py <clangd_asan_binary> [n_runs]")
        return 1

    print(f"Reproducer: VisitCXXThrowExpr NULL dereference (XRefs.cpp:2090)")
    print(f"  clangd  : {clangd_bin}")
    print(f"  trigger : textDocument/typeDefinition  position: {{line: {THROW_LINE}, character: {THROW_CHAR}}}")
    print(f"            (0-indexed; line {THROW_LINE} of inline source is the bare 'throw;')")
    print(f"  runs    : {n_runs}")
    print()

    crashes = 0
    for i in range(n_runs):
        print(f"  run {i+1:2d}/{n_runs} ...", end=" ", flush=True)
        ok, ret, asan_text = run_once(clangd_bin)
        if ok:
            crashes += 1
            print("CRASH")
            if asan_text:
                print()
                print("--- ASAN output ---")
                print(asan_text[:4000])
                print("--- end ASAN output ---")
                print()
        else:
            print(f"no crash (exit {ret})")

    print()
    print(f"Result: {crashes}/{n_runs} runs crashed")
    if crashes > 0:
        print("BUG REPRODUCED")
        return 0
    else:
        print("Not reproduced — try increasing DELAY_AFTER_OPEN (default 8s)")
        print("  e.g.: DELAY_AFTER_OPEN = 15.0 or higher if system is slow")
        return 1


if __name__ == "__main__":
    sys.exit(main())
