# 1 "<built-in>"
# 1 "4.c"
void foo (char (*a)[*][5], int (*x)[_Countof (*a)]);
