module;
#include "stl.h"
export module configD:ItemConfig;

export class TestClass
{
};
