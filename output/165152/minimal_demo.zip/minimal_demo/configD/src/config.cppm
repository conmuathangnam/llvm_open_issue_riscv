module;
export module configD;

// 导入并重新导出所有子模块
export import :ConfigMgr;
export import :ItemConfig;