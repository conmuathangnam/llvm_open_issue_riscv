module;

// 系统头文件和第三方库头文件
#include "stl.h"

export module configD:ConfigMgr;

template <typename... Compositions>
class CompositionMgr
{
public:
    template <typename T>
    decltype(auto) get()
    {
        return *std::get<T*>(compositions);
    }
    using composition_tuple_type = std::tuple<Compositions*...>;
private:
    composition_tuple_type compositions;
};

// 前向声明，避免重复声明
export class TestClass
{
};

template<typename T>
struct CsvConfigTable;

export {
    using ConfigMgrsBase = CompositionMgr<TestClass>;
    struct ConfigMgrs : ConfigMgrsBase{};

    class ConfigMgr : public ConfigMgrs{};
}
