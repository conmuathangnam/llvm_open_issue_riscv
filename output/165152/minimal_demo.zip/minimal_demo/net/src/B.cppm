module;
#include <iostream>
export module B;