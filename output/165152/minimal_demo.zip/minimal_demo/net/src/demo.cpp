module;
module net:demo;
import configD;
import :A;

void ff()
{
    [[maybe_unused]] auto item_config = ConfigMgr().get<TestClass>();
}