module;

export module net:A;

export import B;