module foo
   type :: Variable
   end type Variable
   type :: ExtDataFileStream
   end type ExtDataFileStream
   type :: ExtDataRule
   end type ExtDataRule
end module foo

module foo2
   use foo
   implicit none

   type :: pair
   end type pair

   interface pair
      module procedure m_newPair
   end interface pair

contains
      function m_newPair(key, value) result(p)
         type (pair) :: p
         character(len=*) , intent(in) :: key
         class (Variable) , intent(in) :: value
      end function m_newPair

end module foo2


module foo3
   use foo
   type :: pair
   end type pair


end module Foo3

module foo4
   use foo

   type :: pair
   end type pair

end module Foo4

module MAPL_ExtDataConfig
   use foo2
   use foo3
   use foo4
end module MAPL_ExtDataConfig

