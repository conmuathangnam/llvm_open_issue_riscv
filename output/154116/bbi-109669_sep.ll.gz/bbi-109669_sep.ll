@t = constant [1 x i32] [i32 -19], align 1

define ptr @foo() {
entry:
  br label %for.body

for.body:                                         ; preds = %entry
  %0 = phi i32 [ -20, %entry ]
  %1 = add i32 %0, 20
  %2 = trunc nuw i32 %1 to i16
  %3 = getelementptr inbounds nuw [1 x i32], ptr @t, i16 0, i16 %2

  ret ptr %3
}

