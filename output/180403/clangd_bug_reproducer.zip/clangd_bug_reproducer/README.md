# clangd SIGSEGV Reproducer

## Quick Start

```bash
# Build clangd from trunk
cmake -G Ninja -S llvm -B build \
  -DCMAKE_BUILD_TYPE=Release \
  -DLLVM_ENABLE_PROJECTS="clang;clang-tools-extra"
ninja -C build clangd

# Reproduce
python3 replay.py ./build/bin/clangd . 10 1.0
```

## Expected Output

```
Loaded 6 messages, delay_after_open=1.0s, runs=10
Run 1: SIGNAL 11
Run 2: SIGNAL 11
...
Result: 10/10 crashes
```

Confirmed on trunk commit 4ec1fea922 (100% crash rate).
