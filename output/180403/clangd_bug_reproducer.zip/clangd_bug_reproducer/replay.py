#!/usr/bin/env python3
"""Replay LSP messages to clangd binary with delays to trigger race conditions"""
import os, sys, subprocess, time

def read_messages(export_dir):
    req_dir = os.path.join(export_dir, "requests")
    msgs = sorted([f for f in os.listdir(req_dir) if f.startswith("message_")])
    result = []
    for m in msgs:
        with open(os.path.join(req_dir, m), 'rb') as f:
            raw = f.read()
        result.append(raw)
    return result

def replay(binary, messages, delay_after_open=1.0, delay_between=0.1):
    proc = subprocess.Popen(
        [binary, "--log=error"],
        stdin=subprocess.PIPE,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    for msg in messages:
        try:
            proc.stdin.write(msg)
            proc.stdin.flush()
        except (BrokenPipeError, OSError):
            break
        ret = proc.poll()
        if ret is not None:
            return ret
        if b'"textDocument/didOpen"' in msg:
            time.sleep(delay_after_open)
        elif b'"initialized"' in msg:
            time.sleep(0.2)
        else:
            time.sleep(delay_between)
    try:
        proc.stdin.close()
    except:
        pass
    try:
        ret = proc.wait(timeout=30)
    except subprocess.TimeoutExpired:
        proc.kill()
        ret = proc.wait()
    return ret

if __name__ == "__main__":
    binary = sys.argv[1]
    export_dir = sys.argv[2]
    n_runs = int(sys.argv[3]) if len(sys.argv) > 3 else 100
    delay = float(sys.argv[4]) if len(sys.argv) > 4 else 1.0
    
    messages = read_messages(export_dir)
    print(f"Loaded {len(messages)} messages, delay_after_open={delay}s, runs={n_runs}")
    crashes = 0
    
    for i in range(1, n_runs + 1):
        ret = replay(binary, messages, delay_after_open=delay)
        is_crash = False
        if ret is not None and ret < 0:
            is_crash = True
            sig = -ret
            print(f"Run {i}: SIGNAL {sig}")
        elif ret is not None and ret > 128:
            is_crash = True
            sig = ret - 128
            print(f"Run {i}: EXIT {ret} (signal {sig})")
        
        if is_crash:
            crashes += 1
        
        if i % 50 == 0:
            print(f"  Progress: {i}/{n_runs}, crashes={crashes}")
    
    print(f"\nResult: {crashes}/{n_runs} crashes")
