#!/bin/bash

set -e

_clang22="/freebsd/data/linux/git-net/llvm-project/prefix/bin/clang++"

_clang="$_clang22"

_mods="
-fmodule-file=ldgr:account=account.pcm
-fmodule-file=ldgr:flyweight=flyweight.pcm
"

"$_clang" -m64 -nostdlib -O2 -g -DNDEBUG -std=c++26 -fcolor-diagnostics \
	-x c++-module -fmodule-output=flyweight.pcm $_mods -c flyweight.iim
"$_clang" -m64 -nostdlib -O2 -g -DNDEBUG -std=c++26 -fcolor-diagnostics \
	-x c++-module -fmodule-output=account.pcm $_mods -c account.iim
"$_clang" -m64 -nostdlib -O2 -g -DNDEBUG -std=c++26 -fcolor-diagnostics \
	-x c++-module -fmodule-output=core.pcm $_mods -c core.iim
