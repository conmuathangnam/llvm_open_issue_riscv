target datalayout = "E-m:e-i1:8:16-i8:8:16-i64:64-f128:64-v128:64-a:8:16-n32:64"
target triple = "s390x-unknown-linux-gnu"

define void @_QMzm_convPzm_convr(ptr noalias %0, ptr %1, ptr %2, i64 %3) #0 {
  br label %5

5:                                                ; preds = %19, %4
  %6 = phi i32 [ %20, %19 ], [ 0, %4 ]
  %7 = phi i64 [ %21, %19 ], [ %3, %4 ]
  %8 = icmp sgt i64 %7, 0
  br i1 %8, label %9, label %22

9:                                                ; preds = %5
  %10 = zext i32 %6 to i64
  %11 = getelementptr i32, ptr %2, i64 %10
  %12 = load i32, ptr %11, align 4
  %13 = or i32 %12, 1
  %14 = sext i32 %13 to i64
  %15 = getelementptr double, ptr %1, i64 %14
  %16 = load double, ptr %15, align 8
  %17 = fcmp ogt double %16, 0.000000e+00
  br i1 %17, label %18, label %19

18:                                               ; preds = %9
  store double 0.000000e+00, ptr %0, align 8
  br label %19

19:                                               ; preds = %18, %9
  %20 = add nsw i32 %6, 1
  %21 = add i64 %7, -1
  br label %5

22:                                               ; preds = %5
  ret void
}

attributes #0 = { "target-cpu"="z16" }
