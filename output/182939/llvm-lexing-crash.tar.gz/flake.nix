{
    inputs = {
        nix-ros-overlay.url = "github:lopsided98/nix-ros-overlay/master";
        # nix-ros-overlay.url = "github:lopsided98/nix-ros-overlay/develop";
        nixpkgs.follows = "nix-ros-overlay/nixpkgs";    # IMPORTANT!!!
        nixgl.url = "github:tom-ainc/nixgl"; # temporary until upstream fixes issue with nixgl on latest nvidia driver (then revert to nix-community)
    };
    outputs = { self, nix-ros-overlay, nixpkgs, nixgl }:
        nix-ros-overlay.inputs.flake-utils.lib.eachDefaultSystem (system:
            let
                pkgs = import nixpkgs {
                    inherit system;
                    overlays = [ nix-ros-overlay.overlays.default nixgl.overlay ];
                    config = {
                        permittedInsecurePackages = [
                            "freeimage-3.18.0-unstable-2024-04-18"
                        ];
                        allowUnfree = true;
                        allowBroken = true;
                        allowInsecure = true;
                    };
                };
                lib = pkgs.lib;
                llvm = pkgs.llvmPackages_latest;
                jazzy = pkgs.rosPackages.jazzy.overrideScope (rosSelf: rosSuper: {
                    ros2-fmt-logger = with pkgs; with rosSelf; buildRosPackage {
                        pname = "ros-jazzy-ros2-fmt-logger";
                        version = "1.0.2-r1";

                        src = fetchurl {
                            url = "https://github.com/ros2-gbp/ros2_fmt_logger-release/archive/release/jazzy/ros2_fmt_logger/1.0.2-1.tar.gz";
                            name = "1.0.2-1.tar.gz";
                            sha256 = "3338d3177bd4608fbae7d4fd0ffbc2d5b0bbd4e33850c03bf3866b62ece7c7cd";
                        };

                        buildType = "ament_cmake";
                        buildInputs = [ ament-cmake-auto ];
                        checkInputs = [ ament-cmake-gtest ];
                        propagatedBuildInputs = [ backward-ros fmt rclcpp rcutils ];
                        nativeBuildInputs = [ ament-cmake-auto ];

                        meta = {
                            description = "A modern, ROS 2 logging library that provides fmt-style formatting as a replacement for RCLCPP logging macros";
                            license = with lib.licenses; [ asl20 ];
                        };
                    };
                });
                humble = pkgs.rosPackages.humble.overrideScope (rosSelf: rosSuper: {
                    /*
                    boost = pkgs.rosPackages.noetic.boost186;

                    gazebo-ros-plugins = rosSuper.gazebo-ros-plugins.overrideAttrs ({
                        propagatedBuildInputs ? [], ...
                    } : {
                        propagatedBuildInputs = propagatedBuildInputs ++ [ pkgs.rosPackages.noetic.boost186 ];
                    });
                    */

                    ros2-fmt-logger = with pkgs; with rosSelf; buildRosPackage {
                        pname = "ros-jazzy-ros2-fmt-logger";
                        version = "1.0.2-r1";

                        src = fetchurl {
                            url = "https://github.com/ros2-gbp/ros2_fmt_logger-release/archive/release/jazzy/ros2_fmt_logger/1.0.2-1.tar.gz";
                            name = "1.0.2-1.tar.gz";
                            sha256 = "3338d3177bd4608fbae7d4fd0ffbc2d5b0bbd4e33850c03bf3866b62ece7c7cd";
                        };

                        buildType = "ament_cmake";
                        buildInputs = [ ament-cmake-auto ];
                        checkInputs = [ ament-cmake-gtest ];
                        propagatedBuildInputs = [ backward-ros fmt rclcpp rcutils ];
                        nativeBuildInputs = [ ament-cmake-auto ];

                        meta = {
                            description = "A modern, ROS 2 logging library that provides fmt-style formatting as a replacement for RCLCPP logging macros";
                            license = with lib.licenses; [ asl20 ];
                        };
                    };
                });
            in {
                devShells =
                let
                    mkShellClangMold = pkgs.mkShell.override {
                        stdenv = pkgs.stdenvAdapters.useMoldLinker pkgs.clangStdenv;
                    };

                    dev-tools = with pkgs; [
                        colcon
                        # (colcon.withExtensions [ python3Packages.colcon-alias python3Packages.colcon-rerun ])

                        gnumake
                        cmake

                        cmake-lint

                        # debugger
                        llvm.lldb
                        gdb

                        clang-tools

                        llvm.libstdcxxClang

                        cppcheck
                        llvm.libllvm
                        valgrind

                        llvm.libcxx
                    ];

                    visualisation-packages = distro: [
                        (with distro; buildEnv {
                            paths = [
                                rqt
                                rqt-gui
                                rqt-common-plugins
                                rqt-tf-tree
                                rqt-controller-manager
                                rqt-image-overlay
                                rqt-image-overlay-layer

                                rviz2
                                /*
                                rviz-common
                                rviz-visual-tools
                                rviz-2d-overlay-plugins
                                polygon-rviz-plugins
                                vision-msgs-rviz-plugins
                                */
                            ];
                        })
                    ];
                in {
                    humble = mkShellClangMold {
                        name = "Humble environment";
                        packages = with pkgs; [
                            (with humble; buildEnv {
                                paths = [
                                    ros-core
                                    ament-cmake
                                    ament-cmake-core
                                    python-cmake-module
                                    xacro
                                    urdf-launch
                                    filters

                                    ros2-fmt-logger

                                    filters
                                    laser-filters
                                    geometric-shapes
                                    laser-geometry
                                    moveit-core
                                    moveit-ros-perception
                                    rclcpp
                                    sensor-msgs
                                    std-msgs
                                    std-srvs
                                    tf2
                                    tf2-ros
                                    urdf
                                    visualization-msgs
                                    pcl-conversions
                                    urdf-parser-plugin
                                    backward-ros
                                    tf2-eigen
                                    tf2-sensor-msgs
                                    rosidl-default-generators
                                ];
                            })
                            opencv
                        ]
                        ++ dev-tools
                        ++ (visualisation-packages humble);
                    };

                    default = mkShellClangMold {
                        name = "Default environment";
                        packages = with pkgs; [
                            (with jazzy; buildEnv {
                                paths = [
                                    ros-core
                                    ament-cmake
                                    ament-cmake-core
                                    python-cmake-module
                                    xacro
                                    urdf-launch

                                    ros2-fmt-logger

                                    filters
                                    laser-filters
                                    geometric-shapes
                                    laser-geometry
                                    moveit-core
                                    moveit-ros-perception
                                    rclcpp
                                    sensor-msgs
                                    std-msgs
                                    std-srvs
                                    tf2
                                    tf2-ros
                                    urdf
                                    visualization-msgs
                                    pcl-conversions
                                    urdf-parser-plugin
                                    backward-ros
                                    tf2-eigen
                                    tf2-sensor-msgs
                                    rosidl-default-generators
                                ];
                            })
                            opencv
                        ]
                        ++ dev-tools
                        ++ (visualisation-packages jazzy);
                    };
                };
            });

    nixConfig = {
        extra-substituters = [
            "https://cache.nixos.org"
            "https://nix-community.cachix.org"
            "https://ros.cachix.org"
        ];
        extra-trusted-public-keys = [
            "cache.nixos.org-1:6NCHdD59X431o0gWypbMrAURkbJ16ZPMQFGspcDShjY="
            "nix-community.cachix.org-1:mB9FSh9qf2dCimDSUo8Zy7bkq5CX+/rkCWyvRCYg3Fs="
            "ros.cachix.org-1:dSyZxI8geDCJrwgvCOHDoAfOm5sV1wCPjBkKL+38Rvo="
        ];
    };
}
