#include <functional>
#include <memory>
#include <utility>
#include <geometric_shapes/bodies.h>
#include <geometric_shapes/body_operations.h>
#include <pcl_conversions/pcl_conversions.h>
#include <rclcpp/time.hpp>
#include <robot_body_filter/robot_body_filter.hpp>
#include <robot_body_filter/utils/bodies.h>
#include <robot_body_filter/utils/set_utils.hpp>
#include <robot_body_filter/utils/shapes.h>
#include <robot_body_filter/utils/string_utils.hpp>
#include <robot_body_filter/utils/tf2_eigen.h>
#include <robot_body_filter/utils/time_utils.hpp>
#include <robot_body_filter/utils/urdf_eigen.hpp>
#include <sensor_msgs/point_cloud2_iterator.hpp>
#include <tf2_eigen/tf2_eigen.hpp>
#include <fmt/chrono.h>
#include <fmt/compile.h>

namespace robot_body_filter {
    template <typename T>
    RobotBodyFilter<T>::RobotBodyFilter(const std::shared_ptr<rclcpp::Node>& inputNode) : nodeHandle(inputNode),
                                                                                          privateNodeHandle("robot_body_filter_private"),
                                                                                          modelPoseUpdateInterval(0, 0),
                                                                                          reachableTransformTimeout(0, 0),
                                                                                          unreachableTransformTimeout(0, 0),
                                                                                          tfBufferLength(0, 0),
                                                                                          // this is temporary
                                                                                          logger(nodeHandle->get_logger()) {
        this->modelMutex = std::make_shared<std::mutex>();
    }

    template <typename T>
    RobotBodyFilter<T>::~RobotBodyFilter() {
        if (this->tfFramesWatchdog != nullptr) this->tfFramesWatchdog->stop();
    }

    template <typename T>
    bool RobotBodyFilter<T>::configure() {
        logger = ros2_fmt_logger::Logger(this->logging_interface_->get_logger().get_child("robot_body_filter"));

        double tempBufferLength = 60.0;
        this->getParam("transforms.buffer_length", tempBufferLength, false, 60.0);
        this->tfBufferLength = rclcpp::Duration::from_seconds(tempBufferLength);
        if (this->tfBuffer == nullptr) {
            logger.info("Creating TF buffer with length {}", this->tfBufferLength.seconds());
            this->tfBuffer = std::make_shared<tf2_ros::Buffer>(this->nodeHandle->get_clock(), tf2_ros::fromRclcpp(this->tfBufferLength));
            this->tfListener = std::make_shared<tf2_ros::TransformListener>(*this->tfBuffer);
        } else {
            // clear the TF buffer (useful if calling configure() after receiving old TF data)
            this->tfBuffer->clear();
        }

        this->getParam("frames.fixed", this->fixedFrame, false, "base_link");
        stripLeadingSlash(this->fixedFrame, true);
        this->getParam("frames.sensor", this->sensorFrame);
        stripLeadingSlash(this->sensorFrame, true);
        this->getParam("frames.filtering", this->filteringFrame, false, this->fixedFrame);
        stripLeadingSlash(this->sensorFrame, true);

        this->getParam("sensor.min_distance", this->minDistance, false, 0);
        this->getParam("sensor.max_distance", this->maxDistance, false, 0);

        this->getParam("body_model.robot_description_param", this->robotDescriptionParam, false, "robot_description");

        this->getParam("filter.keep_clouds_organized", this->keepCloudsOrganized, false, true);
        double tempModelPoseUpdateInterval;
        this->getParam("filter.model_pose_update_interval", tempModelPoseUpdateInterval, false, 0);
        this->modelPoseUpdateInterval = rclcpp::Duration::from_seconds(tempModelPoseUpdateInterval);
        bool doClipping;
        this->getParam("filter.do_clipping", doClipping, false, true);
        bool doContainsTest;
        this->getParam("filter.do_contains_test", doContainsTest, false, true);
        bool doShadowTest;
        this->getParam("filter.do_shadow_test", doShadowTest, false, true);
        double maxShadowDistance;
        this->getParam("filter.max_shadow_distance", maxShadowDistance, false, this->maxDistance);

        double tempReachableTransformTimeout;
        this->getParam("transforms.timeout.reachable", tempReachableTransformTimeout, false, 0.1);
        this->reachableTransformTimeout = rclcpp::Duration::from_seconds(tempReachableTransformTimeout);
        double tempUnreachableTransformTimeout;
        this->getParam("transforms.timeout.unreachable", tempUnreachableTransformTimeout, false, 0.2);
        this->unreachableTransformTimeout = rclcpp::Duration::from_seconds(tempUnreachableTransformTimeout);
        this->getParam("transforms.require_all_reachable", this->requireAllFramesReachable, false, false);
        this->getParam("transforms.link_tf_prefix", this->linkTfPrefix, false, "");
        if (!this->linkTfPrefix.empty()) {
            this->linkTfPrefix = this->linkTfPrefix + "/";
        }

        this->getParam("bounding_sphere.publish_cut_out_pointcloud", this->publishNoBoundingSpherePointcloud, false, false);
        this->getParam("bounding_box.publish_cut_out_pointcloud", this->publishNoBoundingBoxPointcloud, false, false);

        this->getParam("oriented_bounding_box.publish_cut_out_pointcloud", this->publishNoOrientedBoundingBoxPointcloud, false, false);

        this->getParam("local_bounding_box.publish_cut_out_pointcloud", this->publishNoLocalBoundingBoxPointcloud, false, false);

        this->getParam("bounding_sphere.compute", this->computeBoundingSphere, false, false);
        this->computeBoundingSphere = this->computeBoundingSphere || this->publishNoBoundingSpherePointcloud;

        this->getParam("bounding_box.compute", this->computeBoundingBox, false, false);
        this->computeBoundingBox = this->computeBoundingBox || this->publishNoBoundingBoxPointcloud;

        this->getParam("oriented_bounding_box.compute", this->computeOrientedBoundingBox, false, false);
        this->computeOrientedBoundingBox = this->computeOrientedBoundingBox || this->publishNoOrientedBoundingBoxPointcloud;

        this->getParam("local_bounding_box.compute", this->computeLocalBoundingBox, false, false);
        this->computeLocalBoundingBox = computeLocalBoundingBox || publishNoLocalBoundingBoxPointcloud;

        this->getParam("bounding_sphere.debug", this->computeDebugBoundingSphere, false, false);
        this->getParam("bounding_box.debug", this->computeDebugBoundingBox, false, false);
        this->getParam("oriented_bounding_box.debug", this->computeDebugOrientedBoundingBox, false, false);
        this->getParam("local_bounding_box.debug", this->computeDebugLocalBoundingBox, false, false);
        this->getParam("bounding_sphere.marker", this->publishBoundingSphereMarker, false, false);
        this->getParam("bounding_box.marker", this->publishBoundingBoxMarker, false, false);
        this->getParam("oriented_bounding_box.marker", this->publishOrientedBoundingBoxMarker, false, false);
        this->getParam("local_bounding_box.marker", this->publishLocalBoundingBoxMarker, false, false);
        this->getParam("local_bounding_box.frame_id", this->localBoundingBoxFrame, false, this->fixedFrame);
        this->getParam("debug.pcl.inside", this->publishDebugPclInside, false, false);
        this->getParam("debug.pcl.clip", this->publishDebugPclClip, false, false);
        this->getParam("debug.pcl.shadow", this->publishDebugPclShadow, false, false);
        this->getParam("debug.marker.contains", this->publishDebugContainsMarker, false, false);
        this->getParam("debug.marker.shadow", this->publishDebugShadowMarker, false, false);
        this->getParam("debug.marker.bounding_sphere", this->publishDebugBsphereMarker, false, false);
        this->getParam("debug.marker.bounding_box", this->publishDebugBboxMarker, false, false);

        double inflationPadding;
        this->getParam("body_model.inflation.padding", inflationPadding, false, 0.0);
        double inflationScale;
        this->getParam("body_model.inflation.scale", inflationScale, false, 1.0);
        this->getParam("body_model.inflation.contains_test.padding", this->defaultContainsInflation.padding, false, inflationPadding);
        this->getParam("body_model.inflation.contains_test.scale", this->defaultContainsInflation.scale, false, inflationScale);
        this->getParam("body_model.inflation.shadow_test.padding", this->defaultShadowInflation.padding, false, inflationPadding);
        this->getParam("body_model.inflation.shadow_test.scale", this->defaultShadowInflation.scale, false, inflationScale);
        this->getParam("body_model.inflation.bounding_sphere.padding", this->defaultBsphereInflation.padding, false, inflationPadding);
        this->getParam("body_model.inflation.bounding_sphere.scale", this->defaultBsphereInflation.scale, false, inflationScale);
        this->getParam("body_model.inflation.bounding_box.padding", this->defaultBboxInflation.padding, false, inflationPadding);
        this->getParam("body_model.inflation.bounding_box.scale", this->defaultBboxInflation.scale, false, inflationScale);

        // read per-link padding
        std::vector<std::string> perLinkInflationPaddingLinks;
        this->getParam("body_model.inflation.per_link.padding_names", perLinkInflationPaddingLinks, false, {});

        for (auto linkName : perLinkInflationPaddingLinks) {
            double padding;
            this->getParam("body_model.inflation.per_link.padding." + linkName, padding, false, std::numeric_limits<double>::quiet_NaN());
            if (std::isnan(padding)) {
                logger.error("parameter '{}' is defined, but 'body_model.inflation.per_link.padding.{}' could not be found", linkName, linkName);
                continue;
            }

            bool containsOnly;
            bool shadowOnly;
            bool bsphereOnly;
            bool bboxOnly;

            linkName = removeSuffix(linkName, CONTAINS_SUFFIX, &containsOnly);
            linkName = removeSuffix(linkName, SHADOW_SUFFIX, &shadowOnly);
            linkName = removeSuffix(linkName, BSPHERE_SUFFIX, &bsphereOnly);
            linkName = removeSuffix(linkName, BBOX_SUFFIX, &bboxOnly);

            if (!shadowOnly && !bsphereOnly && !bboxOnly)
                this->perLinkContainsInflation[linkName] = ScaleAndPadding(this->defaultContainsInflation.scale, padding);
            if (!containsOnly && !bsphereOnly && !bboxOnly)
                this->perLinkShadowInflation[linkName] = ScaleAndPadding(this->defaultShadowInflation.scale, padding);
            if (!containsOnly && !shadowOnly && !bboxOnly)
                this->perLinkBsphereInflation[linkName] = ScaleAndPadding(this->defaultBsphereInflation.scale, padding);
            if (!containsOnly && !shadowOnly && !bsphereOnly)
                this->perLinkBboxInflation[linkName] = ScaleAndPadding(this->defaultBboxInflation.scale, padding);
        }

        // read per-link scale
        std::vector<std::string> perLinkInflationScaleLinks;
        this->getParam("body_model.inflation.per_link.scale_names", perLinkInflationScaleLinks, false, {});

        for (auto linkName : perLinkInflationScaleLinks) {
            double scale;
            this->getParam("body_model.inflation.per_link.scale." + linkName, scale, false, std::numeric_limits<double>::quiet_NaN());
            if (std::isnan(scale)) {
                logger.error("parameter '{}' is defined, but 'body_model.inflation.per_link.scale.{}' could not be found", linkName, linkName);
                continue;
            }

            bool containsOnly;
            bool shadowOnly;
            bool bsphereOnly;
            bool bboxOnly;

            linkName = removeSuffix(linkName, CONTAINS_SUFFIX, &containsOnly);
            linkName = removeSuffix(linkName, SHADOW_SUFFIX, &shadowOnly);
            linkName = removeSuffix(linkName, BSPHERE_SUFFIX, &bsphereOnly);
            linkName = removeSuffix(linkName, BBOX_SUFFIX, &bboxOnly);

            if (!shadowOnly && !bsphereOnly && !bboxOnly) {
                if (!this->perLinkContainsInflation.contains(linkName))
                    this->perLinkContainsInflation[linkName] = ScaleAndPadding(scale, this->defaultContainsInflation.padding);
                else
                    this->perLinkContainsInflation[linkName].scale = scale;
            }

            if (!containsOnly && !bsphereOnly && !bboxOnly) {
                if (!this->perLinkShadowInflation.contains(linkName))
                    this->perLinkShadowInflation[linkName] = ScaleAndPadding(scale, this->defaultShadowInflation.padding);
                else
                    this->perLinkShadowInflation[linkName].scale = scale;
            }

            if (!containsOnly && !shadowOnly && !bboxOnly) {
                if (!this->perLinkBsphereInflation.contains(linkName))
                    this->perLinkBsphereInflation[linkName] = ScaleAndPadding(scale, this->defaultBsphereInflation.padding);
                else
                    this->perLinkBsphereInflation[linkName].scale = scale;
            }

            if (!containsOnly && !shadowOnly && !bsphereOnly) {
                if (!this->perLinkBboxInflation.contains(linkName))
                    this->perLinkBboxInflation[linkName] = ScaleAndPadding(scale, this->defaultBboxInflation.padding);
                else
                    this->perLinkBboxInflation[linkName].scale = scale;
            }
        }

        // can contain either whole link names, or scoped names of their
        // collisions (i.e. "link::collision_1" or "link::my_collision")
        // Note: ROS2 does not by default have a std::set parameter, this was the
        // workaround
        std::vector<std::string> tempLinksIgnoredInBoundingSphereVector;
        this->getParam("ignored_links.bounding_sphere", tempLinksIgnoredInBoundingSphereVector);
        this->linksIgnoredInBoundingSphere.clear();

        std::vector<std::string> tempLinksIgnoredInBoundingBoxVector;
        this->getParam("ignored_links.bounding_box", tempLinksIgnoredInBoundingBoxVector);
        this->linksIgnoredInBoundingBox.clear();
        this->linksIgnoredInBoundingBox.insert(tempLinksIgnoredInBoundingBoxVector.begin(), tempLinksIgnoredInBoundingBoxVector.end());

        std::vector<std::string> tempLinksIgnoredInContainsTest;
        this->getParam("ignored_links.contains_test", tempLinksIgnoredInContainsTest);
        this->linksIgnoredInContainsTest.clear();
        this->linksIgnoredInContainsTest.insert(tempLinksIgnoredInContainsTest.begin(), tempLinksIgnoredInContainsTest.end());

        std::vector<std::string> tempLinksIgnoredInShadowTest;
        this->getParam("ignored_links.shadow_test", tempLinksIgnoredInShadowTest);
        this->linksIgnoredInShadowTest.clear();
        this->linksIgnoredInShadowTest.insert(tempLinksIgnoredInShadowTest.begin(), tempLinksIgnoredInShadowTest.end());

        std::vector<std::string> tempLinksIgnoredEverywhere;
        this->getParam("ignored_links.everywhere", tempLinksIgnoredEverywhere);
        this->linksIgnoredEverywhere.clear();
        this->linksIgnoredEverywhere.insert(tempLinksIgnoredEverywhere.begin(), tempLinksIgnoredEverywhere.end());

        std::vector<std::string> tempOnlyLinks;
        this->getParam("only_links", tempOnlyLinks);
        this->onlyLinks.clear();
        this->onlyLinks.insert(tempOnlyLinks.begin(), tempOnlyLinks.end());

        this->getParam("body_model.dynamic_robot_description.field_name", this->robotDescriptionUpdatesFieldName);

        //TODO: Reload service
        // this->reloadRobotModelServiceServer = this->nodeHandle->template create_service<std_srvs::srv::Trigger>(
        //     "reload_model", std::bind(&RobotBodyFilter::triggerModelReload, this, std::placeholders::_1, std::placeholders::_2));

        if (this->computeBoundingSphere) {
            this->boundingSpherePublisher = nodeHandle->create_publisher<SphereStampedMsg>("robot_bounding_sphere", 100);
        }

        if (this->computeBoundingBox) {
            this->boundingBoxPublisher = nodeHandle->create_publisher<PolygonStampedMsg>("robot_bounding_box", 100);
        }

        if (this->computeOrientedBoundingBox) {
            this->orientedBoundingBoxPublisher = nodeHandle->create_publisher<OrientedBoundingBoxStampedMsg>("robot_oriented_bounding_box", 100);
        }

        if (this->computeLocalBoundingBox) {
            this->localBoundingBoxPublisher = nodeHandle->create_publisher<PolygonStampedMsg>("robot_local_bounding_box", 100);
        }

        if (this->publishBoundingSphereMarker && this->computeBoundingSphere) {
            this->boundingSphereMarkerPublisher = this->nodeHandle->create_publisher<MarkerMsg>("robot_bounding_sphere_marker", 100);
        }

        if (this->publishBoundingBoxMarker && this->computeBoundingBox) {
            this->boundingBoxMarkerPublisher = this->nodeHandle->create_publisher<MarkerMsg>("robot_bounding_box_marker", 100);
        }

        if (this->publishOrientedBoundingBoxMarker && this->computeOrientedBoundingBox) {
            this->orientedBoundingBoxMarkerPublisher = this->nodeHandle->create_publisher<MarkerMsg>("robot_oriented_bounding_box_marker", 100);
        }

        if (this->publishLocalBoundingBoxMarker && this->computeLocalBoundingBox) {
            this->localBoundingBoxMarkerPublisher = this->nodeHandle->create_publisher<MarkerMsg>("robot_local_bounding_box_marker", 100);
        }

        if (this->publishNoBoundingBoxPointcloud) {
            this->scanPointCloudNoBoundingBoxPublisher = this->nodeHandle->create_publisher<PointCloud2Msg>("scan_point_cloud_no_bbox", 100);
        }

        if (this->publishNoOrientedBoundingBoxPointcloud) {
            this->scanPointCloudNoOrientedBoundingBoxPublisher = this->nodeHandle->create_publisher<PointCloud2Msg>("scan_point_cloud_no_oriented_bbox", 100);
        }

        if (this->publishNoLocalBoundingBoxPointcloud) {
            this->scanPointCloudNoLocalBoundingBoxPublisher = this->nodeHandle->create_publisher<PointCloud2Msg>("scan_point_cloud_no_local_bbox", 100);
        }

        if (this->publishNoBoundingSpherePointcloud) {
            this->scanPointCloudNoBoundingSpherePublisher = this->nodeHandle->create_publisher<PointCloud2Msg>("scan_point_cloud_no_bsphere", 100);
        }

        if (this->publishDebugPclInside) {
            this->debugPointCloudInsidePublisher = this->nodeHandle->create_publisher<PointCloud2Msg>("scan_point_cloud_inside", 100);
        }

        if (this->publishDebugPclClip) {
            this->debugPointCloudClipPublisher = this->nodeHandle->create_publisher<PointCloud2Msg>("scan_point_cloud_clip", 100);
        }

        if (this->publishDebugPclShadow) {
            this->debugPointCloudShadowPublisher = this->nodeHandle->create_publisher<PointCloud2Msg>("scan_point_cloud_shadow", 100);
        }

        if (this->publishDebugContainsMarker) {
            this->debugContainsMarkerPublisher = this->nodeHandle->create_publisher<MarkerArrayMsg>("robot_model_for_contains_test", 100);
        }

        if (this->publishDebugShadowMarker) {
            this->debugShadowMarkerPublisher = this->nodeHandle->create_publisher<MarkerArrayMsg>("robot_model_for_shadow_test", 100);
        }

        if (this->publishDebugBsphereMarker) {
            this->debugBsphereMarkerPublisher = this->nodeHandle->create_publisher<MarkerArrayMsg>("robot_model_for_bounding_sphere", 100);
        }

        if (this->publishDebugBboxMarker) {
            this->debugBboxMarkerPublisher = this->nodeHandle->create_publisher<MarkerArrayMsg>("robot_model_for_bounding_box", 100);
        }

        if (this->computeDebugBoundingBox) {
            this->boundingBoxDebugMarkerPublisher = this->nodeHandle->create_publisher<MarkerArrayMsg>("robot_bounding_box_debug", 100);
        }

        if (this->computeDebugOrientedBoundingBox) {
            this->orientedBoundingBoxDebugMarkerPublisher = this->nodeHandle->create_publisher<MarkerArrayMsg>("robot_oriented_bounding_box_debug", 100);
        }

        if (this->computeDebugLocalBoundingBox) {
            this->localBoundingBoxDebugMarkerPublisher = this->nodeHandle->create_publisher<MarkerArrayMsg>("robot_local_bounding_box_debug", 100);
        }

        if (this->computeDebugBoundingSphere) {
            this->boundingSphereDebugMarkerPublisher = this->nodeHandle->create_publisher<MarkerArrayMsg>("robot_bounding_sphere_debug", 100);
        }

        // initialize the 3D body masking tool
        shapeMask = std::make_unique<RayCastingShapeMask>(
            this->nodeHandle,
            [this](auto shapeHandle, auto transform) -> bool {
                return getShapeTransform(shapeHandle, transform);
            },
            this->minDistance,
            this->maxDistance,
            doClipping,
            doContainsTest,
            doShadowTest,
            maxShadowDistance
        );

        // the other case happens when configure() is called again from
        // update() (e.g. when a new bag file
        // started playing)
        if (this->tfFramesWatchdog == nullptr) {
            std::set<std::string> initialMonitoredFrames;
            if (!this->sensorFrame.empty()) {
                initialMonitoredFrames.insert(this->sensorFrame);
            }
            // TODO 2026-02-22 (solonovamax): make configurable?
            auto loop_rate = std::make_shared<rclcpp::Rate>(rclcpp::Duration::from_seconds(1.0).nanoseconds());
            logger.debug("Creating TF frames watchdog");
            logger.debug("Filtering data in frame {}", this->filteringFrame);
            this->tfFramesWatchdog = std::make_shared<TFFramesWatchdog>(
                this->logging_interface_->get_logger(),
                this->nodeHandle, this->filteringFrame, initialMonitoredFrames,
                this->tfBuffer, this->unreachableTransformTimeout, loop_rate
            );
            this->tfFramesWatchdog->start();
        }

        // TODO 2026-02-22 (solonovamax): robot_description is actually a topic, and we should probably subscribe to it instead?
        AsyncCallbackGroup = nodeHandle->create_callback_group(rclcpp::CallbackGroupType::Reentrant, true);
        rclcpp::QoS qos(rclcpp::KeepLast(10));
        const rmw_qos_profile_t& qos_profile = qos.get_rmw_qos_profile();
        robotDescriptionUpdatesListener = std::make_shared<rclcpp::AsyncParametersClient>(
            this->nodeHandle, "/robot_state_publisher", qos_profile, AsyncCallbackGroup
        );
        auto parameters_future = robotDescriptionUpdatesListener->get_parameters({"robot_description"}, [this](const auto& future) {
            const auto msg = std::make_shared<StringMsg>();
            msg->data = future.get()[0].as_string();
            logger.debug("New URDF: {}", msg->data);
            robotDescriptionUpdated(msg);
        });

        // TODO 2026-02-22 (solonovamax): wait for the future to resolve?
        // parameters_future.wait();

        // {  // initialize the robot body to be masked out
        //   auto sleeper = rclcpp::Rate(rclcpp::Duration::from_seconds(1.0).nanoseconds());
        //   std::string robotUrdf;
        //   while (!this->nodeHandle->get_parameter(this->robotDescriptionParam.c_str(), robotUrdf) || robotUrdf.length() == 0) {
        //     if (this->failWithoutRobotDescription) {
        //       throw std::runtime_error("RobotBodyFilter: " + this->robotDescriptionParam + " is empty or not set.");
        //     }
        //     if (!rclcpp::ok()) return false;

        //     logger.error("RobotBodyFilter: {} is empty or not set. Please, provide "
        //                  "the robot model. Waiting 1s. ",
        //                  robotDescriptionParam);
        //     rclcpp::sleep_for(std::chrono::seconds(1));
        //   }

        //   // happens when configure() is called again from update() (e.g. when
        //   // a new bag file started
        //   // playing)
        //   if (!this->shapesToLinks.empty()) this->clearRobotMask();
        //   this->addRobotMaskFromUrdf(robotUrdf);
        // }

        logger.info("RobotBodyFilter: Successfully configured.");
        logger.info("Filtering data inframe {}", this->filteringFrame);
        logger.info("RobotBodyFilter: Filtering into the following categories:");
        logger.info("RobotBodyFilter: \tOUTSIDE");
        if (doClipping)
            logger.info("RobotBodyFilter: \tCLIP");
        if (doContainsTest)
            logger.info("RobotBodyFilter: \tINSIDE");
        if (doShadowTest)
            logger.info("RobotBodyFilter: \tSHADOW");

        if (this->onlyLinks.empty()) {
            logger.info("RobotBodyFilter: onlyLinks is empty");
            if (this->linksIgnoredEverywhere.empty()) {
                logger.info("RobotBodyFilter: Filtering applied to all links.");
            } else {
                logger.info("RobotBodyFilter: Filtering applied to all links except {}.", this->linksIgnoredEverywhere);
            }
        } else {
            if (this->linksIgnoredEverywhere.empty()) {
                logger.info("RobotBodyFilter: Filtering applied to links {}.", this->onlyLinks);
            } else {
                logger.info("RobotBodyFilter: Filtering applied to links {} with these links excluded: {}.", tempOnlyLinks, tempLinksIgnoredEverywhere);
            }
        }

        this->timeConfigured = this->nodeHandle->now();

        return true;
    }

    template <typename T>
    bool RobotBodyFilter<T>::computeMask(
        const PointCloud2Msg& projectedPointCloud,
        std::vector<RayCastingShapeMask::MaskValue>& pointMask,
        const std::string& sensorFrame
    ) {
        // this->modelMutex has to be already locked!
        logger.debug("Computing Mask");
        using clock = std::chrono::steady_clock;
        const auto startCompute = clock::now();
        const auto& scanTime = projectedPointCloud.header.stamp;

        // compute a mask of point indices for points from projectedPointCloud
        // that tells if they are inside or outside robot, or shadow points
        if (!this->pointByPointScan) {
            Eigen::Vector3d sensorPosition;
            try {
                const auto sensorTf = this->tfBuffer->lookupTransform(
                    this->filteringFrame, sensorFrame, scanTime,
                    remainingTime(*this->nodeHandle->get_clock(), scanTime, this->reachableTransformTimeout)
                );
                tf2::fromMsg(sensorTf.transform.translation, sensorPosition);
            } catch (tf2::TransformException& e) {
                logger.error("RobotBodyFilter: Could not compute filtering mask due to this TF exception: {}", e.what());
                return false;
            }

            // update transforms cache, which is then used in body masking
            this->updateTransformCache(scanTime);

            // updates shapes according to tf cache (by calling getShapeTransform
            // for each shape) and masks contained points
            this->shapeMask->maskContainmentAndShadows(projectedPointCloud, pointMask, sensorPosition);
        } else {
            auto x_it = CloudConstIter(projectedPointCloud, "x");
            auto y_it = CloudConstIter(projectedPointCloud, "y");
            auto z_it = CloudConstIter(projectedPointCloud, "z");
            auto vp_x_it = CloudConstIter(projectedPointCloud, "vp_x");
            auto vp_y_it = CloudConstIter(projectedPointCloud, "vp_y");
            auto vp_z_it = CloudConstIter(projectedPointCloud, "vp_z");
            auto stamps_it = CloudConstIter(projectedPointCloud, "stamps");

            pointMask.resize(num_points(projectedPointCloud));

            double scanDuration = 0.0;
            for (auto stamps_end_it = CloudConstIter(projectedPointCloud, "stamps"); stamps_end_it != stamps_end_it.end(); ++stamps_end_it) {
                if (*stamps_end_it > static_cast<float>(scanDuration))
                    scanDuration = static_cast<double>(*stamps_end_it);
            }

            const auto afterScanTime = rclcpp::Time(scanTime) + rclcpp::Duration::from_seconds(scanDuration);

            size_t updateBodyPosesEvery;
            if (this->modelPoseUpdateInterval.seconds() == 0 && this->modelPoseUpdateInterval.nanoseconds() == 0) {
                updateBodyPosesEvery = 1;
            } else {
                updateBodyPosesEvery = static_cast<size_t>(std::ceil(this->modelPoseUpdateInterval.seconds() / scanDuration * num_points(projectedPointCloud)));
                // prevent division by zero
                if (updateBodyPosesEvery == 0)
                    updateBodyPosesEvery = 1;
            }

            // prevent division by zero in ratio computation in case the pointcloud
            // isn't really taken point by point with different timestamps
            if (scanDuration == 0.0) {
                updateBodyPosesEvery = num_points(projectedPointCloud) + 1;
                logger.warn_once(
                    "RobotBodyFilter: sensor/point_by_point is set to true but all points in the cloud have the same timestamp. "
                    "You should change the parameter to false to gain performance."
                );
            }

            // update transforms cache, which is then used in body masking
            this->updateTransformCache(scanTime, afterScanTime);

            Eigen::Vector3f point;
            Eigen::Vector3d viewPoint;
            RayCastingShapeMask::MaskValue mask;

            this->cacheLookupBetweenScansRatio = 0.0;
            for (size_t i = 0; i < num_points(projectedPointCloud); ++i, ++x_it, ++y_it, ++z_it, ++vp_x_it, ++vp_y_it, ++vp_z_it, ++stamps_it) {
                point.x() = *x_it;
                point.y() = *y_it;
                point.z() = *z_it;

                // TODO viewpoint can be autocomputed from stamps
                viewPoint.x() = static_cast<double>(*vp_x_it);
                viewPoint.y() = static_cast<double>(*vp_y_it);
                viewPoint.z() = static_cast<double>(*vp_z_it);

                const auto updateBodyPoses = i % updateBodyPosesEvery == 0;

                if (updateBodyPoses && scanDuration > 0.0)
                    this->cacheLookupBetweenScansRatio = static_cast<double>(*stamps_it) / scanDuration;

                // updates shapes according to tf cache (by calling getShapeTransform
                // for each shape) and masks contained points
                this->shapeMask->maskContainmentAndShadows(point, mask, viewPoint, updateBodyPoses);
                pointMask[i] = mask;
            }
        }

        logger.debug("RobotBodyFilter: Mask computed in {:.5%S} secs.", clock::now() - startCompute);

        this->publishDebugPointClouds(projectedPointCloud, pointMask);
        this->publishDebugMarkers(scanTime);
        this->computeAndPublishBoundingSphere(projectedPointCloud);
        this->computeAndPublishBoundingBox(projectedPointCloud);
        this->computeAndPublishOrientedBoundingBox(projectedPointCloud);
        this->computeAndPublishLocalBoundingBox(projectedPointCloud);

        logger.debug("RobotBodyFilter: Filtering run time is {:.5%S} secs.", clock::now() - startCompute);
        return true;
    }

    template <typename T>
    bool RobotBodyFilter<T>::getShapeTransform(const point_containment_filter::ShapeHandle shapeHandle, Eigen::Isometry3d& transform) const {
        // make sure you locked this->modelMutex

        // check if the given shapeHandle has been registered to a link during
        // addRobotMaskFromUrdf call.
        if (!this->shapesToLinks.contains(shapeHandle)) {
            auto& clk = *nodeHandle->get_clock();
            logger.error_throttle(rclcpp::Duration::from_seconds(3), "RobotBodyFilter: Invalid shape handle: {}", shapeHandle);
            return false;
        }

        const auto& collision = this->shapesToLinks.at(shapeHandle);

        if (!this->transformCache.contains(collision.cacheKey)) {
            // do not log the error because shape mask would do it for us
            return false;
        }

        if (!this->pointByPointScan) {
            transform = *this->transformCache.at(collision.cacheKey);
        } else {
            if (!this->transformCacheAfterScan.contains(collision.cacheKey)) {
                // do not log the error because shape mask would do it for us
                return false;
            }

            const auto& tf1 = *this->transformCache.at(collision.cacheKey);
            const auto& tf2 = *this->transformCacheAfterScan.at(collision.cacheKey);
            const Eigen::Quaterniond quat1(tf1.rotation().matrix());
            const Eigen::Quaterniond quat2(tf1.rotation().matrix());
            const auto r = this->cacheLookupBetweenScansRatio;

            transform.translation() = tf1.translation() * (1 - r) + tf2.translation() * r;
            const Eigen::Quaterniond quat3 = quat1.slerp(r, quat2);
            transform.linear() = quat3.toRotationMatrix();
        }

        return true;
    }

    template <typename T>
    void RobotBodyFilter<T>::addRobotMaskFromUrdf(const std::string& urdfModel) {
        if (urdfModel.empty()) {
            logger.error("RobotBodyFilter: Empty string passed as robot model to addRobotMaskFromUrdf. Robot body filtering is not going to work.");
            return;
        }

        // parse the URDF model
        urdf::Model parsedUrdfModel;
        if (bool urdfParseSucceeded = parsedUrdfModel.initString(urdfModel); !urdfParseSucceeded) {
            logger.error(
                "RobotBodyFilter: The URDF model given in parameter {} cannot be parsed. "
                "See urdf::Model::initString for debugging, or try running gzsdf my_robot.urdf",
                this->robotDescriptionParam
            );
            return;
        }

        {
            std::lock_guard _(*this->modelMutex);

            this->shapesIgnoredInBoundingSphere.clear();
            this->shapesIgnoredInBoundingBox.clear();
            std::unordered_set<MultiShapeHandle> ignoreInContainsTest = {};
            std::unordered_set<MultiShapeHandle> ignoreInShadowTest = {};

            // add all model's collision links as masking shapes
            for (const auto& [linkName, link] : parsedUrdfModel.links_) {
                logger.debug("RobotBodyFilter: Adding link {} to the mask.", linkName);

                // every link can have multiple collision elements
                size_t collisionIndex = 0;
                for (const auto& collision : link->collision_array) {
                    if (collision->geometry == nullptr) {
                        logger.warn(
                            "RobotBodyFilter: Collision element without geometry found in link {} of robot {}. "
                            "This collision element will not be filtered out.",
                            link->name, parsedUrdfModel.getName()
                        );
                        continue; // collisionIndex is intentionally not increased
                    }

                    const auto NAME_LINK = link->name;
                    const auto NAME_COLLISION_NAME = "*::" + collision->name;
                    const auto NAME_LINK_COLLISION_NR = link->name + "::" + std::to_string(collisionIndex);
                    const auto NAME_LINK_COLLISON_NAME = link->name + "::" + collision->name;

                    const auto collisionNames = std::vector{
                        NAME_LINK,
                        NAME_COLLISION_NAME,
                        NAME_LINK_COLLISION_NR,
                        NAME_LINK_COLLISON_NAME,
                    };

                    std::set<std::string> collisionNamesSet = {};
                    std::set<std::string> collisionNamesContains = {};
                    std::set<std::string> collisionNamesShadow = {};
                    for (const auto& name : collisionNames) {
                        collisionNamesSet.insert(name);
                        collisionNamesContains.insert(name + CONTAINS_SUFFIX);
                        collisionNamesShadow.insert(name + SHADOW_SUFFIX);
                    }

                    // if onlyLinks is nonempty, make sure this collision belongs to a
                    // specified link
                    if (!this->onlyLinks.empty()) {
                        if (isSetIntersectionEmpty(collisionNamesSet, this->onlyLinks)) {
                            ++collisionIndex;
                            continue;
                        }
                    }

                    // if the link is ignored, go on
                    if (!isSetIntersectionEmpty(collisionNamesSet, this->linksIgnoredEverywhere)) {
                        ++collisionIndex;
                        continue;
                    }

                    const auto collisionShape = constructShape(*collision->geometry);
                    const auto shapeName = collision->name.empty() ? NAME_LINK_COLLISION_NR : NAME_LINK_COLLISON_NAME;

                    // if the shape could not be constructed, ignore it (e.g. mesh was not
                    // found)
                    if (collisionShape == nullptr) {
                        logger.warn("Could not construct shape for collision {}, ignoring it.", shapeName);
                        ++collisionIndex;
                        continue;
                    }

                    // add the collision shape to shapeMask; the inflation parameters come
                    // into play here
                    const auto containsTestInflation = this->getLinkInflationForContainsTest(collisionNames);
                    const auto shadowTestInflation = this->getLinkInflationForShadowTest(collisionNames);
                    const auto bsphereInflation = this->getLinkInflationForBoundingSphere(collisionNames);
                    const auto bboxInflation = this->getLinkInflationForBoundingBox(collisionNames);
                    const auto shapeHandle = this->shapeMask->addShape(
                        collisionShape,
                        containsTestInflation.scale, containsTestInflation.padding,
                        shadowTestInflation.scale, shadowTestInflation.padding,
                        bsphereInflation.scale, bsphereInflation.padding,
                        bboxInflation.scale, bboxInflation.padding,
                        false, shapeName
                    );
                    const auto shapeLink = CollisionBodyWithLink(collision, link, collisionIndex, shapeHandle);
                    this->shapesToLinks[shapeHandle.contains] = shapeLink;
                    this->shapesToLinks[shapeHandle.shadow] = shapeLink;
                    this->shapesToLinks[shapeHandle.bsphere] = shapeLink;
                    this->shapesToLinks[shapeHandle.bbox] = shapeLink;

                    if (!isSetIntersectionEmpty(collisionNamesSet, this->linksIgnoredInBoundingSphere)) {
                        this->shapesIgnoredInBoundingSphere.insert(shapeHandle.bsphere);
                    }

                    if (!isSetIntersectionEmpty(collisionNamesSet, this->linksIgnoredInBoundingBox)) {
                        this->shapesIgnoredInBoundingBox.insert(shapeHandle.bbox);
                    }

                    if (!isSetIntersectionEmpty(collisionNamesSet, this->linksIgnoredInContainsTest)) {
                        ignoreInContainsTest.insert(shapeHandle);
                    }

                    if (!isSetIntersectionEmpty(collisionNamesSet, this->linksIgnoredInShadowTest)) {
                        ignoreInShadowTest.insert(shapeHandle);
                    }

                    ++collisionIndex;
                }

                // no collision element found; only warn for links that are not ignored
                // and have at least one visual
                if (collisionIndex == 0 && !link->visual_array.empty()) {
                    if ((this->onlyLinks.empty() || this->onlyLinks.contains(link->name)) &&
                        !this->linksIgnoredEverywhere.contains(link->name)) {
                        logger.warn(
                            "RobotBodyFilter: No collision element found for link {} of robot {}."
                            "This link will not be filtered out from laser scans.",
                            link->name, parsedUrdfModel.getName()
                        );
                    }
                }
            }

            this->shapeMask->setIgnoreInContainsTest(ignoreInContainsTest);
            this->shapeMask->setIgnoreInShadowTest(ignoreInShadowTest);

            this->shapeMask->updateInternalShapeLists();

            std::set<std::string> monitoredFrames;
            for (const auto& shapeToLink : this->shapesToLinks) monitoredFrames.insert(shapeToLink.second.link->name);

            // Issue #6: Monitor sensor frame even if it is not a part of the model
            if (!this->sensorFrame.empty())
                monitoredFrames.insert(this->sensorFrame);

            this->tfFramesWatchdog->setMonitoredFrames(monitoredFrames);
        }
    }

    template <typename T>
    void RobotBodyFilter<T>::clearRobotMask() {
        {
            logger.info("RobotBodyFilter: modelMutex not yet locked.");

            std::lock_guard _(*this->modelMutex);

            logger.info("RobotBodyFilter: modelMutex locked.");

            std::unordered_set<MultiShapeHandle> removedMultiShapes;
            for (const auto& [shape, collisionBody] : this->shapesToLinks) {
                if (const auto& multiShape = collisionBody.multiHandle; !removedMultiShapes.contains(multiShape)) {
                    this->shapeMask->removeShape(multiShape, false);
                    removedMultiShapes.insert(multiShape);
                }
            }
            this->shapeMask->updateInternalShapeLists();

            this->shapesToLinks.clear();
            this->shapesIgnoredInBoundingSphere.clear();
            this->shapesIgnoredInBoundingBox.clear();
            this->transformCache.clear();
            this->transformCacheAfterScan.clear();
        }

        this->tfFramesWatchdog->clear();
    }

    template <typename T>
    void RobotBodyFilter<T>::updateTransformCache(const rclcpp::Time& time, const rclcpp::Time& afterScanTime) {
        // make sure you locked this->modelMutex

        // clear the cache so that maskContainment always uses only these tf data and
        // not some older
        this->transformCache.clear();

        if (afterScanTime.seconds() != 0)
            this->transformCacheAfterScan.clear();

        // iterate over all links corresponding to some masking shape and update their
        // cached transforms relative to fixed_frame
        for (const auto& [shape, collisionBody] : this->shapesToLinks) {
            const auto& collision = collisionBody.collision;
            const auto& link = collisionBody.link;

            // here we assume the tf frames' names correspond to the link names
            const auto linkFrame = this->linkTfPrefix + link->name;

            // the collision object may have a different origin than the visual, we need
            // to account for that
            const auto& collisionOffsetTransform = urdfPose2EigenTransform(collision->origin);

            {
                auto linkTransformTfOptional = this->tfFramesWatchdog->lookupTransform(
                    linkFrame, time,
                    remainingTime(*this->nodeHandle->get_clock(), time, this->reachableTransformTimeout)
                );

                if (!linkTransformTfOptional) // has no value
                    continue;

                const auto& linkTransformTf = linkTransformTfOptional.value();
                const auto& linkTransformEigen = tf2::transformToEigen(linkTransformTf);

                const auto& transform = linkTransformEigen * collisionOffsetTransform;

                const auto allocator = Eigen::aligned_allocator<Eigen::Isometry3d>();
                this->transformCache[collisionBody.cacheKey] = std::allocate_shared<Eigen::Isometry3d>(allocator, transform);
            }

            if (afterScanTime.seconds() != 0) {
                auto linkTransformTfOptional = this->tfFramesWatchdog->lookupTransform(
                    linkFrame, afterScanTime,
                    remainingTime(*this->nodeHandle->get_clock(), time, this->reachableTransformTimeout)
                );

                if (!linkTransformTfOptional) // has no value
                    continue;

                const auto& linkTransformTf = linkTransformTfOptional.value();
                const auto& linkTransformEigen = tf2::transformToEigen(linkTransformTf);

                const auto& transform = linkTransformEigen * collisionOffsetTransform;

                const auto allocator = Eigen::aligned_allocator<Eigen::Isometry3d>();
                this->transformCacheAfterScan[collisionBody.cacheKey] = std::allocate_shared<Eigen::Isometry3d>(allocator, transform);
            }
        }
    }

    // ROS1 requires this dynamic reconfig, I believe we can simply get parameter again in ROS2
    template <typename T>
    void RobotBodyFilter<T>::robotDescriptionUpdated(const StringMsg::SharedPtr& msg) {
        const auto& urdf = msg->data;
        // robot_description parameter was not found, so we don't have to restart
        // the filter
        if (urdf.empty()) return;

        logger.info("RobotBodyFilter: Reloading robot model because of dynamic_reconfigure update. Filter operation stopped.");

        this->tfFramesWatchdog->pause();
        this->configured_ = false;

        logger.debug("RobotBodyFilter: tfWatchdog paused and configured set to false.");

        this->clearRobotMask();

        logger.debug("RobotBodyFilter: Robot mask cleared. Reloading robot model.");

        this->addRobotMaskFromUrdf(urdf);

        logger.debug("RobotBodyFilter: Robot mask succesfully added from URDF");

        this->tfFramesWatchdog->unpause();
        this->timeConfigured = nodeHandle->now();
        this->configured_ = true;

        logger.debug("RobotBodyFilter: Robot model reloaded, resuming filter operation.");
    }

    template <typename T>
    bool RobotBodyFilter<T>::triggerModelReload(std_srvs::srv::Trigger_Request&, std_srvs::srv::Trigger_Response&) {
        std::string urdf;
        auto success = this->getParam(this->robotDescriptionParam, urdf);

        if (!success) {
            logger.error("RobotBodyFilter: Parameter {} doesn't exist.", this->robotDescriptionParam.c_str());
            return false;
        }

        logger.info("RobotBodyFilter: Reloading robot model because of trigger. Filter operation stopped.");

        this->tfFramesWatchdog->pause();
        this->configured_ = false;

        this->clearRobotMask();
        this->addRobotMaskFromUrdf(urdf);

        this->tfFramesWatchdog->unpause();
        this->timeConfigured = nodeHandle->now();
        this->configured_ = true;

        logger.info("RobotBodyFilter: Robot model reloaded, resuming filter operation.");
        return true;
    }

    template <typename T>
    void RobotBodyFilter<T>::createBodyVisualizationMsg(
        const std::map<point_containment_filter::ShapeHandle, const bodies::Body*>& bodies,
        const rclcpp::Time& stamp,
        const ColorRGBAMsg& color,
        MarkerArrayMsg& markerArray
    ) const {
        // when computing the markers for publication, we want to publish them to the
        // time of the scan, so we need to set cacheLookupBetweenScansRatio again to
        // zero
        if (this->cacheLookupBetweenScansRatio != 0.0) {
            this->cacheLookupBetweenScansRatio = 0.0;
            this->shapeMask->updateBodyPoses();
        }

        for (const auto& [shapeHandle, body] : bodies) {
            MarkerMsg msg;
            bodies::constructMarkerFromBody(body, msg);

            msg.header.stamp = stamp;
            msg.header.frame_id = this->filteringFrame;

            msg.color = color;
            msg.action = MarkerMsg::ADD;
            msg.ns = this->shapesToLinks.at(shapeHandle).cacheKey;
            msg.frame_locked = true;

            markerArray.markers.push_back(msg);
        }
    }

    template <typename T>
    void RobotBodyFilter<T>::publishDebugMarkers(const rclcpp::Time& scanTime) const {
        // assume this->modelMutex is locked

        if (this->publishDebugContainsMarker) {
            MarkerArrayMsg markerArray;
            ColorRGBAMsg color;
            color.g = 1.0;
            color.a = 0.5;
            createBodyVisualizationMsg(this->shapeMask->getBodiesForContainsTest(), scanTime, color, markerArray);
            this->debugContainsMarkerPublisher->publish(markerArray);
        }

        if (this->publishDebugShadowMarker) {
            MarkerArrayMsg markerArray;
            ColorRGBAMsg color;
            color.b = 1.0;
            color.a = 0.5;
            createBodyVisualizationMsg(this->shapeMask->getBodiesForShadowTest(), scanTime, color, markerArray);
            this->debugShadowMarkerPublisher->publish(markerArray);
        }

        if (this->publishDebugBsphereMarker) {
            MarkerArrayMsg markerArray;
            ColorRGBAMsg color;
            color.g = 1.0;
            color.b = 1.0;
            color.a = 0.5;
            createBodyVisualizationMsg(this->shapeMask->getBodiesForBoundingSphere(), scanTime, color, markerArray);
            this->debugBsphereMarkerPublisher->publish(markerArray);
        }

        if (this->publishDebugBboxMarker) {
            MarkerArrayMsg markerArray;
            ColorRGBAMsg color;
            color.r = 1.0;
            color.b = 1.0;
            color.a = 0.5;
            createBodyVisualizationMsg(this->shapeMask->getBodiesForBoundingBox(), scanTime, color, markerArray);
            this->debugBboxMarkerPublisher->publish(markerArray);
        }
    }

    template <typename T>
    void RobotBodyFilter<T>::publishDebugPointClouds(const PointCloud2Msg& projectedPointCloud,
                                                     const std::vector<RayCastingShapeMask::MaskValue>& pointMask) const {
        if (this->publishDebugPclInside) {
            PointCloud2Msg insideCloud;
            CREATE_FILTERED_CLOUD(
                projectedPointCloud, insideCloud, this->keepCloudsOrganized,
                (pointMask[i] == RayCastingShapeMask::MaskValue::INSIDE)
            );
            this->debugPointCloudInsidePublisher->publish(insideCloud);
        }

        if (this->publishDebugPclClip) {
            PointCloud2Msg clipCloud;
            CREATE_FILTERED_CLOUD(
                projectedPointCloud, clipCloud, this->keepCloudsOrganized,
                (pointMask[i] == RayCastingShapeMask::MaskValue::CLIP)
            );
            this->debugPointCloudClipPublisher->publish(clipCloud);
        }

        if (this->publishDebugPclShadow) {
            PointCloud2Msg shadowCloud;
            CREATE_FILTERED_CLOUD(
                projectedPointCloud, shadowCloud, this->keepCloudsOrganized,
                (pointMask[i] == RayCastingShapeMask::MaskValue::SHADOW)
            );
            this->debugPointCloudShadowPublisher->publish(shadowCloud);
        }
    }

    template <typename T>
    void RobotBodyFilter<T>::computeAndPublishBoundingSphere(
        const PointCloud2Msg& projectedPointCloud
    ) const {
        if (!this->computeBoundingSphere && !this->computeDebugBoundingSphere)
            return;

        logger.debug("Computing and Publishing Bounding Sphere");

        // assume this->modelMutex is locked

        // when computing bounding spheres for publication, we want to publish them to
        // the time of the scan, so we need to set cacheLookupBetweenScansRatio again
        // to zero
        if (this->cacheLookupBetweenScansRatio != 0.0) {
            this->cacheLookupBetweenScansRatio = 0.0;
            this->shapeMask->updateBodyPoses();
        }

        const auto& scanTime = projectedPointCloud.header.stamp;
        std::vector<bodies::BoundingSphere> spheres;
        {
            MarkerArrayMsg boundingSphereDebugMsg;

            for (const auto& [shapeHandle, body] : this->shapeMask->getBodiesForBoundingSphere()) {
                if (this->shapesIgnoredInBoundingSphere.contains(shapeHandle))
                    continue;

                bodies::BoundingSphere sphere;
                body->computeBoundingSphere(sphere);

                spheres.push_back(sphere);
                if (this->computeDebugBoundingSphere) {
                    MarkerMsg msg;
                    msg.header.stamp = scanTime;
                    msg.header.frame_id = this->filteringFrame;

                    msg.scale.x = msg.scale.y = msg.scale.z = sphere.radius * 2;

                    msg.pose.position.x = sphere.center[0];
                    msg.pose.position.y = sphere.center[1];
                    msg.pose.position.z = sphere.center[2];
                    msg.pose.orientation.w = 1;

                    msg.color.g = 1.0;
                    msg.color.a = 0.5;
                    msg.type = MarkerMsg::SPHERE;
                    msg.action = MarkerMsg::ADD;
                    msg.ns = "bsphere/" + this->shapesToLinks.at(shapeHandle).cacheKey;
                    msg.frame_locked = true;

                    boundingSphereDebugMsg.markers.push_back(msg);
                }
            }

            if (this->computeDebugBoundingSphere) {
                this->boundingSphereDebugMarkerPublisher->publish(boundingSphereDebugMsg);
            }
        }

        if (this->computeBoundingSphere) {
            bodies::BoundingSphere boundingSphere;
            bodies::mergeBoundingSpheres(spheres, boundingSphere);

            SphereStampedMsg boundingSphereMsg;
            boundingSphereMsg.header.stamp = scanTime;
            boundingSphereMsg.header.frame_id = this->filteringFrame;
            boundingSphereMsg.sphere.radius = static_cast<float>(boundingSphere.radius);
            boundingSphereMsg.sphere.center = tf2::toMsg(boundingSphere.center);

            this->boundingSpherePublisher->publish(boundingSphereMsg);

            if (this->publishBoundingSphereMarker) {
                MarkerMsg msg;
                msg.header.stamp = scanTime;
                msg.header.frame_id = this->filteringFrame;

                msg.scale.x = msg.scale.y = msg.scale.z = boundingSphere.radius * 2;

                msg.pose.position.x = boundingSphere.center[0];
                msg.pose.position.y = boundingSphere.center[1];
                msg.pose.position.z = boundingSphere.center[2];
                msg.pose.orientation.w = 1;

                msg.color.g = 1.0;
                msg.color.a = 0.5;
                msg.type = MarkerMsg::SPHERE;
                msg.action = MarkerMsg::ADD;
                msg.ns = "bounding_sphere";
                msg.frame_locked = true;

                this->boundingSphereMarkerPublisher->publish(msg);
            }

            if (this->publishNoBoundingSpherePointcloud) {
                PointCloud2Msg noSphereCloud;
                CREATE_FILTERED_CLOUD(
                    projectedPointCloud, noSphereCloud, this->keepCloudsOrganized,
                    ((Eigen::Vector3d(*x_it, *y_it, *z_it) - boundingSphere.center).norm() > boundingSphere.radius)
                );
                this->scanPointCloudNoBoundingSpherePublisher->publish(noSphereCloud);
            }
        }
    }

    template <typename T>
    void RobotBodyFilter<T>::computeAndPublishBoundingBox(const PointCloud2Msg& projectedPointCloud) const {
        if (!this->computeBoundingBox && !this->computeDebugBoundingBox)
            return;

        // assume this->modelMutex is locked

        // when computing bounding boxes for publication, we want to publish them to
        // the time of the scan, so we need to set cacheLookupBetweenScansRatio again
        // to zero
        if (this->cacheLookupBetweenScansRatio != 0.0) {
            this->cacheLookupBetweenScansRatio = 0.0;
            this->shapeMask->updateBodyPoses();
        }

        const auto& scanTime = projectedPointCloud.header.stamp;
        std::vector<bodies::AxisAlignedBoundingBox> boxes;
        {
            MarkerArrayMsg boundingBoxDebugMsg;
            for (const auto& [shapeHandle, body] : this->shapeMask->getBodiesForBoundingBox()) {
                // logger.info("Looking for shape handle {}", shapeHandle);
                if (this->shapesIgnoredInBoundingBox.contains(shapeHandle))
                    continue;

                bodies::AxisAlignedBoundingBox box;
                body->computeBoundingBox(box);

                boxes.push_back(box);

                if (this->computeDebugBoundingBox) {
                    MarkerMsg msg;
                    msg.header.stamp = scanTime;
                    msg.header.frame_id = this->filteringFrame;

                    // it is aligned to fixed frame, not necessarily robot frame
                    tf2::toMsg(box.sizes(), msg.scale);
                    msg.pose.position = tf2::toMsg(static_cast<Eigen::Vector3d>(box.center()));
                    msg.pose.orientation.w = 1;

                    msg.color.g = 1.0;
                    msg.color.a = 0.5;
                    msg.type = MarkerMsg::CUBE;
                    msg.action = MarkerMsg::ADD;
                    msg.ns = "bbox/" + this->shapesToLinks.at(shapeHandle).cacheKey;
                    msg.frame_locked = true;

                    boundingBoxDebugMsg.markers.push_back(msg);
                }
            }

            if (this->computeDebugBoundingBox) {
                this->boundingBoxDebugMarkerPublisher->publish(boundingBoxDebugMsg);
            }
        }

        if (this->computeBoundingBox) {
            bodies::AxisAlignedBoundingBox box;
            bodies::mergeBoundingBoxes(boxes, box);

            PolygonStampedMsg boundingBoxMsg;

            boundingBoxMsg.header.stamp = scanTime;
            boundingBoxMsg.header.frame_id = this->filteringFrame;

            boundingBoxMsg.polygon.points.resize(2);
            tf2::toMsg(box.min(), boundingBoxMsg.polygon.points[0]);
            tf2::toMsg(box.max(), boundingBoxMsg.polygon.points[1]);

            this->boundingBoxPublisher->publish(boundingBoxMsg);

            if (this->publishBoundingBoxMarker) {
                MarkerMsg msg;
                msg.header.stamp = scanTime;
                msg.header.frame_id = this->filteringFrame;

                // it is aligned to fixed frame and not necessarily to robot frame
                tf2::toMsg(box.sizes(), msg.scale);
                msg.pose.position = tf2::toMsg(static_cast<Eigen::Vector3d>(box.center()));
                msg.pose.orientation.w = 1;

                msg.color.r = 1.0;
                msg.color.a = 0.5;
                msg.type = MarkerMsg::CUBE;
                msg.action = MarkerMsg::ADD;
                msg.ns = "bounding_box";
                msg.frame_locked = true;

                this->boundingBoxMarkerPublisher->publish(msg);
            }

            // compute and publish the scan_point_cloud with robot bounding box removed
            if (this->publishNoBoundingBoxPointcloud) {
                const auto bboxCropInput = std::make_shared<pcl::PCLPointCloud2>();
                pcl_conversions::toPCL(projectedPointCloud, *bboxCropInput);

                pcl::CropBox<pcl::PCLPointCloud2> cropBox;
                cropBox.setNegative(true);
                cropBox.setInputCloud(bboxCropInput);
                cropBox.setKeepOrganized(this->keepCloudsOrganized);

                const auto min = box.min().cast<float>();
                const auto max = box.max().cast<float>();
                cropBox.setMin(Eigen::Vector4f(min[0], min[1], min[2], 0.0));
                cropBox.setMax(Eigen::Vector4f(max[0], max[1], max[2], 0.0));

                pcl::PCLPointCloud2 pclOutput;
                cropBox.filter(pclOutput);

                const auto boxFilteredCloud = std::make_shared<PointCloud2Msg>();
                pcl_conversions::moveFromPCL(pclOutput, *boxFilteredCloud);
                boxFilteredCloud->header.stamp = scanTime; // PCL strips precision of timestamp
                this->scanPointCloudNoBoundingBoxPublisher->publish(*boxFilteredCloud);
            }
        }
    }

    template <typename T>
    void RobotBodyFilter<T>::computeAndPublishOrientedBoundingBox(const PointCloud2Msg& projectedPointCloud) const {
        if (!this->computeOrientedBoundingBox && !this->computeDebugOrientedBoundingBox)
            return;

        // assume this->modelMutex is locked

        // when computing bounding boxes for publication, we want to publish them to
        // the time of the scan, so we need to set cacheLookupBetweenScansRatio again
        // to zero
        if (this->cacheLookupBetweenScansRatio != 0.0) {
            this->cacheLookupBetweenScansRatio = 0.0;
            this->shapeMask->updateBodyPoses();
        }

        const auto& scanTime = projectedPointCloud.header.stamp;
        std::vector<bodies::OrientedBoundingBox> boxes;

        {
            MarkerArrayMsg boundingBoxDebugMsg;
            for (const auto& [shapeHandle, body] : this->shapeMask->getBodiesForBoundingBox()) {
                if (this->shapesIgnoredInBoundingBox.contains(shapeHandle))
                    continue;

                bodies::OrientedBoundingBox box;
                body->computeBoundingBox(box);

                boxes.push_back(box);

                if (this->computeDebugOrientedBoundingBox) {
                    MarkerMsg msg;
                    msg.header.stamp = scanTime;
                    msg.header.frame_id = this->filteringFrame;

                    tf2::toMsg(box.getExtents(), msg.scale);
                    msg.pose.position = tf2::toMsg(static_cast<Eigen::Vector3d>(box.getPose().translation()));
                    msg.pose.orientation = tf2::toMsg(Eigen::Quaterniond(box.getPose().linear()));

                    msg.color.g = 1.0;
                    msg.color.a = 0.5;
                    msg.type = MarkerMsg::CUBE;
                    msg.action = MarkerMsg::ADD;
                    msg.ns = "obbox/" + this->shapesToLinks.at(shapeHandle).cacheKey;
                    msg.frame_locked = true;

                    boundingBoxDebugMsg.markers.push_back(msg);
                }
            }

            if (this->computeDebugOrientedBoundingBox) {
                this->orientedBoundingBoxDebugMarkerPublisher->publish(boundingBoxDebugMsg);
            }
        }

        if (this->computeOrientedBoundingBox) {
            bodies::OrientedBoundingBox box(Eigen::Isometry3d::Identity(), Eigen::Vector3d::Zero());
            // TODO: fix this
            bodies::mergeBoundingBoxesApprox(boxes, box);

            OrientedBoundingBoxStampedMsg boundingBoxMsg;

            boundingBoxMsg.header.stamp = scanTime;
            boundingBoxMsg.header.frame_id = this->filteringFrame;

            tf2::toMsg(box.getExtents(), boundingBoxMsg.obb.extents);
            tf2::toMsg(box.getPose().translation(), boundingBoxMsg.obb.pose.translation);
            boundingBoxMsg.obb.pose.rotation = tf2::toMsg(Eigen::Quaterniond(box.getPose().linear()));

            this->orientedBoundingBoxPublisher->publish(boundingBoxMsg);

            if (this->publishOrientedBoundingBoxMarker) {
                MarkerMsg msg;
                msg.header.stamp = scanTime;
                msg.header.frame_id = this->filteringFrame;

                tf2::toMsg(box.getExtents(), msg.scale);
                msg.pose.position = tf2::toMsg(static_cast<Eigen::Vector3d>(box.getPose().translation()));
                msg.pose.orientation = tf2::toMsg(Eigen::Quaterniond(box.getPose().linear()));

                msg.color.r = 1.0;
                msg.color.a = 0.5;
                msg.type = MarkerMsg::CUBE;
                msg.action = MarkerMsg::ADD;
                msg.ns = "oriented_bounding_box";
                msg.frame_locked = true;

                this->orientedBoundingBoxMarkerPublisher->publish(msg);
            }

            // compute and publish the scan_point_cloud with robot bounding box removed
            if (this->publishNoOrientedBoundingBoxPointcloud) {
                const auto bboxCropInput = std::make_shared<pcl::PCLPointCloud2>();
                pcl_conversions::toPCL(projectedPointCloud, *bboxCropInput);

                pcl::CropBox<pcl::PCLPointCloud2> cropBox;
                cropBox.setNegative(true);
                cropBox.setInputCloud(bboxCropInput);
                cropBox.setKeepOrganized(this->keepCloudsOrganized);

                const auto e = box.getExtents().cast<float>();
                cropBox.setMin(Eigen::Vector4f(-e.x() / 2, -e.y() / 2, -e.z() / 2, 0.0));
                cropBox.setMax(Eigen::Vector4f(e.x() / 2, e.y() / 2, e.z() / 2, 0.0));
                cropBox.setTranslation(box.getPose().translation().cast<float>());
                cropBox.setRotation(box.getPose().linear().eulerAngles(0, 1, 2).cast<float>());

                pcl::PCLPointCloud2 pclOutput;
                cropBox.filter(pclOutput);

                const auto boxFilteredCloud = std::make_shared<PointCloud2Msg>();
                pcl_conversions::moveFromPCL(pclOutput, *boxFilteredCloud);
                boxFilteredCloud->header.stamp = scanTime; // PCL strips precision of timestamp

                this->scanPointCloudNoOrientedBoundingBoxPublisher->publish(*boxFilteredCloud);
            }
        }
    }

    template <typename T>
    void RobotBodyFilter<T>::computeAndPublishLocalBoundingBox(const PointCloud2Msg& projectedPointCloud) const {
        if (!this->computeLocalBoundingBox && !this->computeDebugLocalBoundingBox)
            return;

        // assume this->modelMutex is locked

        const auto& scanTime = projectedPointCloud.header.stamp;
        std::string err;
        try {
            if (!this->tfBuffer->canTransform(this->localBoundingBoxFrame, this->filteringFrame, scanTime,
                                              remainingTime(*this->nodeHandle->get_clock(), scanTime, this->reachableTransformTimeout), &err)) {
                logger.error("Cannot get transform {}->{}. Error is {}.", this->filteringFrame, this->localBoundingBoxFrame, err);
                return;
            }
        } catch (tf2::TransformException& e) {
            logger.error("Cannot get transform {}->{}. Error is {}.", this->filteringFrame, this->localBoundingBoxFrame, e.what());
            return;
        }

        const auto localTfMsg = this->tfBuffer->lookupTransform(this->localBoundingBoxFrame, this->filteringFrame, scanTime);
        const Eigen::Isometry3d localTf = tf2::transformToEigen(localTfMsg.transform);

        std::vector<bodies::AxisAlignedBoundingBox> boxes;

        {
            MarkerArrayMsg boundingBoxDebugMsg;
            for (const auto& [shapeHandle, body] : this->shapeMask->getBodiesForBoundingBox()) {
                if (this->shapesIgnoredInBoundingBox.contains(shapeHandle))
                    continue;

                bodies::AxisAlignedBoundingBox box;
                bodies::computeBoundingBoxAt(body, box, localTf * body->getPose());

                boxes.push_back(box);

                if (this->computeDebugLocalBoundingBox) {
                    MarkerMsg msg;
                    msg.header.stamp = scanTime;
                    msg.header.frame_id = this->localBoundingBoxFrame;

                    tf2::toMsg(box.sizes(), msg.scale);
                    msg.pose.position = tf2::toMsg(static_cast<Eigen::Vector3d>(box.center()));
                    msg.pose.orientation.w = 1;

                    msg.color.g = 1.0;
                    msg.color.a = 0.5;
                    msg.type = MarkerMsg::CUBE;
                    msg.action = MarkerMsg::ADD;
                    msg.ns = "lbbox/" + this->shapesToLinks.at(shapeHandle).cacheKey;
                    msg.frame_locked = true;

                    boundingBoxDebugMsg.markers.push_back(msg);
                }
            }

            if (this->computeDebugLocalBoundingBox) {
                this->localBoundingBoxDebugMarkerPublisher->publish(boundingBoxDebugMsg);
            }
        }

        if (this->computeLocalBoundingBox) {
            auto box = bodies::AxisAlignedBoundingBox{};
            bodies::mergeBoundingBoxes(boxes, box);

            PolygonStampedMsg boundingBoxMsg;

            boundingBoxMsg.header.stamp = scanTime;
            boundingBoxMsg.header.frame_id = this->localBoundingBoxFrame;

            boundingBoxMsg.polygon.points.resize(2);
            tf2::toMsg(box.min(), boundingBoxMsg.polygon.points[0]);
            tf2::toMsg(box.max(), boundingBoxMsg.polygon.points[1]);

            this->localBoundingBoxPublisher->publish(boundingBoxMsg);

            if (this->publishLocalBoundingBoxMarker) {
                MarkerMsg msg;
                msg.header.stamp = scanTime;
                msg.header.frame_id = this->localBoundingBoxFrame;

                tf2::toMsg(box.sizes(), msg.scale);
                msg.pose.position = tf2::toMsg(static_cast<Eigen::Vector3d>(box.center()));
                msg.pose.orientation.w = 1;

                msg.color.r = 1.0;
                msg.color.a = 0.5;
                msg.type = MarkerMsg::CUBE;
                msg.action = MarkerMsg::ADD;
                msg.ns = "local_bounding_box";
                msg.frame_locked = true;

                this->localBoundingBoxMarkerPublisher->publish(msg);
            }

            // compute and publish the scan_point_cloud with robot bounding box removed
            if (this->publishNoLocalBoundingBoxPointcloud) {
                auto bboxCropInput = std::make_shared<pcl::PCLPointCloud2>();
                pcl_conversions::toPCL(projectedPointCloud, *bboxCropInput);

                pcl::CropBox<pcl::PCLPointCloud2> cropBox;
                cropBox.setNegative(true);
                cropBox.setInputCloud(bboxCropInput);
                cropBox.setKeepOrganized(this->keepCloudsOrganized);

                const auto min = box.min().cast<float>();
                const auto max = box.max().cast<float>();
                cropBox.setMin(Eigen::Vector4f(min[0], min[1], min[2], 0.0));
                cropBox.setMax(Eigen::Vector4f(max[0], max[1], max[2], 0.0));
                const Eigen::Isometry3d localTfInv = localTf.inverse();
                cropBox.setTranslation(localTfInv.translation().cast<float>());
                cropBox.setRotation(localTfInv.linear().eulerAngles(0, 1, 2).cast<float>());

                pcl::PCLPointCloud2 pclOutput;
                cropBox.filter(pclOutput);

                auto boxFilteredCloud = std::make_shared<PointCloud2Msg>();
                pcl_conversions::moveFromPCL(pclOutput, *boxFilteredCloud);
                boxFilteredCloud->header.stamp = scanTime; // PCL strips precision of timestamp

                this->scanPointCloudNoLocalBoundingBoxPublisher->publish(*boxFilteredCloud);
            }
        }
    }

    template <typename T>
    ScaleAndPadding RobotBodyFilter<T>::getLinkInflationForContainsTest(const std::string& linkName) const {
        return this->getLinkInflationForContainsTest(std::vector{linkName});
    }

    template <typename T>
    ScaleAndPadding RobotBodyFilter<T>::getLinkInflationForContainsTest(const std::vector<std::string>& linkNames) const {
        return RobotBodyFilter::getLinkInflation(linkNames, this->defaultContainsInflation, this->perLinkContainsInflation);
    }

    template <typename T>
    ScaleAndPadding RobotBodyFilter<T>::getLinkInflationForShadowTest(const std::string& linkName) const {
        return this->getLinkInflationForShadowTest(std::vector{linkName});
    }

    template <typename T>
    ScaleAndPadding RobotBodyFilter<T>::getLinkInflationForShadowTest(const std::vector<std::string>& linkNames) const {
        return RobotBodyFilter::getLinkInflation(linkNames, this->defaultShadowInflation, this->perLinkShadowInflation);
    }

    template <typename T>
    ScaleAndPadding RobotBodyFilter<T>::getLinkInflationForBoundingSphere(const std::string& linkName) const {
        return this->getLinkInflationForBoundingSphere(std::vector{linkName});
    }

    template <typename T>
    ScaleAndPadding RobotBodyFilter<T>::getLinkInflationForBoundingSphere(const std::vector<std::string>& linkNames) const {
        return RobotBodyFilter::getLinkInflation(linkNames, this->defaultBsphereInflation, this->perLinkBsphereInflation);
    }

    template <typename T>
    ScaleAndPadding RobotBodyFilter<T>::getLinkInflationForBoundingBox(const std::string& linkName) const {
        return this->getLinkInflationForBoundingBox(std::vector{linkName});
    }

    template <typename T>
    ScaleAndPadding RobotBodyFilter<T>::getLinkInflationForBoundingBox(const std::vector<std::string>& linkNames) const {
        return RobotBodyFilter::getLinkInflation(linkNames, this->defaultBboxInflation, this->perLinkBboxInflation);
    }

    template <typename T>
    ScaleAndPadding RobotBodyFilter<T>::getLinkInflation(
        const std::vector<std::string>& linkNames,
        const ScaleAndPadding& defaultInflation,
        const std::map<std::string, ScaleAndPadding>& perLinkInflation
    ) {
        ScaleAndPadding result = defaultInflation;

        for (const auto& linkName : linkNames) {
            if (perLinkInflation.contains(linkName))
                result = perLinkInflation.at(linkName);
        }

        return result;
    }
}
