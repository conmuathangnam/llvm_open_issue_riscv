#include <utility>

#include <robot_body_filter/tf_frames_watchdog.hpp>

#include <robot_body_filter/utils/time_utils.hpp>

namespace robot_body_filter {
    TFFramesWatchdog::TFFramesWatchdog(
        rclcpp::Logger logger,
        rclcpp::Node::SharedPtr nodeHandle,
        std::string robotFrame,
        std::set<std::string> monitoredFrames,
        tf2_ros::Buffer::SharedPtr tfBuffer,
        const rclcpp::Duration& unreachableTfLookupTimeout,
        rclcpp::Rate::SharedPtr unreachableFramesCheckRate
    ) : robotFrame(std::move(robotFrame)),
        monitoredFrames(std::move(monitoredFrames)),
        tfBuffer(std::move(tfBuffer)),
        unreachableTfLookupTimeout(unreachableTfLookupTimeout),
        unreachableFramesCheckRate(std::move(unreachableFramesCheckRate)),
        logger(logger.get_child("tf_frames_watchdog")),
        nodeHandle(std::move(nodeHandle)) {}

    TFFramesWatchdog::~TFFramesWatchdog() {
        this->stop();
    }

    void TFFramesWatchdog::start() {
        this->shouldStop = false;
        this->thisThread = std::thread(&TFFramesWatchdog::run, this);
        this->unpause();
    }

    void TFFramesWatchdog::run() {
        this->started = true;

        while (!this->shouldStop && rclcpp::ok()) {
            if (!this->paused) {
                // the thread is paused when we want to change the stuff protected by framesMutex.
                this->searchForReachableFrames();
            }
            this->unreachableFramesCheckRate->sleep();
        }
    }

    bool TFFramesWatchdog::isRunning() const {
        return this->started;
    }

    void TFFramesWatchdog::pause() {
        this->paused = true;
    }

    void TFFramesWatchdog::unpause() {
        this->paused = false;
    }

    void TFFramesWatchdog::stop() {
        logger.info("Stopping TF watchdog.");
        this->shouldStop = true;
        this->paused = true;

        if (this->started && this->thisThread.joinable())
            this->thisThread.join(); // segfaults without this line
        logger.info("TF watchdog stopped.");
    }

    void TFFramesWatchdog::clear() {
        std::lock_guard _(this->framesMutex);
        monitoredFrames.clear();
        tfBuffer->clear();
        reachableFrames.clear();
    }

    void TFFramesWatchdog::setMonitoredFrames(std::set<std::string> monitoredFrames) {
        std::lock_guard _(this->framesMutex);
        this->monitoredFrames = std::move(monitoredFrames);

        // if some monitored frames disappeared, delete them also from reachableFrames
        for (auto& frame : this->reachableFrames) {
            if (!this->monitoredFrames.contains(frame))
                this->reachableFrames.erase(frame);
        }
    }

    void TFFramesWatchdog::addMonitoredFrame(const std::string& monitoredFrame) {
        std::lock_guard _(this->framesMutex);
        this->addMonitoredFrameNoLock(monitoredFrame);
    }

    bool TFFramesWatchdog::isMonitored(const std::string& frame) const {
        std::lock_guard _(this->framesMutex);
        return this->isMonitoredNoLock(frame);
    }

    bool TFFramesWatchdog::isReachable(const std::string& frame) const {
        std::lock_guard _(this->framesMutex);
        return this->isReachableNoLock(frame);
    }

    bool TFFramesWatchdog::areAllFramesReachable() const {
        std::lock_guard _(this->framesMutex);
        return this->reachableFrames.size() == this->monitoredFrames.size();
    }

    optional<geometry_msgs::msg::TransformStamped> TFFramesWatchdog::lookupTransform(
        const std::string& frame,
        const rclcpp::Time& time,
        const rclcpp::Duration& timeout,
        std::string* errstr) {
        if (!this->started)
            throw std::runtime_error("TFFramesWatchdog has not been started.");

        {
            std::lock_guard _(this->framesMutex);
            if (!this->isMonitoredNoLock(frame)) {
                logger.warn("TFFramesWatchdog ({}): Frame {} is not yet monitored, starting monitoring it.", this->robotFrame, frame);
                this->addMonitoredFrameNoLock(frame);
                // this lookup is lost, same as if the frame is unreachable
                return nullopt;
            }

            // Return immediately for unreachable frames
            if (!this->isReachableNoLock(frame))
                return nullopt;
        }

        std::string tmpErrstr;
        if (errstr == nullptr) {
            errstr = &tmpErrstr;
        }

        static const auto& log_throttle = rclcpp::Duration::from_seconds(3);

        if (!this->tfBuffer->canTransform(this->robotFrame, frame, time, remainingTime(*this->nodeHandle->get_clock(), time, timeout), errstr)) {
            logger.warn_throttle(log_throttle, "TFFramesWatchdog ({}): Frame {} became unreachable. Cause: {}", this->robotFrame, frame, *errstr);
            // if we couldn't get TF for this reachable frame, mark it unreachable
            this->markUnreachable(frame);
            return nullopt;
        }

        try {
            return this->tfBuffer->lookupTransform(this->robotFrame, frame, time, remainingTime(*this->nodeHandle->get_clock(), time, timeout));
        } catch (tf2::LookupException&) {
            logger.warn_throttle(log_throttle, "TFFramesWatchdog ({}): Frame {} is not reachable. Cause: {}", this->robotFrame, frame, *errstr);
            // if we couldn't get TF for this reachable frame, mark it unreachable
            this->markUnreachable(frame);
            return nullopt;
        }
    }

    bool TFFramesWatchdog::isReachableNoLock(const std::string& frame) const {
        return this->reachableFrames.contains(frame);
    }

    bool TFFramesWatchdog::isMonitoredNoLock(const std::string& frame) const {
        return this->monitoredFrames.contains(frame);
    }

    void TFFramesWatchdog::addMonitoredFrameNoLock(const std::string& monitoredFrame) {
        this->monitoredFrames.insert(monitoredFrame);
    }

    void TFFramesWatchdog::markReachable(const std::string& frame) {
        std::lock_guard _(this->framesMutex);
        this->reachableFrames.insert(frame);
    }

    void TFFramesWatchdog::markUnreachable(const std::string& frame) {
        std::lock_guard _(this->framesMutex);
        this->reachableFrames.erase(frame);
    }

    std::set<std::string> TFFramesWatchdog::findUnreachableFrames() {
        // detect all unreachable frames
        // we can't join this loop with the one in searchForReachableFrames, because we need to lock the framesMutex, but
        // canTransform can hang for pretty long, which would result in deadlocks

        std::set<std::string> unreachableFrames = {};

        std::lock_guard _(this->framesMutex);

        std::ranges::set_difference(
            this->monitoredFrames, this->reachableFrames,
            std::inserter(unreachableFrames, unreachableFrames.end())
        );

        return unreachableFrames;
    }

    void TFFramesWatchdog::searchForReachableFrames() {
        const rclcpp::Time time = nodeHandle->now();

        // now, the mutex is unlocked and we try to get transforms to all of the unreachable links... that
        // could take a while
        for (const auto unreachableFrames = this->findUnreachableFrames(); auto& frame : unreachableFrames) {
            if (this->paused)
                break;

            std::string err;
            logger.debug("robot frame: {}, checking against: {}", this->robotFrame, frame);
            if (this->tfBuffer->canTransform(this->robotFrame, frame, time, this->unreachableTfLookupTimeout, &err)) {
                this->markReachable(frame);
                logger.debug("TFFramesWatchdog ({}): Frame {} became reachable at {}.{}", this->robotFrame, frame, time.seconds(), time.nanoseconds());
            } else {
                static const auto& log_throttle = rclcpp::Duration::from_seconds(3);
                logger.warn_throttle(log_throttle, "TFFramesWatchdog ({}): Frame {} is not reachable! Cause: {}", this->robotFrame, frame, err);
            }
        }
    }
}
