#include "robot_body_filter/utils/time_utils.hpp"

namespace robot_body_filter {
    rclcpp::Duration remainingTime(rclcpp::Clock clock, const rclcpp::Time& query, const double timeout) {
        const auto passed = (clock.now() - query).seconds();
        return rclcpp::Duration::from_seconds(std::max(0.0, timeout - passed));
    }

    rclcpp::Duration remainingTime(rclcpp::Clock clock, const rclcpp::Time& query, const rclcpp::Duration& timeout) {
        const auto passed = clock.now() - query;
        const auto remaining = timeout - passed;
        return (remaining.seconds() >= 0) ? remaining : rclcpp::Duration::from_seconds(0);
    }
};
