#include "robot_body_filters.hpp"

#include "utils/string_utils.hpp"
#include "utils/time_utils.hpp"

namespace robot_body_filter {
    bool RobotBodyFilterLaserScan::update(const sensor_msgs::msg::LaserScan& inputScan, sensor_msgs::msg::LaserScan& filteredScan) {
        const auto& scanTime = rclcpp::Time(inputScan.header.stamp);

        if (!this->configured_) {
            RCLCPP_DEBUG(nodeHandle->get_logger(),
                         "RobotBodyFilter: Ignore scan from time %f.%ld - filter not yet "
                         "initialized.",
                         scanTime.seconds(), scanTime.nanoseconds());
            return false;
        }

        if (scanTime < timeConfigured && scanTime + tfBufferLength >= timeConfigured) {
            RCLCPP_DEBUG(nodeHandle->get_logger(),
                         "RobotBodyFilter: Ignore scan from time %f.%ld - filter not yet "
                         "initialized.",
                         scanTime.seconds(), scanTime.nanoseconds());
            return false;
        }

        if (scanTime < timeConfigured && scanTime + tfBufferLength < timeConfigured) {
            RCLCPP_WARN(nodeHandle->get_logger(),
                        "RobotBodyFilter: Old TF data received. Clearing TF buffer and "
                        "reconfiguring laser"
                        "filter. If you're replaying a bag file, make sure rosparam "
                        "/use_sim_time is set to "
                        "true");
            this->configure();
            return false;
        }

        // tf2 doesn't like frames starting with slash
        const auto scanFrame = stripLeadingSlash(inputScan.header.frame_id, true);

        // Passing a sensorFrame does not make sense. Scan messages can't be
        // transformed to other frames.
        if (!this->sensorFrame.empty() && this->sensorFrame != scanFrame) {
            RCLCPP_WARN_ONCE(nodeHandle->get_logger(),
                             "RobotBodyFilter: frames/sensor is set to frame_id '%s' different than "
                             "the frame_id of the incoming message '%s'. This is an invalid "
                             "configuration: "
                             "the frames/sensor parameter will be neglected.",
                             this->sensorFrame.c_str(), scanFrame.c_str());
        }

        if (!this->tfFramesWatchdog->isReachable(scanFrame)) {
            RCLCPP_DEBUG(nodeHandle->get_logger(),
                         "RobotBodyFilter: Throwing away scan since sensor frame is "
                         "unreachable.");
            // if this->sensorFrame is empty, it can happen that we're not actually
            // monitoring the sensor frame, so start monitoring it
            if (!this->tfFramesWatchdog->isMonitored(scanFrame))
                this->tfFramesWatchdog->addMonitoredFrame(scanFrame);
            return false;
        }

        if (this->requireAllFramesReachable && !this->tfFramesWatchdog->areAllFramesReachable()) {
            RCLCPP_DEBUG(nodeHandle->get_logger(),
                         "RobotBodyFilter: Throwing away scan since not all frames are "
                         "reachable.");
            return false;
        }

        const clock_t stopwatchOverall = clock();

        // create the output copy of the input scan
        filteredScan = inputScan;
        filteredScan.header.frame_id = scanFrame;
        filteredScan.range_min = std::max(inputScan.range_min, static_cast<float>(this->minDistance));
        if (this->maxDistance > 0.0)
            filteredScan.range_max = std::min(inputScan.range_max, static_cast<float>(this->maxDistance));

        {
            // acquire the lock here, because we work with the tfBuffer all the time
            std::lock_guard guard(*this->modelMutex);

            if (this->pointByPointScan) {
                // make sure we have all the tfs between
                // sensor frame and fixedFrame during the time
                // of scan acquisition
                const auto scanDuration = inputScan.ranges.size() * inputScan.time_increment;
                const auto afterScanTime = scanTime + rclcpp::Duration::from_seconds(scanDuration);

                std::string err;
                if (!this->tfBuffer->canTransform(this->fixedFrame, scanFrame, scanTime,
                                                  remainingTime(*this->nodeHandle->get_clock(), scanTime, this->reachableTransformTimeout), &err) ||
                    !this->tfBuffer->canTransform(this->fixedFrame, scanFrame, afterScanTime,
                                                  remainingTime(*this->nodeHandle->get_clock(), afterScanTime, this->reachableTransformTimeout), &err)) {
                    if (err.find("future") != std::string::npos) {
                        const auto delay = nodeHandle->now() - scanTime;
                        auto& clk = *nodeHandle->get_clock();
                        RCLCPP_ERROR_THROTTLE(nodeHandle->get_logger(), clk, 3,
                                              "RobotBodyFilter: Cannot transform laser scan to "
                                              "fixed frame. The scan is too much delayed (%s s). TF error: %s",
                                              to_string(delay).c_str(), err.c_str());
                    } else {
                        auto& clk = *nodeHandle->get_clock();
                        RCLCPP_ERROR_THROTTLE(nodeHandle->get_logger(), clk, 3,
                                              "RobotBodyFilter: Cannot transform laser scan to "
                                              "fixed frame. Something's wrong with TFs: %s",
                                              err.c_str());
                    }
                    return false;
                }
            }

            // The point cloud will have fields x, y, z, intensity (float32) and index
            // (int32) and for point-by-point scans also timestamp and viewpoint
            sensor_msgs::msg::PointCloud2 projectedPointCloud;
            {
                // project the scan measurements to a point cloud in the filteringFrame

                sensor_msgs::msg::PointCloud2 tmpPointCloud;

                // the projected point cloud can omit some measurements if they are out of
                // the defined scan's range; for this case, the second channel ("index")
                // contains indices of the point cloud's points into the scan
                auto channelOptions = laser_geometry::channel_option::Intensity | laser_geometry::channel_option::Index;

                if (this->pointByPointScan) {
                    RCLCPP_INFO_ONCE(nodeHandle->get_logger(), "RobotBodyFilter: Applying complex laser scan projection.");
                    // perform the complex laser scan projection
                    channelOptions |= laser_geometry::channel_option::Timestamp | laser_geometry::channel_option::Viewpoint;

                    laserProjector.transformLaserScanToPointCloud(this->fixedFrame, inputScan, tmpPointCloud, *this->tfBuffer, -1,
                                                                  channelOptions);
                } else {
                    RCLCPP_INFO_ONCE(nodeHandle->get_logger(), "RobotBodyFilter: Applying simple laser scan projection.");
                    // perform simple laser scan projection
                    laserProjector.projectLaser(inputScan, tmpPointCloud, -1.0, channelOptions);
                }

                // convert to filtering frame
                if (tmpPointCloud.header.frame_id == this->filteringFrame) {
                    projectedPointCloud = std::move(tmpPointCloud);
                } else {
                    RCLCPP_INFO_ONCE(nodeHandle->get_logger(), "RobotBodyFilter: Transforming scan from frame %s to %s",
                                     tmpPointCloud.header.frame_id.c_str(), this->filteringFrame.c_str());
                    std::string err;
                    if (!this->tfBuffer->canTransform(this->filteringFrame, tmpPointCloud.header.frame_id, scanTime,
                                                      remainingTime(*this->nodeHandle->get_clock(), scanTime, this->reachableTransformTimeout), &err)) {
                        auto& clk = *nodeHandle->get_clock();
                        RCLCPP_ERROR_THROTTLE(nodeHandle->get_logger(), clk, 3,
                                              "RobotBodyFilter: Cannot transform "
                                              "laser scan to filtering frame. Something's wrong with TFs: %s",
                                              err.c_str());
                        return false;
                    }

                    transformWithChannels(tmpPointCloud, projectedPointCloud, *this->tfBuffer, this->filteringFrame,
                                          this->channelsToTransform);
                }
            }

            RCLCPP_DEBUG(nodeHandle->get_logger(), "RobotBodyFilter: Scan transformation run time is %.5f secs.",
                         static_cast<double>(clock() - stopwatchOverall)/ CLOCKS_PER_SEC);

            std::vector<RayCastingShapeMask::MaskValue> pointMask = {};

            if (const auto success = this->computeMask(projectedPointCloud, pointMask, scanFrame); !success) return false;

            {
                // remove invalid points
                constexpr float INVALID_POINT_VALUE = std::numeric_limits<float>::quiet_NaN();
                try {
                    sensor_msgs::PointCloud2Iterator<int> indexIt(projectedPointCloud, "index");

                    size_t indexInScan;
                    for (const auto maskValue : pointMask) {
                        switch (maskValue) {
                        case RayCastingShapeMask::MaskValue::INSIDE:
                        case RayCastingShapeMask::MaskValue::SHADOW:
                        case RayCastingShapeMask::MaskValue::CLIP:
                            indexInScan = static_cast<const size_t>(*indexIt);
                            filteredScan.ranges[indexInScan] = INVALID_POINT_VALUE;
                            break;
                        case RayCastingShapeMask::MaskValue::OUTSIDE:
                            break;
                        }
                        ++indexIt;
                    }
                } catch (std::runtime_error&) {
                    RCLCPP_ERROR(this->nodeHandle->get_logger(),
                                 "RobotBodyFilter: projectedPointCloud doesn't have field "
                                 "called 'index',"
                                 " but the algorithm relies on that.");
                    return false;
                }
            }
        }

        return true;
    }

    bool RobotBodyFilterLaserScan::configure() {
        RCLCPP_INFO(nodeHandle->get_logger(), "Declaring Parameters");
        this->getParam("sensor.point_by_point", this->pointByPointScan, false, true);
        const bool success = RobotBodyFilter::configure();
        return success;
    }

    bool RobotBodyFilterPointCloud2::update(const sensor_msgs::msg::PointCloud2& inputCloud, sensor_msgs::msg::PointCloud2& filteredCloud) {
        const auto& scanTime = rclcpp::Time(inputCloud.header.stamp);

        if (!this->configured_) {
            RCLCPP_DEBUG(nodeHandle->get_logger(),
                         "RobotBodyFilter: Ignore cloud from time %f.%ld - filter not yet "
                         "initialized.",
                         scanTime.seconds(), scanTime.nanoseconds());
            return false;
        }

        if (scanTime < this->timeConfigured && scanTime + this->tfBufferLength >= this->timeConfigured) {
            RCLCPP_DEBUG(nodeHandle->get_logger(),
                         "RobotBodyFilter: Ignore cloud from time %f.%ld - filter not yet "
                         "initialized.",
                         scanTime.seconds(), scanTime.nanoseconds());
            return false;
        }

        if (scanTime < this->timeConfigured && scanTime + this->tfBufferLength < this->timeConfigured) {
            RCLCPP_WARN(nodeHandle->get_logger(),
                        "RobotBodyFilter: Old TF data received. Clearing TF buffer and "
                        "reconfiguring laser filter. If you're replaying a bag file, make "
                        "sure rosparam /use_sim_time is set to true");
            this->configure();
            return false;
        }

        const auto inputCloudFrame = this->sensorFrame.empty() ? stripLeadingSlash(inputCloud.header.frame_id, true) : this->sensorFrame;

        if (!this->tfFramesWatchdog->isReachable(inputCloudFrame)) {
            RCLCPP_DEBUG(nodeHandle->get_logger(),
                         "inputCloudFrame: %s", inputCloudFrame.c_str());
            RCLCPP_DEBUG(nodeHandle->get_logger(),
                         "RobotBodyFilter: Throwing away scan since sensor frame is "
                         "unreachable.");
            // if this->sensorFrame is empty, it can happen that we're not actually
            // monitoring the cloud frame, so start monitoring it
            if (!this->tfFramesWatchdog->isMonitored(inputCloudFrame))
                this->tfFramesWatchdog->addMonitoredFrame(inputCloudFrame);
            return false;
        }

        if (this->requireAllFramesReachable && !this->tfFramesWatchdog->areAllFramesReachable()) {
            RCLCPP_DEBUG(nodeHandle->get_logger(),
                         "RobotBodyFilter: Throwing away scan since not all frames are "
                         "reachable.");
            return false;
        }

        bool hasStampsField = false;
        bool hasVpXField = false, hasVpYField = false, hasVpZField = false;
        for (const auto& field : inputCloud.fields) {
            if (field.name == "stamps" && field.datatype == sensor_msgs::msg::PointField::FLOAT32)
                hasStampsField = true;
            else if (field.name == "vp_x" && field.datatype == sensor_msgs::msg::PointField::FLOAT32)
                hasVpXField = true;
            else if (field.name == "vp_y" && field.datatype == sensor_msgs::msg::PointField::FLOAT32)
                hasVpYField = true;
            else if (field.name == "vp_z" && field.datatype == sensor_msgs::msg::PointField::FLOAT32)
                hasVpZField = true;
        }

        // Verify the pointcloud and its fields

        if (this->pointByPointScan) {
            if (inputCloud.height != 1 && inputCloud.is_dense == 0) {
                RCLCPP_WARN_ONCE(nodeHandle->get_logger(),
                                 "RobotBodyFilter: The pointcloud seems to be an organized "
                                 "pointcloud, which usually means it was captured all at once."
                                 " Consider setting 'point_by_point_scan' to false to get a "
                                 "more efficient computation.");
            }
            if (!hasStampsField || !hasVpXField || !hasVpYField || !hasVpZField) {
                throw std::runtime_error(
                    "A point-by-point scan has to contain float32"
                    "fields 'stamps', 'vp_x', 'vp_y' and 'vp_z'.");
            }
        } else if (hasStampsField) {
            RCLCPP_WARN_ONCE(nodeHandle->get_logger(),
                             "RobotBodyFilter: The pointcloud has a 'stamps' field, "
                             "which indicates each point was probably captured at a "
                             "different time instant. Consider setting parameter "
                             "'point_by_point_scan' to true to get correct results.");
        } else if (inputCloud.height == 1 && inputCloud.is_dense == 1) {
            RCLCPP_WARN_ONCE(nodeHandle->get_logger(),
                             "RobotBodyFilter: The pointcloud is dense, which usually means"
                             " it was captured each point at a different time instant. "
                             "Consider setting 'point_by_point_scan' to true to get a more"
                             " accurate version.");
        }

        // Transform to filtering frame
        RCLCPP_DEBUG(nodeHandle->get_logger(), "RobotBodyFilter: Transforming point cloud from input frame: %s to filtering frame: %s",
                     inputCloud.header.frame_id.c_str(), this->filteringFrame.c_str());

        sensor_msgs::msg::PointCloud2 transformedCloud;
        if (inputCloud.header.frame_id == this->filteringFrame) {
            transformedCloud = inputCloud;
        } else {
            RCLCPP_INFO_ONCE(nodeHandle->get_logger(), "RobotBodyFilter: Transforming cloud from frame %s to %s",
                             inputCloud.header.frame_id.c_str(), this->filteringFrame.c_str());
            std::lock_guard guard(*this->modelMutex);
            std::string err;
            if (!this->tfBuffer->canTransform(this->filteringFrame, inputCloud.header.frame_id, scanTime,
                                              remainingTime(*this->nodeHandle->get_clock(), scanTime, this->reachableTransformTimeout), &err)) {
                auto& clk = *nodeHandle->get_clock();
                RCLCPP_ERROR_THROTTLE(nodeHandle->get_logger(), clk, 3,
                                      "RobotBodyFilter: Cannot transform "
                                      "point cloud to filtering frame. Something's wrong with TFs: %s",
                                      err.c_str());
                return false;
            }
            transformWithChannels(inputCloud, transformedCloud, *this->tfBuffer, this->filteringFrame,
                                  this->channelsToTransform);
        }

        // Compute the mask and use it (transform message only if sensorFrame is
        // specified)
        RCLCPP_DEBUG(nodeHandle->get_logger(), "Computing Mask");
        std::vector<RayCastingShapeMask::MaskValue> pointMask;
        {
            std::lock_guard guard(*this->modelMutex);

            if (const auto success = this->computeMask(transformedCloud, pointMask, inputCloudFrame); !success)
                return false;
        }

        // Filter the cloud
        RCLCPP_DEBUG(nodeHandle->get_logger(), "Filtering the cloud");

        sensor_msgs::msg::PointCloud2 tmpCloud;
        CREATE_FILTERED_CLOUD(transformedCloud, tmpCloud, this->keepCloudsOrganized, (pointMask[i] == RayCastingShapeMask::MaskValue::OUTSIDE))

        // Transform to output frame
        RCLCPP_DEBUG(nodeHandle->get_logger(), "Transform to output frame");

        if (tmpCloud.header.frame_id == this->outputFrame) {
            filteredCloud = std::move(tmpCloud);
        } else {
            RCLCPP_INFO_ONCE(nodeHandle->get_logger(), "RobotBodyFilter: Transforming cloud from frame %s to %s",
                             tmpCloud.header.frame_id.c_str(), this->outputFrame.c_str());
            std::lock_guard guard(*this->modelMutex);
            std::string err;
            if (!this->tfBuffer->canTransform(this->outputFrame, tmpCloud.header.frame_id, scanTime,
                                              remainingTime(*this->nodeHandle->get_clock(), scanTime, this->reachableTransformTimeout), &err)) {
                auto& clk = *nodeHandle->get_clock();
                RCLCPP_ERROR_THROTTLE(nodeHandle->get_logger(), clk, 3,
                                      "RobotBodyFilter: Cannot transform "
                                      "point cloud to output frame. Something's wrong with TFs: %s",
                                      err.c_str());
                return false;
            }

            transformWithChannels(tmpCloud, filteredCloud, *this->tfBuffer, this->outputFrame, this->channelsToTransform);
        }

        return true;
    }

    bool RobotBodyFilterPointCloud2::configure() {
        this->getParam("sensor.point_by_point", this->pointByPointScan, false, false);

        if (const bool success = RobotBodyFilter::configure(); !success) return false;

        this->getParam("frames.output", this->outputFrame, false, this->filteringFrame);
        std::vector<std::string> tempPointChannels;
        std::vector<std::string> tempDirectionChannels;
        this->getParam("cloud.point_channels", tempPointChannels, false, {"vp_"});
        this->getParam("cloud.direction_channels", tempDirectionChannels, false, {"normal_"});
        const auto pointChannels = tempPointChannels;
        const auto directionChannels = tempDirectionChannels;

        for (const auto& channel : pointChannels)
            this->channelsToTransform[channel] = CloudChannelType::POINT;
        for (const auto& channel : directionChannels)
            this->channelsToTransform[channel] = CloudChannelType::DIRECTION;

        stripLeadingSlash(this->outputFrame, true);

        return true;
    }
}

#include <pluginlib/class_list_macros.hpp>

PLUGINLIB_EXPORT_CLASS(robot_body_filter::RobotBodyFilterLaserScan, filters::FilterBase<sensor_msgs::msg::LaserScan>)

PLUGINLIB_EXPORT_CLASS(robot_body_filter::RobotBodyFilterPointCloud2, filters::FilterBase<sensor_msgs::msg::PointCloud2>)
