#ifndef ROBOT_BODY_FILTER_SET_UTILS_HPP
#define ROBOT_BODY_FILTER_SET_UTILS_HPP

namespace robot_body_filter {
    template <typename T>
    bool isSetIntersectionEmpty(const std::set<T>& set1, const std::set<T>& set2) {
        std::set<T> tmpSet = {};

        std::ranges::set_difference(
            set1, set2,
            std::inserter(tmpSet, tmpSet.end())
        );

        return tmpSet.empty();
    }
}

#endif //ROBOT_BODY_FILTER_SET_UTILS_HPP
