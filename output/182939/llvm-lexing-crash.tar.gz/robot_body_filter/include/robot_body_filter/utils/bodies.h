#ifndef ROBOT_BODY_FILTER_BODIES_H
#define ROBOT_BODY_FILTER_BODIES_H

#include <geometric_shapes/aabb.h>
#include <geometric_shapes/bodies.h>
#include <geometric_shapes/obb.h>

namespace bodies {
    typedef AABB AxisAlignedBoundingBox;
    typedef OBB OrientedBoundingBox;

    /** \brief Compute AABB for the body at different pose. Can't use setPose() because we want `body` to be const. */
    void computeBoundingBoxAt(const Body* body, AxisAlignedBoundingBox& bbox, const Eigen::Isometry3d& pose);
}

#endif //ROBOT_BODY_FILTER_BODIES_H
