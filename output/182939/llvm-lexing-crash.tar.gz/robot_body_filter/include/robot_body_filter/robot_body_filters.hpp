#pragma once
#include <laser_geometry/laser_geometry.hpp>

#include "robot_body_filter.hpp"
#include "tf2_sensor_msgs.h"

namespace robot_body_filter {
    class RobotBodyFilterLaserScan : public RobotBodyFilter<sensor_msgs::msg::LaserScan> {
    public:
        //! Apply the filter.
        bool update(const sensor_msgs::msg::LaserScan& inputScan, sensor_msgs::msg::LaserScan& filteredScan) override;

        bool configure() override;

    protected:
        laser_geometry::LaserProjection laserProjector;

        // in RobotBodyFilterLaserScan::update we project the scan to a pointcloud with viewpoints
        const std::unordered_map<std::string, CloudChannelType> channelsToTransform{{"vp_", CloudChannelType::POINT}};
    };

    class RobotBodyFilterPointCloud2 : public RobotBodyFilter<sensor_msgs::msg::PointCloud2> {
    public:
        //! Apply the filter.
        bool update(const sensor_msgs::msg::PointCloud2& inputCloud, sensor_msgs::msg::PointCloud2& filteredCloud) override;

        bool configure() override;

    protected:
        /** \brief Frame into which the output data should be transformed. */
        std::string outputFrame;

        std::unordered_map<std::string, CloudChannelType> channelsToTransform;
    };
}
