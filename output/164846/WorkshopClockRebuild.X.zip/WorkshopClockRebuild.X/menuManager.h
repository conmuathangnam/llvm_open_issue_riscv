/* 
 * File:   menuManager.h
 * Author: John
 *
 * Created on 24 May 2021, 15:52
 */

#ifndef MENUMANAGER_H
#define	MENUMANAGER_H

#ifdef	__cplusplus
extern "C" {
#endif
    
#include "stdafx.h"
    
enum MenuLevel
{
    Menu_None,
    Menu_Top,
    Menu_Alarms,
    Menu_OscillatorTune,
    Menu_DefineAlarm
};
struct menu_Definition
{
    short maxLevel;
    short menu_parent;
}

g_menus[10] = {
    {0 , 0},
    {3 , Menu_None},        // top level menu 
    {2, Menu_Top},          // alarm pick menu
    {0, Menu_Top},          // oscillator tune menu 
    {2, Menu_Top},          // pick an alarm to set menu 
    {0, 0},
    {0, 0},
    {0, 0},
    {0, 0},
    {0, 0}
    
};
enum MenuNavigationAction
{
    Menu_Navi_Mode,         // mode switch pressed
    Menu_Navi_Up,           // up   ------"-------
    Menu_Navi_Down,         // down ------"-------
    Menu_Navi_Next,
    Menu_Navi_Back,
    Menu_Navi_End,
    Menu_Navi_Top
};
int currentMenuLevel;
short currentMenuEntry;
volatile int16_t oscillatorTuneValue;

extern short  IsMenuActive(void);
extern void PrintMenu(const enum MenuLevel menu);
extern short menuNavigate(const enum MenuNavigationAction action);
extern void DrawCursor(void);
extern short processMenu(void);
extern short selectCurrentMenuItem(void);

void ShowMainMenu(void);
void ShowOscillatorTune(void);
void setOscillatorTune(void);
void ShowAlarmSelect(void);

#ifdef	__cplusplus
}
#endif

#endif	/* MENUMANAGER_H */

