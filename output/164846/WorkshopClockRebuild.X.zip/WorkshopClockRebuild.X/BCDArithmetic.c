#include "BCDArithmetic.h"

/*
 * input
 * 
 * 0x000->0x099
 * 
 * output 
 * 
 * 0x000 -> 0x063 
 * 
 */
short convertBCD2Binary(unsigned char input)
{
    short returnValue = input & 0x00F;      // just start with the units
    /*
     * now calculate the 10's
     */
    short _10s = input & 0x0F0;
    _10s >>= 4;
    _10s *= 10;
    returnValue += _10s;    
    return returnValue;
}
/*
 * input
 * 
 * 0x000->0x063 
 * 
 * output 
 * 
 * 0x000 -> 0x099 
 * 0x0FF if input exceeded. 
 * 
 */
unsigned char  convertBinary2BCD(short input)
{
    if (input > 63)
    {
        return 0xFF;    // return invalid value
    }
    short _10s = 0;
    short _1s = 0;
     
    /*
     * to make the loop work - cast away the unsigned modifier.
     */
    short work = input;
   
    while (work > 0) 
    {
        work -= 10;
        if (work >= 0)
        {
            _10s ++;
        }
    };

    _1s = work + 10;
    if (_1s == 10)
        _1s = 0;

    return (unsigned char) _1s | (_10s << 4);
}
