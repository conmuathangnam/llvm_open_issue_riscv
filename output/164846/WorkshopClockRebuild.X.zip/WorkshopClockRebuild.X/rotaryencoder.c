/*
 * File:   rotary encoder.c
 * Author: johnm
 *
 * Created on August 5, 2022, 4:01 PM
 */
#include "stdafx.h"
#include "rotaryencoder.h"
#include "BasicLCD.h"
#include "timeManagement.h"
#include "menuManager.h"

static unsigned char oldstate; // this variable need to be static as it has to retain the value between calls

static uint16_t prevNextCode = 0;
static uint16_t store=0;

static int16_t encoderValue;
static int16_t oldEncoderValue;
    
/*static*/ bool  incrementEncoderValue(
           int16_t minValue, 
           int16_t maxValue,
           int16_t increment)
{
    processEncoderChange(increment);
    
    if (oldEncoderValue == encoderValue)
    {
        return false; 
    }

    if (encoderValue  > maxValue)
    {
        encoderValue = minValue;
    }
    else if (encoderValue < minValue)
    {
        encoderValue = maxValue;
    }

    oldEncoderValue = encoderValue;
    PORTB = PORTB;
    return true;
}

void initialiseEncoder(void)
{   
    oldstate = 0x0000;
    encoderValue = 0;
}
int16_t     getEncoderValue(void) 
{
    return encoderValue;
}
void    setEncoderValue(int16_t value) 
{
    encoderValue = value;
}
/*
 *  got this beauty from 
 * 
 * https://www.best-microcontroller-projects.com/rotary-encoder.html#Taming_Noisy_Rotary_Encoders
 * 
 * accessed 14:45 25/8/2022
 * 
 * 
 */
int16_t read_rotary(int16_t increment) {
  static int8_t rot_enc_table[] = {0,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0};

  prevNextCode <<= 2;
  if (PORTBbits.RB1) prevNextCode |= 0x02;
  if (PORTBbits.RB0) prevNextCode |= 0x01;
  prevNextCode &= 0x0f;

   // If valid then store as 16 bool data.
   if  (rot_enc_table[prevNextCode] ) {
      store <<= 4;
      store |= prevNextCode;
      //if (store==0xd42b) return 1;
      //if (store==0xe817) return -1;
      if ((store&0xff)==0x2b) return 0 - increment;
      if ((store&0xff)==0x17) return increment;
   }
   return 0;
}
void    processEncoderChange(int16_t increment)
{   
    int16_t incrementResult = read_rotary(increment); 
    encoderValue += incrementResult;

    switch (ApplicationState)
    {
        case Running:
            break; 
        case SetTime:
            break; 
        case SetAlarm0:
        case SetAlarm1:
            break;
        case Menu:
            if (incrementResult == 1)
            {
                menuNavigate(Menu_Navi_Down);
            }
            else if (incrementResult == -1)
            {
                menuNavigate(Menu_Navi_Up);
            }
            break;
        case AlarmTriggered:
        case Sleep:
            break; 
    }    
    
}
void    processEncoderButton(void)
{
    __delay_ms(10); // delay for 1ms here for debounce
   
    while(PORTBbits.RB2 == 1)  // let go that button 
    {
        Buzzer = true; 
        PORTB = PORTB;  //
         __delay_ms(10); // delay for 1ms here for debounce
   
    }
    Buzzer = false; 
    
    __delay_ms(10); // delay for 1ms here for debounce
    switch (ApplicationState)
    {
        case Running:
            ApplicationState = MenuStart;
            break; 
        case SetTime:
            Rtcctimedate.setStage++;
            break; 
        case SetAlarm0:
            RTCCAlarm0.setStage++;
            break;
        case SetAlarm1:
            RTCCAlarm1.setStage++;
            break;
        case Menu:
            ApplicationState = MenuItemClicked;
            break;
        case AlarmTriggered:
            //ApplicationState = Running; // acknowledge the alarm 
            break;
        case Sleep:
            /*
             * we were waiting 3 seconds to sleep - instead they pressed a 
             * button.
             */
            ApplicationState = MenuStart;
            break; 
    }    
    buttonPressOutstanding = true; 
}