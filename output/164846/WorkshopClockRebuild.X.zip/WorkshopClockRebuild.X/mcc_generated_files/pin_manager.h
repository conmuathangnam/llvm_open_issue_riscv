/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for .
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC18F45K22
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.36 and above
        MPLAB 	          :  MPLAB X 6.00	
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

/**
  Section: Included Files
*/

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set ROTARY_B aliases
#define ROTARY_B_TRIS                 TRISBbits.TRISB0
#define ROTARY_B_LAT                  LATBbits.LATB0
#define ROTARY_B_PORT                 PORTBbits.RB0
#define ROTARY_B_WPU                  WPUBbits.WPUB0
#define ROTARY_B_ANS                  ANSELBbits.ANSB0
#define ROTARY_B_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define ROTARY_B_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define ROTARY_B_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define ROTARY_B_GetValue()           PORTBbits.RB0
#define ROTARY_B_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define ROTARY_B_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define ROTARY_B_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define ROTARY_B_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define ROTARY_B_SetAnalogMode()      do { ANSELBbits.ANSB0 = 1; } while(0)
#define ROTARY_B_SetDigitalMode()     do { ANSELBbits.ANSB0 = 0; } while(0)

// get/set ROTARY_A aliases
#define ROTARY_A_TRIS                 TRISBbits.TRISB1
#define ROTARY_A_LAT                  LATBbits.LATB1
#define ROTARY_A_PORT                 PORTBbits.RB1
#define ROTARY_A_WPU                  WPUBbits.WPUB1
#define ROTARY_A_ANS                  ANSELBbits.ANSB1
#define ROTARY_A_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define ROTARY_A_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define ROTARY_A_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define ROTARY_A_GetValue()           PORTBbits.RB1
#define ROTARY_A_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define ROTARY_A_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define ROTARY_A_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define ROTARY_A_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define ROTARY_A_SetAnalogMode()      do { ANSELBbits.ANSB1 = 1; } while(0)
#define ROTARY_A_SetDigitalMode()     do { ANSELBbits.ANSB1 = 0; } while(0)

// get/set ROTARY_SW aliases
#define ROTARY_SW_TRIS                 TRISBbits.TRISB2
#define ROTARY_SW_LAT                  LATBbits.LATB2
#define ROTARY_SW_PORT                 PORTBbits.RB2
#define ROTARY_SW_WPU                  WPUBbits.WPUB2
#define ROTARY_SW_ANS                  ANSELBbits.ANSB2
#define ROTARY_SW_SetHigh()            do { LATBbits.LATB2 = 1; } while(0)
#define ROTARY_SW_SetLow()             do { LATBbits.LATB2 = 0; } while(0)
#define ROTARY_SW_Toggle()             do { LATBbits.LATB2 = ~LATBbits.LATB2; } while(0)
#define ROTARY_SW_GetValue()           PORTBbits.RB2
#define ROTARY_SW_SetDigitalInput()    do { TRISBbits.TRISB2 = 1; } while(0)
#define ROTARY_SW_SetDigitalOutput()   do { TRISBbits.TRISB2 = 0; } while(0)
#define ROTARY_SW_SetPullup()          do { WPUBbits.WPUB2 = 1; } while(0)
#define ROTARY_SW_ResetPullup()        do { WPUBbits.WPUB2 = 0; } while(0)
#define ROTARY_SW_SetAnalogMode()      do { ANSELBbits.ANSB2 = 1; } while(0)
#define ROTARY_SW_SetDigitalMode()     do { ANSELBbits.ANSB2 = 0; } while(0)

// get/set RTCC_ALARM_INT aliases
#define RTCC_ALARM_INT_TRIS                 TRISBbits.TRISB4
#define RTCC_ALARM_INT_LAT                  LATBbits.LATB4
#define RTCC_ALARM_INT_PORT                 PORTBbits.RB4
#define RTCC_ALARM_INT_WPU                  WPUBbits.WPUB4
#define RTCC_ALARM_INT_ANS                  ANSELBbits.ANSB4
#define RTCC_ALARM_INT_SetHigh()            do { LATBbits.LATB4 = 1; } while(0)
#define RTCC_ALARM_INT_SetLow()             do { LATBbits.LATB4 = 0; } while(0)
#define RTCC_ALARM_INT_Toggle()             do { LATBbits.LATB4 = ~LATBbits.LATB4; } while(0)
#define RTCC_ALARM_INT_GetValue()           PORTBbits.RB4
#define RTCC_ALARM_INT_SetDigitalInput()    do { TRISBbits.TRISB4 = 1; } while(0)
#define RTCC_ALARM_INT_SetDigitalOutput()   do { TRISBbits.TRISB4 = 0; } while(0)
#define RTCC_ALARM_INT_SetPullup()          do { WPUBbits.WPUB4 = 1; } while(0)
#define RTCC_ALARM_INT_ResetPullup()        do { WPUBbits.WPUB4 = 0; } while(0)
#define RTCC_ALARM_INT_SetAnalogMode()      do { ANSELBbits.ANSB4 = 1; } while(0)
#define RTCC_ALARM_INT_SetDigitalMode()     do { ANSELBbits.ANSB4 = 0; } while(0)

// get/set Light_Sensor aliases
#define Light_Sensor_TRIS                 TRISBbits.TRISB5
#define Light_Sensor_LAT                  LATBbits.LATB5
#define Light_Sensor_PORT                 PORTBbits.RB5
#define Light_Sensor_WPU                  WPUBbits.WPUB5
#define Light_Sensor_ANS                  ANSELBbits.ANSB5
#define Light_Sensor_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define Light_Sensor_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define Light_Sensor_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define Light_Sensor_GetValue()           PORTBbits.RB5
#define Light_Sensor_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define Light_Sensor_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define Light_Sensor_SetPullup()          do { WPUBbits.WPUB5 = 1; } while(0)
#define Light_Sensor_ResetPullup()        do { WPUBbits.WPUB5 = 0; } while(0)
#define Light_Sensor_SetAnalogMode()      do { ANSELBbits.ANSB5 = 1; } while(0)
#define Light_Sensor_SetDigitalMode()     do { ANSELBbits.ANSB5 = 0; } while(0)

// get/set RC3 procedures
#define RC3_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define RC3_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define RC3_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define RC3_GetValue()              PORTCbits.RC3
#define RC3_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define RC3_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define RC3_SetAnalogMode()         do { ANSELCbits.ANSC3 = 1; } while(0)
#define RC3_SetDigitalMode()        do { ANSELCbits.ANSC3 = 0; } while(0)

// get/set RC4 procedures
#define RC4_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define RC4_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define RC4_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define RC4_GetValue()              PORTCbits.RC4
#define RC4_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define RC4_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define RC4_SetAnalogMode()         do { ANSELCbits.ANSC4 = 1; } while(0)
#define RC4_SetDigitalMode()        do { ANSELCbits.ANSC4 = 0; } while(0)

// get/set IO_RC6 aliases
#define IO_RC6_TRIS                 TRISCbits.TRISC6
#define IO_RC6_LAT                  LATCbits.LATC6
#define IO_RC6_PORT                 PORTCbits.RC6
#define IO_RC6_ANS                  ANSELCbits.ANSC6
#define IO_RC6_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define IO_RC6_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define IO_RC6_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define IO_RC6_GetValue()           PORTCbits.RC6
#define IO_RC6_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define IO_RC6_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define IO_RC6_SetAnalogMode()      do { ANSELCbits.ANSC6 = 1; } while(0)
#define IO_RC6_SetDigitalMode()     do { ANSELCbits.ANSC6 = 0; } while(0)

// get/set LCD_DB4 aliases
#define LCD_DB4_TRIS                 TRISDbits.TRISD4
#define LCD_DB4_LAT                  LATDbits.LATD4
#define LCD_DB4_PORT                 PORTDbits.RD4
#define LCD_DB4_ANS                  ANSELDbits.ANSD4
#define LCD_DB4_SetHigh()            do { LATDbits.LATD4 = 1; } while(0)
#define LCD_DB4_SetLow()             do { LATDbits.LATD4 = 0; } while(0)
#define LCD_DB4_Toggle()             do { LATDbits.LATD4 = ~LATDbits.LATD4; } while(0)
#define LCD_DB4_GetValue()           PORTDbits.RD4
#define LCD_DB4_SetDigitalInput()    do { TRISDbits.TRISD4 = 1; } while(0)
#define LCD_DB4_SetDigitalOutput()   do { TRISDbits.TRISD4 = 0; } while(0)
#define LCD_DB4_SetAnalogMode()      do { ANSELDbits.ANSD4 = 1; } while(0)
#define LCD_DB4_SetDigitalMode()     do { ANSELDbits.ANSD4 = 0; } while(0)

// get/set LCD_DB5 aliases
#define LCD_DB5_TRIS                 TRISDbits.TRISD5
#define LCD_DB5_LAT                  LATDbits.LATD5
#define LCD_DB5_PORT                 PORTDbits.RD5
#define LCD_DB5_ANS                  ANSELDbits.ANSD5
#define LCD_DB5_SetHigh()            do { LATDbits.LATD5 = 1; } while(0)
#define LCD_DB5_SetLow()             do { LATDbits.LATD5 = 0; } while(0)
#define LCD_DB5_Toggle()             do { LATDbits.LATD5 = ~LATDbits.LATD5; } while(0)
#define LCD_DB5_GetValue()           PORTDbits.RD5
#define LCD_DB5_SetDigitalInput()    do { TRISDbits.TRISD5 = 1; } while(0)
#define LCD_DB5_SetDigitalOutput()   do { TRISDbits.TRISD5 = 0; } while(0)
#define LCD_DB5_SetAnalogMode()      do { ANSELDbits.ANSD5 = 1; } while(0)
#define LCD_DB5_SetDigitalMode()     do { ANSELDbits.ANSD5 = 0; } while(0)

// get/set LCD_DB6 aliases
#define LCD_DB6_TRIS                 TRISDbits.TRISD6
#define LCD_DB6_LAT                  LATDbits.LATD6
#define LCD_DB6_PORT                 PORTDbits.RD6
#define LCD_DB6_ANS                  ANSELDbits.ANSD6
#define LCD_DB6_SetHigh()            do { LATDbits.LATD6 = 1; } while(0)
#define LCD_DB6_SetLow()             do { LATDbits.LATD6 = 0; } while(0)
#define LCD_DB6_Toggle()             do { LATDbits.LATD6 = ~LATDbits.LATD6; } while(0)
#define LCD_DB6_GetValue()           PORTDbits.RD6
#define LCD_DB6_SetDigitalInput()    do { TRISDbits.TRISD6 = 1; } while(0)
#define LCD_DB6_SetDigitalOutput()   do { TRISDbits.TRISD6 = 0; } while(0)
#define LCD_DB6_SetAnalogMode()      do { ANSELDbits.ANSD6 = 1; } while(0)
#define LCD_DB6_SetDigitalMode()     do { ANSELDbits.ANSD6 = 0; } while(0)

// get/set LCD_DB7 aliases
#define LCD_DB7_TRIS                 TRISDbits.TRISD7
#define LCD_DB7_LAT                  LATDbits.LATD7
#define LCD_DB7_PORT                 PORTDbits.RD7
#define LCD_DB7_ANS                  ANSELDbits.ANSD7
#define LCD_DB7_SetHigh()            do { LATDbits.LATD7 = 1; } while(0)
#define LCD_DB7_SetLow()             do { LATDbits.LATD7 = 0; } while(0)
#define LCD_DB7_Toggle()             do { LATDbits.LATD7 = ~LATDbits.LATD7; } while(0)
#define LCD_DB7_GetValue()           PORTDbits.RD7
#define LCD_DB7_SetDigitalInput()    do { TRISDbits.TRISD7 = 1; } while(0)
#define LCD_DB7_SetDigitalOutput()   do { TRISDbits.TRISD7 = 0; } while(0)
#define LCD_DB7_SetAnalogMode()      do { ANSELDbits.ANSD7 = 1; } while(0)
#define LCD_DB7_SetDigitalMode()     do { ANSELDbits.ANSD7 = 0; } while(0)

// get/set LCD_E aliases
#define LCD_E_TRIS                 TRISEbits.TRISE0
#define LCD_E_LAT                  LATEbits.LATE0
#define LCD_E_PORT                 PORTEbits.RE0
#define LCD_E_ANS                  ANSELEbits.ANSE0
#define LCD_E_SetHigh()            do { LATEbits.LATE0 = 1; } while(0)
#define LCD_E_SetLow()             do { LATEbits.LATE0 = 0; } while(0)
#define LCD_E_Toggle()             do { LATEbits.LATE0 = ~LATEbits.LATE0; } while(0)
#define LCD_E_GetValue()           PORTEbits.RE0
#define LCD_E_SetDigitalInput()    do { TRISEbits.TRISE0 = 1; } while(0)
#define LCD_E_SetDigitalOutput()   do { TRISEbits.TRISE0 = 0; } while(0)
#define LCD_E_SetAnalogMode()      do { ANSELEbits.ANSE0 = 1; } while(0)
#define LCD_E_SetDigitalMode()     do { ANSELEbits.ANSE0 = 0; } while(0)

// get/set LCD_RW aliases
#define LCD_RW_TRIS                 TRISEbits.TRISE1
#define LCD_RW_LAT                  LATEbits.LATE1
#define LCD_RW_PORT                 PORTEbits.RE1
#define LCD_RW_ANS                  ANSELEbits.ANSE1
#define LCD_RW_SetHigh()            do { LATEbits.LATE1 = 1; } while(0)
#define LCD_RW_SetLow()             do { LATEbits.LATE1 = 0; } while(0)
#define LCD_RW_Toggle()             do { LATEbits.LATE1 = ~LATEbits.LATE1; } while(0)
#define LCD_RW_GetValue()           PORTEbits.RE1
#define LCD_RW_SetDigitalInput()    do { TRISEbits.TRISE1 = 1; } while(0)
#define LCD_RW_SetDigitalOutput()   do { TRISEbits.TRISE1 = 0; } while(0)
#define LCD_RW_SetAnalogMode()      do { ANSELEbits.ANSE1 = 1; } while(0)
#define LCD_RW_SetDigitalMode()     do { ANSELEbits.ANSE1 = 0; } while(0)

// get/set LCD_RS aliases
#define LCD_RS_TRIS                 TRISEbits.TRISE2
#define LCD_RS_LAT                  LATEbits.LATE2
#define LCD_RS_PORT                 PORTEbits.RE2
#define LCD_RS_ANS                  ANSELEbits.ANSE2
#define LCD_RS_SetHigh()            do { LATEbits.LATE2 = 1; } while(0)
#define LCD_RS_SetLow()             do { LATEbits.LATE2 = 0; } while(0)
#define LCD_RS_Toggle()             do { LATEbits.LATE2 = ~LATEbits.LATE2; } while(0)
#define LCD_RS_GetValue()           PORTEbits.RE2
#define LCD_RS_SetDigitalInput()    do { TRISEbits.TRISE2 = 1; } while(0)
#define LCD_RS_SetDigitalOutput()   do { TRISEbits.TRISE2 = 0; } while(0)
#define LCD_RS_SetAnalogMode()      do { ANSELEbits.ANSE2 = 1; } while(0)
#define LCD_RS_SetDigitalMode()     do { ANSELEbits.ANSE2 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);


/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handler for the IOCB4 pin functionality
 * @Example
    IOCB4_ISR();
 */
void IOCB4_ISR(void);

/**
  @Summary
    Interrupt Handler Setter for IOCB4 pin interrupt-on-change functionality

  @Description
    Allows selecting an interrupt handler for IOCB4 at application runtime
    
  @Preconditions
    Pin Manager intializer called

  @Returns
    None.

  @Param
    InterruptHandler function pointer.

  @Example
    PIN_MANAGER_Initialize();
    IOCB4_SetInterruptHandler(MyInterruptHandler);

*/
void IOCB4_SetInterruptHandler(void (* InterruptHandler)(void));

/**
  @Summary
    Dynamic Interrupt Handler for IOCB4 pin

  @Description
    This is a dynamic interrupt handler to be used together with the IOCB4_SetInterruptHandler() method.
    This handler is called every time the IOCB4 ISR is executed and allows any function to be registered at runtime.
    
  @Preconditions
    Pin Manager intializer called

  @Returns
    None.

  @Param
    None.

  @Example
    PIN_MANAGER_Initialize();
    IOCB4_SetInterruptHandler(IOCB4_InterruptHandler);

*/
extern void (*IOCB4_InterruptHandler)(void);

/**
  @Summary
    Default Interrupt Handler for IOCB4 pin

  @Description
    This is a predefined interrupt handler to be used together with the IOCB4_SetInterruptHandler() method.
    This handler is called every time the IOCB4 ISR is executed. 
    
  @Preconditions
    Pin Manager intializer called

  @Returns
    None.

  @Param
    None.

  @Example
    PIN_MANAGER_Initialize();
    IOCB4_SetInterruptHandler(IOCB4_DefaultInterruptHandler);

*/
void IOCB4_DefaultInterruptHandler(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/