/**
  Generated Pin Manager File

  Company:
    Microchip Technology Inc.

  File Name:
    pin_manager.c

  Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for pin APIs for all pins selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC18F45K22
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.36 and above
        MPLAB             :  MPLAB X 6.00

    Copyright (c) 2013 - 2015 released Microchip Technology Inc.  All rights reserved.
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/
#include "../stdafx.h"
#include "pin_manager.h"




void (*IOCB4_InterruptHandler)(void);

void PIN_MANAGER_Initialize(void)
{
    /**
    LATx registers
    */
    LATE = 0x00;
    LATD = 0x00;
    LATA = 0x00;
    LATB = 0x00;
    LATC = 0x00;

    /**
    TRISx registers
    */
    TRISE = 0x00;
    TRISA = 0x00;//FF;
    //TRISAbits.RA6 = 1;
    //TRISAbits.RA7 = 1;
    //  switch + rotary encoder A & B 
    //  plus interrupt on change for alarm MFP from RTCC 
    TRISB = 0x00;
    TRISBbits.RB0 = 1;
    TRISBbits.RB1 = 1;
    TRISBbits.RB2 = 1;
    TRISBbits.RB4 = 1;    
    TRISBbits.RB5 = 1;    
    
    TRISC = 0x00;//FF;
    TRISCbits.RC3 = 1;
    TRISCbits.RC4 = 1;
    TRISD = 0x00;
    
    /**
    ANSELx registers
    */
    ANSELD = 0x00;//0F;
    ANSELC = 0x00;//E4;
    ANSELB = 0x00;//38;
    ANSELE = 0x00;//00;
    ANSELA = 0x00;//2F;

    /**
    WPUx registers
    */
    WPUB = 0x00;
    INTCON2bits.nRBPU = false;
    // Enable RBI interrupt 
    INTCONbits.RBIE = true; 
    IOCBbits.IOCB4 = true;
    IOCBbits.IOCB5 = true;
    
    
    //IOCB4_SetInterruptHandler(IOCB4_DefaultInterruptHandler);

}
  
void PIN_MANAGER_IOC(void)
{   
    // interrupt on change for pin IOCB4
    PORTB = PORTB;
    /*
     * the first is the alarm, second lights out. 
     * in either case ignore if the application state is NOT running. 
     */
    if (ApplicationState == Running)
    {
        if(IOCBbits.IOCB4 == true && PORTBbits.RB4 == true)
        {
            IOCB4_DefaultInterruptHandler(); 

        }	
        else if(IOCBbits.IOCB5 == true && PORTBbits.RB5 == true)
        {
            ApplicationState = Sleep;
            buttonPressOutstanding = true;
        }
    }
        
	// Clear global Interrupt-On-Change flag    
    INTCON3bits.INT2IF = false;
    INTCONbits.RBIF = false; 
}

/**
   IOCB4 Interrupt Service Routine
*/
void IOCB4_ISR(void) {

//    // Add custom IOCB4 code
//
//    // Call the interrupt handler for the callback registered at runtime
//    if(IOCB4_InterruptHandler)
//    {
//        IOCB4_InterruptHandler();
//    }
}

/**
  Allows selecting an interrupt handler for IOCB4 at application runtime
*/
void IOCB4_SetInterruptHandler(void (* InterruptHandler)(void)){
    IOCB4_InterruptHandler = InterruptHandler;
}

/**
  Default interrupt handler for IOCB4
*/
void IOCB4_DefaultInterruptHandler(void){
    // add your IOCB4 interrupt custom code
    // or set custom function using IOCB4_SetInterruptHandler()
    /*
     * means we have an alarm triggered. 
     * 
     * signal this thru application state 
     */
    if (ApplicationState == Running)
    {
        ApplicationState = AlarmTriggered;
    }
}

/**
 End of File
*/