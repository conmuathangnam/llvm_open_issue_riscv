/* 
 * File:   stdafx.h
 * Author: John
 *
 * Created on 06 May 2021, 10:55
 */

#ifndef STDAFX_H
#define	STDAFX_H

#ifdef	__cplusplus
extern "C" {
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include <xc.h>
#include "mcc_generated_files/device_config.h"
   
//#ifndef bool
//#define bool short 
//    
//#define bool        short
//#define true        1
//#define false       0
//    
//#endif
    
#define Buzzer              LD0
#define LCD_Backlight		LC6
#define ExternalPower		LC7
#define PowerExternal(onOrOff)   {LCD_Backlight = onOrOff; \
                             ExternalPower = onOrOff;}
/*
 * Application state machine 
 */

enum application_state
{
    Running,
    RunningPrintFullScreen,
    RunningChiming,
    RunningChimingHour,
    SetTime,
    SetAlarm0,
    SetAlarm1,
    Menu,
    MenuItemClicked,
    MenuStart,
    AlarmTriggered,
    Sleep    
};
/*
 * time management definitions 
 */
#include "timeManagement.h"

enum triStateBool
{
    FALSE,
    TRUE,
    IGNORE,
    BEFORE = FALSE,
    AFTER = TRUE,
    ON = IGNORE,
    UNSET = FALSE,      // clock has not been set nor has performed 
                        // a successful decode cycle
    SET = TRUE,         // clock has been set but has not decoded successfully
    DECODED = IGNORE    // has decoded successfully 
} triStateBool;


/*
 * THIS is the time 
 */
volatile RTCCTimeDate		Rtcctimedate;	
volatile RTCCTimeDate     RTCCAlarm0; 
volatile RTCCTimeDate     RTCCAlarm1; 

volatile enum application_state ApplicationState;     
volatile bool saveCCPR1LToEEPROMPlease;
volatile bool  buttonPressOutstanding; 
volatile unsigned char chimeCounter;

#ifdef	__cplusplus
}
#endif

#endif	/* STDAFX_H */

