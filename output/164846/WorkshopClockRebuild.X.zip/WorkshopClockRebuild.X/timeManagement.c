
#include "stdafx.h"
#include <string.h>
    
#include "timeManagement.h"
#include "rotaryencoder.h"
#include "BasicLCD.h"
#include "BCDArithmetic.h"

static char buffer[20]; 

void manageThisRTCC(RTCCTimeDate* currentObject_in)
{
    currentObject = currentObject_in;
}

void initialiseTimeManagement(void)
{
    currentObject = 0;
    
    RTCCAlarm0.isAlarm = true;
    resetThis(&RTCCAlarm0);    
    RTCCAlarm1.isAlarm = true;
    resetThis(&RTCCAlarm1);
    Rtcctimedate.isAlarm = false; 
    resetThis(&Rtcctimedate);    
}
void resetThis(RTCCTimeDate* timeObject)
{
    if (timeObject == 0)
    {
        return; 
    }
    timeObject->date.DST = false;
    timeObject->setStage = TSS_Day;
    timeObject->time.Hour = 0;
    timeObject->time.Min = 0;
    timeObject->time.Sec = 0;
    timeObject->date.isLeap = false;
    timeObject->date._FullDayByte.ALMIF = false; 
    timeObject->isAlarmSet = false; 
            
    if (!timeObject->isAlarm)
    {
        timeObject->date.Date = 1;
        timeObject->date.Day = 7;
        timeObject->date.Month = 1;
        timeObject->date.Year = 0x22;
    }
    else
    {
        timeObject->date.Year = 0;        
        timeObject->date.Day = 0;
        timeObject->date.Month = 0;
        timeObject->date.Date = 0;
     }
}

void setAlarm(bool alarm1)
{
   
    //* stage 1 - set the day 
    
    ApplicationState = alarm1 ? SetAlarm1 : SetAlarm0;
   
    manageThisRTCC(alarm1 ? &RTCCAlarm1 : &RTCCAlarm0);
   
    printDay(); 
    printTime(true); 
    printDate(); 
    currentObject->setStage = TSS_Day;
    setDateDayTime();     
    resetAlarmFlags(false);
    resetAlarmFlags(true);
}
void setDateDayTime(void)
{
    //* stage 1 - set the day 
    changeStage();
    printDay(); 
    
    while (currentObject->setStage == TSS_Day)
    {
       
        if (incrementEncoderValue(
                currentObject->isAlarm ? 0 : 1,
                7,1))
        {
            currentObject->date._FullDayByte.DayBits = getEncoderValue();    
            printDay(); 
        }       
    }
    changeStage();
    printTime(false);
    
    while (currentObject->setStage == TSS_Hour)
    {      
        if (incrementEncoderValue(0,23,1))
        {
            currentObject->time.Hour = convertBinary2BCD(getEncoderValue());    
            printTime(false); 
        }   
    }
    
    changeStage();
    
    while (currentObject->setStage == TSS_Min)
    {      
        if (incrementEncoderValue(0,59,1))
        {
            currentObject->time.Min = convertBinary2BCD(getEncoderValue());    
            printTime(false); 
        }   
    }
    changeStage();
    printDate(); 
    
    while (currentObject->setStage == TSS_Date)
    {      
        if (incrementEncoderValue(
                currentObject->isAlarm ? 0 : 1,                
                31,1))
        {
            currentObject->date.Date = convertBinary2BCD(getEncoderValue());    
            printDate(); 
        }   
    }
    changeStage();
    
    while (currentObject->setStage == TSS_Month)
    {      
        if (incrementEncoderValue(
                currentObject->isAlarm ? 0 : 1,
                12,1))
        {
            currentObject->date.Month = convertBinary2BCD(getEncoderValue());    
            printDate(); 
        }   
    }
    if (ApplicationState == SetTime)
    {
        changeStage();

        while (currentObject->setStage == TSS_Year)
        {      
            if (incrementEncoderValue(0,99,1))
            {
                currentObject->date.Year = convertBinary2BCD(getEncoderValue());    
                printDate(); 
            }   
        }
        currentObject->time.Sec = 0;
        /*
         * last job - calculate if we are in BST or not 
         */
        switch (currentObject->date.Month)
        {
            case 1:
            case 2:
                currentObject->date.DST = false;
                break;
            case 3:     // March 
                switch(isLastSundayOfMonth())
                {
                    case BEFORE:
                        currentObject->date.DST = false;            
                        break;
                    case AFTER:
                        currentObject->date.DST = true;            
                        break;
                    case ON:
                        currentObject->date.DST = currentObject->time.Hour >= 2;            
                        break;
                }
                break;

            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:            
                currentObject->date.DST = true;
                break;

            case 0x10:  // October
                switch(isLastSundayOfMonth())
                {
                    case BEFORE:
                        currentObject->date.DST = true;            
                        break;
                    case AFTER:
                        currentObject->date.DST = false;            
                        break;
                    case ON:
                        if (currentObject->time.Hour == 0)
                            currentObject->date.DST = true;            
                        else
                            currentObject->date.DST = false;            

                        break;
                }
                break;
            case 0x11:
            case 0x12:
                currentObject->date.DST = false;
                break;
        }
    }
    else
    {
        if (ApplicationState == SetAlarm0 ||
            ApplicationState == SetAlarm1)
        {
            /*
             * we need them to confirm the alarm....
             */
            currentObject->setStage = TSS_ALARM;
            blankLine(4);// position correctly    
            PrintMsg(timeSetStageString[currentObject->setStage]);
            /*
             * default is yes. 
             */
            Send_Cmd(line4 + 16);
            PrintMsg("Yes");
            
            while (currentObject->setStage == TSS_ALARM)
            {      
                if (incrementEncoderValue(0,1,1))
                {
                    Send_Cmd(line4 + 16);
                    PrintMsg(getEncoderValue() == 0 ? "Yes" : "No " ); 
                }   
            }
            /*
             * come out  - encoder = 0 means save 1 means abandon
             */
            switch (getEncoderValue())
            {
                case 0:  // means save and set the alarm
                    currentObject->date._FullDayByte.ALMPOL = 1;
                    currentObject->isAlarmSet = true;
                    WriteRTCCAlarm(ApplicationState == SetAlarm1); 
                    toggleAlarmOn(ApplicationState == SetAlarm1, true); 
                    break;
                case 1:  // means abandon
                    toggleAlarmOn(ApplicationState == SetAlarm1, false); 
                    resetThis(currentObject);
                    break;
            }
        }
    }
    
    ApplicationState = Running;
    Send_Cmd(CLR_DISP);
    Send_Cmd(DISP_HOME);
    /*
     * reset the running object to be the current time 
     */
    manageThisRTCC(&Rtcctimedate);
    printFullTimeScreen();
    
    currentObject->setStage = TSS_None;
    
}
void changeStage(void)
{
    blankLine(4);// position correctly    
    PrintMsg(timeSetStageString[currentObject->setStage]);
    
    int8_t value = 0;
    
    switch (currentObject->setStage)
    {
        case TSS_Year:    
            value = convertBCD2Binary(currentObject->date.Year);                
        break;    
        case TSS_Day:    
            value = currentObject->date._FullDayByte.DayBits;                
        break;
    
        case TSS_Month:    
            value = convertBCD2Binary(currentObject->date.Month);                
        break;
        
        case TSS_Date:    
            value = convertBCD2Binary(currentObject->date.Date);                            
        break;
        case TSS_Hour:
            value = convertBCD2Binary(currentObject->time.Hour);    
        break;   
        case TSS_Min:
            value = convertBCD2Binary(currentObject->time.Min);    
        break;
        default:
            return;
    }
    setEncoderValue(value);            
}
void printFullTimeScreen(void)
{
    
    /*
     * screen looks like this:
     * 
     * day of week
     * time 
     * date 
     * status
     * 
     *  
     
     */
    printDay(); 
    printTime(true); 
    printDate(); 
    printLine4Information();
}
void printLine4Information(void)
{
    blankLine(4);
    memset(&buffer[0], 0x00,20);       
    
    sprintf(buffer,
                "Alarm:1%s2%s Tune %d",
                RTCCAlarm0.isAlarmSet ? "Y" : "N",
                RTCCAlarm1.isAlarmSet ? "Y" : "N", 
                getOscillatorTuneValue());
    
    PrintMsg(buffer);		// print message  
    
}
void printDate()
{
    blankLine(3);
    
    memset(&buffer[0], 0x00,20);       
    
    unsigned short monthAsBinary = convertBCD2Binary(currentObject->date.Month);
    
    if ( monthAsBinary > 0x0c)
    {
        sprintf(buffer,
                "Shite Month %d",
                monthAsBinary);
       
    }
    else
    {
        if (ApplicationState == SetAlarm0 ||
            ApplicationState == SetAlarm1)
        {
            // setting an alarm - don;t want the year 
           sprintf(buffer,
                monthsminusYear[monthAsBinary],
                convertBCD2Binary(currentObject->date.Date));
        }
        else
        {
            sprintf(buffer,
                months[monthAsBinary],
                convertBCD2Binary(currentObject->date.Date),
                convertBCD2Binary(currentObject->date.Year));
        }
        
    }
    
    PrintMsg(buffer);		// print message  
}
void printDay(void)
{
    blankLine(1);
    
    if (currentObject->date._FullDayByte.DayBits >= 0 && 
        currentObject->date._FullDayByte.DayBits <= 7)
    {
        PrintMsg(days[currentObject->date._FullDayByte.DayBits]);
    }
    else
    {
        sprintf(buffer,"Shite Day %X", currentObject->date._FullDayByte.DayBits);
        PrintMsg(buffer);		// print message  
    }    
}

void printTime(const bool withBlank)
{
    memset(&buffer[0], 0x00,20);
    if (withBlank)
    {
        blankLine(2);
        
        sprintf(buffer,"      %0.2d:%0.2d:%0.2d  %s",
                    convertBCD2Binary(currentObject->time.Hour),
                    convertBCD2Binary(currentObject->time.Min),
                    convertBCD2Binary(currentObject->time.Sec),
                    currentObject->date.DST ? "BST" : "UTC");
        
        PrintMsg(buffer);		// print message  

        return;
    }
    
    Send_Cmd(DISP_HOME);
    
    if ((currentObject->time.Sec == 0 && 
        currentObject->time.Min == 0) || 
        currentObject->setStage == TSS_Hour)
    {
        sprintf(buffer,"%0.2d:",convertBCD2Binary(currentObject->time.Hour));

        Send_Cmd(TIME_HOUR_POS);

        PrintMsg(buffer);		// print message  
    }
    if (currentObject->time.Sec == 0  || 
        currentObject->setStage == TSS_Min)
    {
        sprintf(buffer,"%0.2d:",convertBCD2Binary(currentObject->time.Min));

        Send_Cmd(TIME_MIN_POS);    
        PrintMsg(buffer);		// print message  
    }
    /*
     * ALWAYS do second 
     */
    sprintf(buffer,"%0.2d",convertBCD2Binary(currentObject->time.Sec));

    Send_Cmd(TIME_SEC_POS);        
    PrintMsg(buffer);		// print message  
    
//    sprintf(buffer,"%s",currentObject->date.DST ? "BST" : "UTC");
//
//    Send_Cmd(TIME_DST_POS);        
//    PrintMsg(buffer);		// print message  
//        
//    
}
void printEncoderValue(void)
{
    char buffer[6]; 
     
    for (unsigned int i=0;i<sizeof(buffer);i++)
    {
        buffer[i] = 0X00;
    }

    sprintf(buffer,"%d",
        getEncoderValue());

    //Send_Cmd(DD_RAM_ADDR);	// set the RAM address
    Send_Cmd(line1 + 16);
    
    PrintMsg("     ");
    Send_Cmd(line1 + 16);
    PrintMsg(buffer);		// print message
}
enum triStateBool isLastSundayOfMonth(void)
{   
    /* 
     * and then ONLY the last Sunday of the month 
     * is it the last Sunday of the month?
     * 
     * both months have 31 days so the last date that can be a Sunday
     * is the 25th, so before that cannot be the last Sunday.
    */
   if (Rtcctimedate.date.Date < 0x25)
   {
       return BEFORE;
   }
   /*
    *  so - the possibilities are: 
    * 
    *   25	Sunday    Saturday  Friday	  Thursday	Wednesday Tuesday	Monday
        26	Monday    Sunday	Saturday  Friday	Thursday  Wednesday	Tuesday
        27	Tuesday   Monday	Sunday	  Saturday	Friday	  Thursday	Wednesday
        28	Wednesday Tuesday   Monday	  Sunday	Saturday  Friday	Thursday
        29	Thursday  Wednesday Tuesday	  Monday	Sunday	  Saturday	Friday
        30	Friday    Thursday  Wednesday Tuesday	Monday	  Sunday	Saturday
        31	Saturday  Friday	Thursday  Wednesday	Tuesday	  Monday	Sunday
    *
    * if the day is Sunday - then this IS the last Sunday    
    */
    if (Rtcctimedate.date.Day == 1)
    {
        return ON;
    }
    /*
     * otherwise we need to calculate how much of the week is left before 
     * we reach another 
     * 
     *           = how many days left in month + day number. 
     * 
     * if you perform this calculation you get this table
     * 
     *      6	12	11	10	9	8	7
            6	5	11	10	9	8	7
            6	5	4	10	9	8	7
            6	5	4	3	9	8	7
            6	5	4	3	2	8	7
            6	5	4	3	2	1	7
            6	5	4	3	2	1	0

     * 
     * SO - if we blow the number of days in the week index i.e. 6 then we were 
     * before the last Sunday otherwise we were after. 
     * 
     * now - remember that Date is BCD so we can;t do arithmetic on it exactly. 
     * convert that to a binary number first
     */
   int binaryDate = Rtcctimedate.date.Date & 0x0F0;
   binaryDate  >>= 4;
   binaryDate *= 10;
   binaryDate  += Rtcctimedate.date.Date & 0x00F ;
   
   int dateOffset = 31 - binaryDate + (int) Rtcctimedate.date.Day;

   if (dateOffset <= 6)
   {
       
       return AFTER;
   }
  
   return BEFORE;
}
bool isLeapYear(const char year)
{
    if (year == 0) return true;
    
    int yearNumber = 2000 + year;

    return (yearNumber % 4) || ((yearNumber % 100 == 0) &&
	(yearNumber % 400)) ? false : true;
}