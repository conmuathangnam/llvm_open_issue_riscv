#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=WorkshopClockRebuild.X.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/WorkshopClockRebuild.X.production.hex
