
#include "stdafx.h"
#include <string.h>
    

#include "BasicLCD.h"
#include "rotaryencoder.h"

void Send_Cmd(const char lpszCmd)
{
	Busy_Check();					// wait for it 	
	
#ifdef	USING8BIT
	LCD_DATA_LATCH	= 	lpszCmd;		// address the byte to send

	RW			= 	write; 			// go into write mode
	RS			= 	instruction;	// its a command 
	LCD_STROBE;						// Enable then disable E line	
#else
	/// send the high nibble first 
	unsigned char temp = lpszCmd;
	temp &=	0x0F0;

	//LCD_DATA_LATCH	= 	temp;		// address the byte to send
    LCD_DATA	= 	temp;			// address the byte to send
	
	RW			= 	write; 			// go into write mode
	RS			= 	instruction;	// its a command 
	LCD_STROBE;						// Enable then disable E line	
	/// then send the low nibble 
	temp = lpszCmd;
	temp = temp << 4;
	temp &=	0x0F0;
	
	//LCD_DATA_LATCH	= 	temp;
    LCD_DATA	= 	temp;			// address the byte to send
	
	RW			= 	write; 			// go into write mode
	RS			= 	instruction;	// its a command 
	LCD_STROBE;						// Enable then disable E line	

#endif
    
    //Busy_Check();
}
void	Send_Data(const char lpszData)
{
	Busy_Check();					// wait for it 	
	
#ifdef	USING8BIT
	LCD_DATA	= 	lpszData;		// address the byte to send
	RW			= 	false; 			// go into write mode
	RS			= 	data;			// its data
	LCD_STROBE;						// Enable then disable E line	
#else
	/// send the high nibble first 
	char temp = lpszData;
	temp &=	0x0F0;
	
	//LCD_DATA_LATCH	= 	temp;			// address the byte to send
	LCD_DATA	= 	temp;			// address the byte to send
	RW			= 	write; 			// go into write mode
	RS			= 	data;			// its data
	LCD_STROBE;						// Enable then disable E line	
	/// then send the low nibble
	temp = lpszData;
	temp  = temp << 4;
	temp &=	0x0F0;
	//LCD_DATA_LATCH	= 	temp;
    LCD_DATA	= 	temp;			// address the byte to send
	
	RW			= 	write; 			// go into write mode
	RS			= 	data;			// its data
	LCD_STROBE;						// Enable then disable E line	
#endif
    
  //  Busy_Check();
}
void PowerDownIn5(void)
{
	__delay_ms(50);			// wait 50 mS before turning off the display and going to sleep 

	Send_Cmd(DISP_OFF);		// turn the display off 	
	PORTC = 0;				// otherwise we get a large current drain 
	PORTA = 0 ; 
	PORTB = 0 ; 
    PORTD = 0;
    PORTE = 0;
}
void PowerUp(const char chPowerUp )
{	
    if (!initialised)
    {
        // step 2 - power up delay go for 15mS
        __delay_ms(50);

        // step 3 - send the start up sequence to the LCD module - we CANT use the BUSY_FLAG yet
#ifdef USING8BIT
        LCD_DATA		= 0x038;	// 8 bool interface - 2 lines
        LCD_STROBE;						
#else

        RS = false;
        RW = false;
        E  = false;  

        LCD_DATA    		= 0x30;	// 4 bool interface - using the high nibble of PORT
        RS = false;
        RW = false;
        LCD_STROBE;	
        __delay_us(50);

        //LCD_DATA_LATCH		= 0x020;	// 4 bool interface - using the high nibble of PORT
        LCD_DATA    		= 0x020;	// 4 bool interface - using the high nibble of PORT    
        RS = false;
        RW = false;
        LCD_STROBE;	


        LCD_DATA		= 0x080;	// 4 bool interface - using the high nibble of PORT
        RS = false;
        RW = false;
        LCD_STROBE;	

        __delay_us(50);

        LCD_DATA		= 0x020;	// 4 bool interface - using the high nibble of PORT
        RS = false;
        RW = false;
        LCD_STROBE;	

        LCD_DATA		= 0x080;	// 4 bool interface - using the high nibble of PORT
        RS = false;
        RW = false;
        LCD_STROBE;	

#endif
        /*
            busy flag should be available from this point on..
        */
         __delay_ms(10);
    }
    
    initialised = true; 
    
    //Send_Cmd(DISP_OFF);		// turn the display off        
    Send_Cmd(chPowerUp);	// turn the display on with the parameterised start up 
	Send_Cmd(CLR_DISP);		// clear it 
    //Send_Cmd(DISP_Mode_4Bit);	// set the display mode				
    Send_Cmd(ENTRY_MODE_SET);	// set the RAM address    
    //Send_Cmd(DD_RAM_ADDR);	// set the RAM address
    Send_Cmd(DISP_HOME);	// go home ET
}
void PrintMsg(const char* lpmsg)
{
	do 
	{
		Send_Data(*lpmsg);
		lpmsg ++;
	} while (*lpmsg != 0x00);
}

void Busy_Check(void)
{
	/*
		step 1 set the data port for READ
	*/
	unsigned char temp;
        
    LCD_DATA_TRIS	=	0b11110000;		// make all high nibble pins read 

	do
	{	
        RS				= 	instruction;// register select = instruction
        RW				=	read;		// set direction to read	
    	LCD_STROBE;
    	
#ifdef	USING8BIT	
	 	temp = LCD_DATA;		// read that port value	 	
	} while (BUSY_FLAG);			// is the busy flag set?
#else
		temp = LCD_DATA;		// read that port value
		
		temp &= 0xF0;				// mask out lower nibble
						
        RS				= 	instruction;// register select = instruction
        RW				=	read;		// set direction to read	
		LCD_STROBE;	
        
        unsigned char temp2 = LCD_DATA;		// read that port value
		temp2 = temp2 >>	4;		// shift down a bool 
		temp2 &= 0X0F;				// mask out the higher rubbish
		
		temp	|= 	temp2; 	
        
        temp &= BUSY_FLAG;  // just test the busy flag 
        
	} while (temp != 0);			// is the busy flag set?

    
#endif
	
	LCD_DATA_TRIS	=	0b00000000;;		// ok we're done - set the port back to write	
}
void blankLine(const unsigned short line)
{
    Send_Cmd(DISP_HOME);
    switch (line)
    {
        case 1:
            Send_Cmd(line1);
            break;
        case 2:
            Send_Cmd(line2);
            break;
        case 3:
            Send_Cmd(line3);
            break;
        case 4:
            Send_Cmd(line4);
            break;
        default:
            return;
    }   
    char buffer[20];
    memset(&buffer[0], 0x00,20);
    memset(&buffer[0], 0x20,19);    
    PrintMsg(buffer);		// print message  
    Send_Cmd(DISP_HOME);
    
    switch (line)
    {
        case 1:
            Send_Cmd(line1);
            break;
        case 2:
            Send_Cmd(line2);
            break;
        case 3:
            Send_Cmd(line3);
            break;
        case 4:
            Send_Cmd(line4);
            break;
        default:
            return;
    }
}
