
#include "menuManager.h"
#include "BasicLCD.h"
#include "rotaryencoder.h"

/*extern*/
bool  IsMenuActive(void) 
{
    return (const bool) currentMenuLevel !=  Menu_None;
}
/*
 * return true if the ApplicationState has changed false if not 
 */
bool  processMenu(void)
{
    /*
     * 
     * called from main loop when state machine is in menu mode. 
     * 
     */
    if (ApplicationState == MenuItemClicked)
    {
        return selectCurrentMenuItem();
    }
    while (ApplicationState == Menu)
    {
        if (currentMenuLevel == Menu_Top)
        {
            if (incrementEncoderValue(0,g_menus[currentMenuLevel].maxLevel, 1))
            {
                currentMenuEntry = getEncoderValue();
                DrawCursor();
            }
        }
        else if (currentMenuLevel == Menu_OscillatorTune)
        {
            if (incrementEncoderValue(-254, 254, 2))
            {
                oscillatorTuneValue = getEncoderValue();
                printEncoderValue(); 
            }
        }
        else if (currentMenuLevel == Menu_Alarms)
        {
            if (incrementEncoderValue(0,g_menus[currentMenuLevel].maxLevel, 1))
            {
                currentMenuEntry = getEncoderValue();
                DrawCursor();
            }
        }
    }
    return false; 
}
/*
 * return true if the ApplicationState has changed false if not 
 */
bool selectCurrentMenuItem(void)
{
    /*
     * user has clicked the button during menu mode
     * 
     * First question - are we at the last entry in the menu - if so then that 
     * always means done
     */
    if (currentMenuEntry == g_menus[currentMenuLevel].maxLevel)
    {              
        currentMenuLevel =  g_menus[currentMenuLevel].menu_parent;
        
        /*
         *  have we clicked done on the last menu? 
         */
        if (currentMenuLevel == Menu_None)
        {
            ApplicationState = RunningPrintFullScreen;
            return true; 
        }
        
        if (currentMenuLevel == Menu_Top)
            ShowMainMenu();
        
        currentMenuEntry =  g_menus[currentMenuLevel].maxLevel;  
        DrawCursor();
        
        return false;
    }
    if (currentMenuLevel == Menu_Top)
    {
        switch (currentMenuEntry)
        {
            case 0:         // means set time 
                ApplicationState = SetTime;
                return true; 
            case 1:         // means set alarms - show alarm menu 
                PrintMenu(Menu_Alarms);
                break; 
            case 2:         // means set oscillator tune show screen 
                currentMenuEntry = Menu_OscillatorTune;
                currentMenuLevel = Menu_OscillatorTune;
                ShowOscillatorTune();
                break;                 
        }
    }
    else if (currentMenuLevel == Menu_OscillatorTune)
    {
        switch (currentMenuEntry)
        {
            case 0:         // means set time 
                ApplicationState = SetTime;
                return true; 
            case 1:         // means set alarms - show alarm menu 
                break; 
            case Menu_OscillatorTune:         // means set oscillator tune show screen 
                setOscillatorTune(); 
                PrintMenu(Menu_Top);
                currentMenuEntry = 3;
                DrawCursor();
                break;                 
        }
    }
    else if (currentMenuLevel == Menu_Alarms)
    {
        switch (currentMenuEntry)
        {
            case 0:         // means alarm 0 
                ApplicationState = SetAlarm0;
                return true; 
            case 1:         // means alarm 1
                ApplicationState = SetAlarm1;
                return true;  
        }
    }
    return false; 
}

extern bool menuNavigate(const enum MenuNavigationAction action)
{
    if (currentMenuLevel == Menu_None)
    {
        return false; // Eh?
    }
    if (currentMenuLevel < Menu_None || currentMenuLevel > Menu_DefineAlarm )
    {
        currentMenuLevel = Menu_None;
        return false;
    }
    bool movedSoDrawCursor = false; 
     
    switch(action)
    {
        case Menu_Navi_Up:                    
            if (currentMenuLevel == Menu_DefineAlarm)
            {
                return false;
            }
            currentMenuEntry--;                   
            movedSoDrawCursor = true;

            break;

        case Menu_Navi_Down:                    
            if (currentMenuLevel == Menu_DefineAlarm)
            {
                return false;
            }
            currentMenuEntry++;                   
            movedSoDrawCursor = true;

            break;
    }
    
    if (movedSoDrawCursor)
    {    
        if (currentMenuEntry < 0)
            currentMenuEntry = g_menus[currentMenuLevel].maxLevel;
        else if (currentMenuEntry > g_menus[currentMenuLevel].maxLevel)
            currentMenuEntry = 0;

        DrawCursor();
        return true; // nothing else to do here .
    }

    /*
     * if not up or down then it MUST be mode switch 
     * 
     * First question - are we at the last entry in the menu - if so then that 
     * always means done
     */
    if (currentMenuEntry == g_menus[currentMenuLevel].maxLevel)
    {
        if (currentMenuLevel == Menu_DefineAlarm)
        {
            saveCCPR1LToEEPROMPlease = true;
            
        }
              
        currentMenuLevel =  g_menus[currentMenuLevel].menu_parent;
        
        
        if (currentMenuLevel == Menu_None)
            return false;
        
        if (currentMenuLevel == Menu_Top)
            ShowMainMenu();
        
        currentMenuEntry =  g_menus[currentMenuLevel].maxLevel;  
        DrawCursor();
        
        return true;
    }
    switch (currentMenuLevel)
    {
        case Menu_Top:           // in the top level menu 
           
            break;
    }    
    return true;
}
void PrintMenu(const enum MenuLevel menu)
{
    Send_Cmd(CLR_DISP);                 // clear screen
    
    currentMenuLevel = menu; 
    
    switch (currentMenuLevel)
    {
        case Menu_None:          // don't do anything else - not a menu             
            break;
        case Menu_Top:
            ShowMainMenu();
            break;
        case Menu_OscillatorTune:
            ShowOscillatorTune();
            break;
        case Menu_Alarms:
            currentMenuEntry = 0;
            ShowAlarmSelect(); 
            break;
    }
    DrawCursor();
}
void ShowMainMenu(void)
{
    oscillatorTuneValue = 0;
    setEncoderValue(oscillatorTuneValue);
    Send_Cmd(line1);
    PrintMsg(" : Set Time         ");
    Send_Cmd(line2);
    PrintMsg(" : Set Alarms       ");
    Send_Cmd(line3);
    PrintMsg(" : Oscillator Tune  ");
    Send_Cmd(line4);
    PrintMsg(" : Done             ");
    currentMenuEntry = 0;
    currentMenuLevel = Menu_Top;
    //DrawCursor();
}
void ShowOscillatorTune(void)
{
    Send_Cmd(CLR_DISP);    
    Send_Cmd(DISP_HOME);
    
    Send_Cmd(line3);
    PrintMsg(" If clock is slow,");
    Send_Cmd(line4);
    PrintMsg("use -ve values.   ");
    
    Send_Cmd(DISP_HOME);    
    Send_Cmd(line1);
    PrintMsg("Oscillator Tune ");
    
    setEncoderValue(getOscillatorTuneValue());
    printEncoderValue();
}
void ShowAlarmSelect(void)
{
    Send_Cmd(CLR_DISP);    
    Send_Cmd(DISP_HOME);
    
    Send_Cmd(line1);
    PrintMsg(" : Set Alarm 1      ");
    Send_Cmd(line2);
    PrintMsg(" : Set Alarm 2      ");
    Send_Cmd(line3);
    PrintMsg(" : Done             ");
}
void DrawCursor(void)
{
    /*
     * erase all previous cursors
     */
    Send_Cmd(line1);
    PrintMsg(" ");
    Send_Cmd(line2);
    PrintMsg(" ");
    Send_Cmd(line3);
    PrintMsg(" ");
    Send_Cmd(line4);
    PrintMsg(" ");
    
    switch (currentMenuEntry)
    {
        /// position the cursor at line1,2,3,4 col 0;
        case 0:
            Send_Cmd(line1);            
            break;
        case 1:
            Send_Cmd(line2);
            break;
        case 2:
            Send_Cmd(line3);
            break;
        case 3:
            Send_Cmd(line4);
            break;        
    }
    PrintMsg(">");
}
/*
 * this poor chap was homeless - so put him here 
 */
void setOscillatorTune(void)
{
    blankLine(4);
    Send_Cmd(line3);
    PrintMsg(" Setting tuning...  ");
    __delay_ms(1000);

    setOscillatorTuneValue(getEncoderValue());
    
    Send_Cmd(line3);
 
    PrintMsg(" Tuning set.        ");
    __delay_ms(1000);
    
}