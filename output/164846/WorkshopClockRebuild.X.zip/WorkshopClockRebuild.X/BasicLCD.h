

#include <htc.h>
#include "mcc_generated_files/device_config.h"
/*
	addressing lines in the lcd DDRAM
	
		line 1 = 0x000
		line 2 = 0x040
		line 3 = 0x014
		line 4 = 0x054
*/
/*;
;
; LCD Module commands
;
*/
#define DISP_ON			0x00C			//; Display on
#define DISP_ON_C		0x00E			//; Display on, Cursor on
#define DISP_ON_B		0x00F			//; Display on, Cursor on, Blink cursor
#define DISP_OFF		0x008			//; Display off
#define CLR_DISP		0x001			//; Clear the Display
#define DISP_HOME		0x002			//; Go HOME ET
#define ENTRY_MODE_SET  0b01100000      // increment don't shift
#define DISP_Mode_8Bit	0b00110000		// set the display mode 8 bool 2 line 5*7 dots
#define DISP_Mode_4Bit	0b00100000		// set the display mode 4 bool 2 line 5*7 dots
#define line1			0x080			// address of first byte of line 1 anded with 0x80
#define line2			0x0c0			// address of first byte of line 2 anded with 0x80
#define line3			0x094			// address of first byte of line 3 anded with 0x80
#define line4			0x0d4			// address of first byte of line 4 anded with 0x80
#define line1_Entry		0x089			// address of first byte of line 1 anded with 0x80
#define line2_Entry		0x0c9			// address of first byte of line 2 anded with 0x80
#define TIME_HOUR_POS   0x0C6			// address of first byte of line 2 anded with 0x80
#define TIME_MIN_POS    0x0C9			// address of first byte of line 2 anded with 0x80
#define TIME_SEC_POS    0x0CC			// address of first byte of line 2 anded with 0x80
#define TIME_DST_POS    0x0D0			// address of first byte of line 2 anded with 0x80

#define line3_Entry		0x09d			// address of first byte of line 3 anded with 0x80
#define line4_Entry		0x0dd			// address of first byte of line 4 anded with 0x80
#define DD_RAM_ADDR		0x080			//; Least Significant 7-bool are for address
#define DD_RAM_UL		0x080			//; Upper Left coner of the Display
#define	RS				LD1
#define	RW				LD2
#define	E				LD3

#define	instruction		0
#define data			1
#define	BUSY_FLAG		0X80
#define read			1
#define write			0
#define true            1
#define false			0
#define LCD_DATA		PORTD
#define LCD_DATA_TRIS	TRISD
#define LCD_DATA_LATCH  LATD

#define LCD_PORT_CMD	PORTE

#define	LCD_STROBE	((E = true),(E = false))


/*
	now some function prototypes
*/

extern void Send_Cmd(const char lpszCmd);
extern void Send_Data(const char lpszData);
extern void PowerDownIn5(void);
extern void PowerUp(const char chPowerUp );
extern void PrintMsg(const char* lpmsg);
extern void Busy_Check(void);
extern void blankLine(const unsigned short line);

extern void    printEncoderValue(void);

static bool initialised = false;

