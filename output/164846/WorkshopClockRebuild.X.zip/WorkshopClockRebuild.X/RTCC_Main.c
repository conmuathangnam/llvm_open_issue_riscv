#include "stdafx.h"
#include "RTCC_Main.h"
#include "mcc_generated_files/examples/i2c1_master_example.h"
#include "timeManagement.h"

void initialiseRTCC(void)
{
    /*
     * make sure the ST start oscillator short in the seconds register is ON
     * 
     */
    uint8_t Temp = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_SEC_REG);
    
	if(!(Temp & RTCC_EN_OSC_START))
	{
        Temp |= RTCC_EN_OSC_START; 
        
		//Oscillator short of RTCC is off. Turn on to start RTCC function
		I2C1_Write1ByteRegister(CNTRL_BYTE_SRAM_RTCC, RTCC_SEC_REG, Temp);
	}
    /*
     * for the time being - make suer the control register all bits are 
     * 0 - no alarms - no output on MPF and no trim. 
     */
    
    I2C1_Write1ByteRegister(CNTRL_BYTE_SRAM_RTCC, RTCC_CNTRL_REG, 0x00);    
}

/********************************************************************
 * Function:        void ReadRTCCTimeDate(RTCCTimeDate* ptrToUserVal)
 *
 * PreCondition:    RTCCTimeDate structure must have been declared.
 *
 * Input:           Address of typedefined RTCCTimeDate structure
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Update typedefined RTCCTimeDate structure with Time
 *					and Date read from MCP7941x
 *******************************************************************/
void ReadRTCCTimeDate(void)
{
 	Rtcctimedate.time.Sec = (I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_SEC_REG) & 0x7F); 
	Rtcctimedate.time.Min = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_MIN_REG);
	Rtcctimedate.time.Hour = (I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_HOUR_REG) & 0x3F);
	
	Rtcctimedate.date.Day = (I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_DAY_REG) & 0x07);
	Rtcctimedate.date.Date = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_DATE_REG);
	uint8_t Temp = (I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_MONTH_REG));
        
    Rtcctimedate.date.isLeap = Temp & 0x20;
    Rtcctimedate.date.Month = Temp & 0x1F;
    
	Rtcctimedate.date.Year = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_YEAR_REG);
}

/********************************************************************
 * Function:        void WriteRTCCTimeDate(RTCCTimeDate* ptrToUserVal)
 *
 * PreCondition:    RTCCTimeDate structure must have been declared.
 *
 * Input:           Address of typedefined RTCCTimeDate structure
 *
 * Output:          None
 *
 * Side Effects:    It is firmware responsibility to load correct format of Hour register.
 *					If 24hour mode is selected while initialising MCP7941x then hour register
 *					should be loaded accordingly
 *
 * Overview:        Update MCP7941x Time & Date registers with the value
 *					provided in typedefined RTCCTimeDate structure 
 *******************************************************************/
void WriteRTCCTimeDate(void)
{
 	uint8_t Temp = 0;

	//Rtcctimedate.time.Sec = Rtcctimedate.time.Sec | 0x80;
	I2C1_Write1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_SEC_REG, Rtcctimedate.time.Sec | 0x80) ;

	I2C1_Write1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_MIN_REG,Rtcctimedate.time.Min);

	/*Temp = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_HOUR_REG);
    //               
	Temp = Temp & 0b000111111;
	Rtcctimedate.time.Hour = Rtcctimedate.time.Hour | Temp;*/
	I2C1_Write1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_HOUR_REG,Rtcctimedate.time.Hour);    
  	I2C1_Write1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_YEAR_REG, Rtcctimedate.date. Year) ;
	I2C1_Write1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_MONTH_REG, Rtcctimedate.date.Month) ;
	/*
     * preserve OSCRUN short 
     */
	I2C1_Write1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_DAY_REG,Rtcctimedate.date.Day | 0b00100000);
	I2C1_Write1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_DATE_REG, Rtcctimedate.date.Date) ;
}
void ReadRTCCAlarm(short alarm1)
{
 	/*
     * seconds 
     */	
	if (alarm1)
        RTCCAlarm1.time.Sec = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_ALARM1_SEC_REG);
    else
        RTCCAlarm0.time.Sec = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_ALARM0_SEC_REG);
    
    /*
     * minutes 
     */	
    if (alarm1)
        RTCCAlarm1.time.Min = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_ALARM1_MIN_REG);
    else
        RTCCAlarm0.time.Min = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_ALARM0_MIN_REG);
        
    /*
     * hours
     */	
	if (alarm1)
        RTCCAlarm1.time.Hour = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_ALARM1_HOUR_REG);
    else
        RTCCAlarm0.time.Hour = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_ALARM0_HOUR_REG);
    /*
     * date 
     */	
    if (alarm1)
        RTCCAlarm1.date.Date = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_ALARM1_DATE_REG);
    else
        RTCCAlarm0.date.Date = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_ALARM0_DATE_REG);
    
    /*
     * month
     */	
    if (alarm1)
        RTCCAlarm1.date.Month = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_ALARM1_MONTH_REG);
    else
        RTCCAlarm0.date.Month = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_ALARM0_MONTH_REG);

    /*
     * weekday - short more complicated as it contains a lot of 
     * the flags 
     * REGISTER 4-11: ALMxWKDAY: WEEKDAY VALUE REGISTER 
        R/W-0 R/W-0 R/W-0 R/W-0 R/W-0 R/W-0 R/W-0 R/W-1
        ALMPOL ALMxMSK2 ALMxMSK1 ALMxMSK0 ALMxIF WKDAY2 WKDAY1 WKDAY0
        short 7 short 0
        Legend:
        R = Readable short W = Writable short U = Unimplemented short, read as ?0?
        -n = Value at POR ?1? = Bit is set ?0? = Bit is clear x = Bit is unknown
        short 7 ALMPOL: Alarm Interrupt Output Polarity short
        1 = Asserted output state of MFP is a logic high level
        0 = Asserted output state of MFP is a logic low level
        short 6-4 ALMxMSK<2:0>: Alarm Mask bits
        000 = Seconds match
        001 = Minutes match
        010 = Hours match (logic takes into account 12-/24-hour operation)
        011 = Day of week match
        100 = Date match
        101 = Reserved; do not use
        110 = Reserved; do not use
        111 = Seconds, Minutes, Hour, Day of Week, Date and Month
        short 3 ALMxIF: Alarm Interrupt Flag short(1,2)
        1 = Alarm match occurred (must be cleared in software)
        0 = Alarm match did not occur
        short 2-0 WKDAY<2:0>: Binary-Coded Decimal Value of Day bits
        Contains a value from 1 to 7. The representation is user-defined.
     */	
    if (alarm1)
        RTCCAlarm1.date.Day = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_ALARM1_DAY_REG);
    else
        RTCCAlarm0.date.Day = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_ALARM0_DAY_REG);
    
}
void toggleAlarmOn(short alarm1, short enable)
{
    unsigned char temp = I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_CNTRL_REG);
    
    if (enable)
    {
        if (alarm1)
            temp |= RTCC_EN_ALM1;
        else
            temp |= RTCC_EN_ALM0;
    }
    else
    {
        if (alarm1)
            temp &= 0xFF - RTCC_EN_ALM1;
        else
            temp &= 0xFF - RTCC_EN_ALM0;
    }
    I2C1_Write1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_CNTRL_REG, temp) ;
    
}
unsigned char getAlarmFlags(short alarm1)
{
    return I2C1_Read1ByteRegister(
            CNTRL_BYTE_SRAM_RTCC,
            alarm1 ? RTCC_ALARM1_DAY_REG : RTCC_ALARM0_DAY_REG );   
}
void resetAlarmFlags(short alarm1)
{
    unsigned char temp = I2C1_Read1ByteRegister(
            CNTRL_BYTE_SRAM_RTCC,
            alarm1 ? RTCC_ALARM1_DAY_REG : RTCC_ALARM0_DAY_REG );   
    if (temp & RTCC_ALARM_INT_FLAG)
    {
        int y=0;
        y++;
    }
    temp &= 0xFF - RTCC_ALARM_INT_FLAG;  // reset the flag 
    
    I2C1_Write1ByteRegister(CNTRL_BYTE_SRAM_RTCC,
            alarm1 ? RTCC_ALARM1_DAY_REG : RTCC_ALARM0_DAY_REG,
            temp) ;
}
void WriteRTCCAlarm(short alarm1)
{
 	/*
     * seconds 
     */	
	I2C1_Write1ByteRegister(
            CNTRL_BYTE_SRAM_RTCC,
            alarm1 ? RTCC_ALARM1_SEC_REG : RTCC_ALARM0_SEC_REG, 
            alarm1 ? RTCCAlarm1.time.Sec : RTCCAlarm0.time.Sec) ;
    /*
     * minutes 
     */	
	I2C1_Write1ByteRegister(
            CNTRL_BYTE_SRAM_RTCC,
            alarm1 ? RTCC_ALARM1_MIN_REG : RTCC_ALARM0_MIN_REG, 
            alarm1 ? RTCCAlarm1.time.Min : RTCCAlarm0.time.Min) ;
    /*
     * hours
     */	
	I2C1_Write1ByteRegister(
            CNTRL_BYTE_SRAM_RTCC,
            alarm1 ? RTCC_ALARM1_HOUR_REG : RTCC_ALARM0_HOUR_REG, 
            alarm1 ? RTCCAlarm1.time.Hour : RTCCAlarm0.time.Hour) ;
	
	/*
     * date 
     */	
	I2C1_Write1ByteRegister(
            CNTRL_BYTE_SRAM_RTCC,
            alarm1 ? RTCC_ALARM1_DATE_REG : RTCC_ALARM0_DATE_REG, 
            alarm1 ? RTCCAlarm1.date.Date : RTCCAlarm0.date.Date) ;
	/*
     * month
     */	
	I2C1_Write1ByteRegister(
            CNTRL_BYTE_SRAM_RTCC,
            alarm1 ? RTCC_ALARM1_MONTH_REG : RTCC_ALARM0_MONTH_REG, 
            alarm1 ? RTCCAlarm1.date.Month  : RTCCAlarm0.date.Month) ;
	

    /*
     * weekday - short more complicated as it contains a lot of 
     * the flags 
     * REGISTER 4-11: ALMxWKDAY: WEEKDAY VALUE REGISTER 
        R/W-0 R/W-0 R/W-0 R/W-0 R/W-0 R/W-0 R/W-0 R/W-1
        ALMPOL ALMxMSK2 ALMxMSK1 ALMxMSK0 ALMxIF WKDAY2 WKDAY1 WKDAY0
        short 7 short 0
        Legend:
        R = Readable short W = Writable short U = Unimplemented short, read as ?0?
        -n = Value at POR ?1? = Bit is set ?0? = Bit is clear x = Bit is unknown
        short 7 ALMPOL: Alarm Interrupt Output Polarity short
        1 = Asserted output state of MFP is a logic high level
        0 = Asserted output state of MFP is a logic low level
        short 6-4 ALMxMSK<2:0>: Alarm Mask bits
        000 = Seconds match
        001 = Minutes match
        010 = Hours match (logic takes into account 12-/24-hour operation)
        011 = Day of week match
        100 = Date match
        101 = Reserved; do not use
        110 = Reserved; do not use
        111 = Seconds, Minutes, Hour, Day of Week, Date and Month
        short 3 ALMxIF: Alarm Interrupt Flag short(1,2)
        1 = Alarm match occurred (must be cleared in software)
        0 = Alarm match did not occur
        short 2-0 WKDAY<2:0>: Binary-Coded Decimal Value of Day bits
        Contains a value from 1 to 7. The representation is user-defined.
     */	
    unsigned char maskbits = 0x80; // for polarity
    if (alarm1)
    {
        if (RTCCAlarm1.time.Min > 0)
        {
            maskbits |= 0x10;
        }
        if (RTCCAlarm1.time.Hour > 0)
        {
            maskbits |= 0x20;
        }
        if (RTCCAlarm1.date.Date > 0)
        {
            maskbits |= 0x40;
        }
        RTCCAlarm1.date.Day |= maskbits;
    }
    else
    {
        if (RTCCAlarm0.time.Min > 0)
        {
            maskbits |= 0x10;
        }
        if (RTCCAlarm0.time.Hour > 0)
        {
            maskbits |= 0x20;
        }
        if (RTCCAlarm0.date.Date > 0)
        {
            maskbits |= 0x40;
        }
        RTCCAlarm0.date.Day |= maskbits;
    }
	I2C1_Write1ByteRegister(
            CNTRL_BYTE_SRAM_RTCC,
            alarm1 ? RTCC_ALARM1_DAY_REG : RTCC_ALARM0_DAY_REG, 
            alarm1 ? RTCCAlarm1.date.Day : RTCCAlarm0.date.Day);
		
}
/*
 * OSCTRIM Register 
 * 
 * REGISTER 4-15: OSCTRIM: OSCILLATOR DIGITAL TRIM REGISTER (ADDRESS 0x08)
    R/W-0 R/W-0 R/W-0 R/W-0 R/W-0 R/W-0 R/W-0 R/W-0
    SIGN TRIMVAL6 TRIMVAL5 TRIMVAL4 TRIMVAL3 TRIMVAL2 TRIMVAL1  TRIMVAL0
    short 7                                                       short 0

 * Legend:
 * R = Readable short W = Writable short U = Unimplemented short, read as ?0?
 * -n = Value at POR ?1? = Bit is set ?0? = Bit is clear x = Bit is unknown
 * short 7 SIGN: Trim Sign short
 * 1 = Add clocks to correct for slow time
 * 0 = Subtract clocks to correct for fast time
 * 
    short 6-0 TRIMVAL<6:0>: Oscillator Trim Value bits
    When CRSTRIM = 0:
    1111111 = Add or subtract 254 clock cycles every minute
    1111110 = Add or subtract 252 clock cycles every minute
    ???
    0000010 = Add or subtract 4 clock cycles every minute
    0000001 = Add or subtract 2 clock cycles every minute
    0000000 = Disable digital trimming
    When CRSTRIM = 1:
    1111111 = Add or subtract 254 clock cycles 128 times per second
    1111110 = Add or subtract 252 clock cycles 128 times per second
    ???
    0000010 = Add or subtract 4 clock cycles 128 times per second
    0000001 = Add or subtract 2 clock cycles 128 times per second
    0000000 = Disable digital trimming
 * 
 * 
 */
/*
 * input - signed 16 short integer from encoder 
 * 
 * convert to signed 8 short value as per spec sheet 
 * set in register OSCTRIM 
 */
int16_t getOscillatorTuneValue(void)
{
    // read the first 7 bits to get the value then read the 
    const char value_from_register = 
        I2C1_Read1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_OSCTRIM_REG);
    /*
     * because we are working in 2's we need to shift the value up 1 short 
     */
    char value = value_from_register & 0x7F; 
    short sign = value_from_register & 0x80; 
    /*
     * now convert these 2 into a 16 short signed integer 
     */
    int16_t returnValue = value << 1;
    if (returnValue != 0)
    {
        if (sign)
        {
            /*
             * 2's compliment this to convert to a signed negative integer
             */
            returnValue -= 1; 
            returnValue ^= 0XFFFF;
            return returnValue; 
        }
    }
    return returnValue; 
}
void    loadOscillatorTuneValueFromEEPROM(void)
{
    /*
     *  ok - on start up - lets go get the OSCTRIM byte from the EEPROM
     * and write that to the RTCC OSCTRIM register.      * 
    */    
  	EEADR = 0x00;
    EECON1bits.EEPGD = false;
    EECON1bits.CFGS = false;
    EECON1bits.RD = true; 
    
    I2C1_Write1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_OSCTRIM_REG,EEDATA);

}

void    setOscillatorTuneValue(int16_t value)
{
    /*
     * ok - so essentially we want to convert the incoming 
     * number into a signed byte to write to the register 
     */
    
    
    uint8_t value2Write = (uint8_t) value;

    short negative = value & 0x8000;
    
    if (negative)
    {
        // 2's compliment     
        value2Write ^= 0XFF;
        value2Write += 1; 
    }
    // shift down a short 
    
    value2Write >>= 1;
    
    // set the sign short 
    
    if (negative)
        value2Write |= 0x80;

    I2C1_Write1ByteRegister(CNTRL_BYTE_SRAM_RTCC,RTCC_OSCTRIM_REG,value2Write);
    saveOscillatorTuneValueToEEPROM(value2Write); 
}
void    saveOscillatorTuneValueToEEPROM(uint8_t value2Write)
{
  
    /*
     *  ok - so now its stored in the volatile RTCC register, we also need 
     * to save it in the PIC EEPROM so we can retrieve on power up.
     * 
     * 
    */    
  	EEADR = 0x00;
    //EEADRH = 0x00;
    EEDATA = value2Write;
    EECON1bits.EEPGD = false;
    EECON1bits.CFGS = false;
    EECON1bits.WREN = true; 
    INTCONbits.GIE = false;         // turn off interrupts 
    /*
     * this is the correct EEPROM write sequence - 
     */
    EECON2 = 0x55;
    EECON2 = 0xAA;
    EECON1bits.WR = true; 
    
    while (EECON1bits.WR);
    PIR2bits.EEIF = false;
    EECON1bits.WREN = false; 
    INTCONbits.GIE = true;         // turn interrupts back on 
}
