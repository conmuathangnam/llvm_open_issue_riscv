/* 
 * File:   RTCC_Main.h
 * Author: johnm
 *
 * Created on August 9, 2022, 3:31 PM
 */

#ifndef RTCC_MAIN_H
#define	RTCC_MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif
#include "stdafx.h"
    

#define		CNTRL_BYTE_SRAM_RTCC					0b01101111
#define		CNTRL_BYTE_EEPROM_RTCC					0b01010111
#define		SRAM_BLOCK_SIZE							64
#define		SRAM_BLOCK_START_ADD					0x20
#define		EEPROM_PAGE_SIZE						8
#define		UNIQUE_ID_START_ADD						0xF0

#define		RTCC_SEC_REG							0x00
#define		RTCC_MIN_REG							0x01
#define		RTCC_HOUR_REG							0x02
#define		RTCC_DAY_REG							0x03
#define		RTCC_DATE_REG							0x04
#define		RTCC_MONTH_REG							0x05
#define		RTCC_YEAR_REG							0x06
#define		RTCC_CNTRL_REG							0x07
#define		RTCC_OSCTRIM_REG						0x08
#define		RTCC_UNLOCK_REG							0x09
#define		RTCC_ALARM0_SEC_REG						0x0A
#define		RTCC_ALARM0_MIN_REG						0x0B
#define		RTCC_ALARM0_HOUR_REG					0x0C
#define		RTCC_ALARM0_DAY_REG						0x0D
#define		RTCC_ALARM0_DATE_REG					0x0E
#define		RTCC_ALARM0_MONTH_REG					0x0F
#define		RTCC_ALARM1_SEC_REG						0x11	
#define		RTCC_ALARM1_MIN_REG						0x12
#define		RTCC_ALARM1_HOUR_REG					0x13
#define		RTCC_ALARM1_DAY_REG						0x14
#define		RTCC_ALARM1_DATE_REG					0x15
#define		RTCC_ALARM1_MONTH_REG					0x16

#define		RTCC_EN_OSC_START						0x80
#define		RTCC_EN_12_24							0x40
#define		RTCC_EN_VBATEN							0x08
#define		RTCC_EN_VBAT							0x10
#define		RTCC_EN_OSCON							0x20
#define		RTCC_EN_LP								0x20
#define		RTCC_EN_RS0								0x01
#define		RTCC_EN_RS1								0x02
#define		RTCC_EN_RS2								0x04
#define		RTCC_EN_EXTOSC							0x08
#define		RTCC_EN_ALM0							0x10
#define		RTCC_EN_ALM1							0x20
#define		RTCC_EN_SQWE							0x40
#define		RTCC_EN_OUT								0x80

#define		RTCC_EN_ALARM_SEC_MATCH					0x00
#define		RTCC_EN_ALARM_MIN_MATCH					0x10
#define		RTCC_EN_ALARM_HOUR_MATCH				0x20
#define		RTCC_EN_ALARM_DAY_MATCH					0x30
#define		RTCC_EN_ALARM_DATE_MATCH				0x40
#define		RTCC_EN_ALARM_TIMESTAMP_MATCH			0x70
#define		RTCC_ALARM_INT_FLAG                     0X08
    

#define		RTCC_MFP_1HZ							0x00
#define		RTCC_MFP_4096HZ							0x01
#define		RTCC_MFP_8192HZ							0x02
#define		RTCC_MFP_32768HZ						0x03
#define		RTCC_CRSTRIM                            0x04
#define		RTCC_CAL_ENABLE							0x10;	


void ReadRTCCTimeDate(void);
void WriteRTCCTimeDate(void);
void initialiseRTCC(void); 

int16_t getOscillatorTuneValue(void); 
void    setOscillatorTuneValue(int16_t value); 
void    loadOscillatorTuneValueFromEEPROM(void); 
void    saveOscillatorTuneValueToEEPROM(uint8_t value2Write); 

void ReadRTCCAlarm(short alarm1);
void WriteRTCCAlarm(short alarm1);
void toggleAlarmOn(short alarm1, short enable);
unsigned char getAlarmFlags(short alarm1);
void resetAlarmFlags(short alarm1);


#ifdef	__cplusplus
}
#endif

#endif	/* RTCC_MAIN_H */

