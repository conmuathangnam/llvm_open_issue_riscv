/* 
 * File:   time Management.h
 * Author: johnm
 *
 * Created on 08 August 2022, 12:04
 */

#ifndef TIME_MANAGEMENT_H
#define	TIME_MANAGEMENT_H

/*
 * Time and alarm setting stage
 */
enum timeSetStage
{
    TSS_None,
    TSS_Day,
    TSS_Hour,
    TSS_Min,
    TSS_Date,
    TSS_Month,
    TSS_Year,
    TSS_ALARM,
    TSS_DONE
};
    
const char* timeSetStageString[8]     = {
   /*1...5....0....5....0*/
    "Setting: None       ",
    "Setting: Day        ",
    "Setting: Hour       ",
    "Setting: Minute     ",
    "Setting: Date       ",
    "Setting: Month      ",
    "Setting: Year       ",
    "Set Alarm Y/N?      "   
};


const char* days[8]     = {
   /*1...5....0....5....0*/
    "       No day       ",
    "       Sunday       ",
    "       Monday       ",
    "      Tuesday       ",
    "      Wednesday     ",
    "      Thursday      ",
    "       Friday       ",
    "      Saturday      "
};

const char* months[13]     = {
   /*1...5....0....5....0*/
    "       No month     ",
    "  %0.2d January 20%0.2d",
    "  %0.2d February 20%0.2d",
    "    %0.2d March 20%0.2d",
    "    %0.2d April 20%0.2d",
    "    %0.2d May 20%0.2d",
    "    %0.2d June 20%0.2d",
    "    %0.2d July 20%0.2d",
    "   %0.2d August 20%0.2d",
    "  %0.2d September 20%0.2d",
    "   %0.2d October 20%0.2d",
    "  %0.2d November 20%0.2d",
    "  %0.2d December 20%0.2d"
};

const char* monthsminusYear[13]     = {
   /*1...5....0....5....0*/
    "      %0.2d  No month",
    "      %0.2d January",
    "      %0.2d February",
    "        %0.2d March",
    "        %0.2d April",
    "        %0.2d May",
    "        %0.2d June",
    "        %0.2d July",
    "       %0.2d August",
    "      %0.2d September",
    "       %0.2d October",
    "      %0.2d November",
    "      %0.2d December"
};


typedef struct{
	unsigned char Sec;
	unsigned char Min;
	unsigned char Hour;
}RTCCTime;

typedef struct{
	union{
		unsigned char Day;	//This will be used when Alarm is to be read
		struct{
			unsigned DayBits : 3;           // BCD Day bits 
			unsigned ALMIF : 1;         // alarm interrupt flag 
			unsigned ALMConfig : 3;     // alarm masks 
			unsigned ALMPOL : 1;        // alarm polarity MFP 
		}_FullDayByte;
	};
	unsigned char Date;
	unsigned char Month;
	unsigned char Year;
    bool         DST;
    bool         isLeap;
}RTCCDate;

typedef struct{
	RTCCTime time;
    RTCCDate date;
    enum timeSetStage setStage;
    bool isAlarm;
    bool isAlarmSet;
}RTCCTimeDate;
//
//typedef struct{
//	
//	union{
//		unsigned char FullDayByte;	//This will be used when Alarm is to be read
//		struct{
//			unsigned Day : 3;           // BCD Day bits 
//			unsigned ALMIF : 1;         // alarm interrupt flag 
//			unsigned ALMConfig : 3;     // alarm masks 
//			unsigned ALMPOL : 1;        // alarm polarity MFP 
//		}_FullDayByte;
//	};
//	unsigned char Sec;
//	unsigned char Min;
//	unsigned char Hour;
//	unsigned char Date;
//	unsigned char Month;
//    enum timeSetStage setStage;
//}RTCCAlarm;

//typedef struct{
//	union{
//		unsigned char Day_Month;
//		struct{
//			unsigned Month : 5;
//			unsigned Day : 3;
//		};
//	};
//	unsigned char Min;
//	unsigned char Hour;
//	unsigned char Date;
//}RTCCTimeStampVcc;


#include "RTCC_Main.h"


void setDateDayTime(void);
void setAlarm(bool alarm1);


void printFullTimeScreen(void);
void printTime(const bool withBlank);
void printDate(void);
void printDay(void);
void printLine4Information(void);
            
void changeStage(void);
enum triStateBool isLastSundayOfMonth(void);
bool isLeapYear(const char year);

void manageThisRTCC(RTCCTimeDate* currentObject_in);

RTCCTimeDate* currentObject;

void resetThis(RTCCTimeDate* currentObject);

void initialiseTimeManagement(void);

#endif	/* TIME_MANAGEMENT_H */

