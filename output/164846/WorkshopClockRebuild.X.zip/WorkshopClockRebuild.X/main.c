/**
  Generated Main Source File
  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC18F45K22
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
*/
#include "stdafx.h"
#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/device_config.h"
#include "mcc_generated_files/i2c1_master.h"
#include "mcc_generated_files/examples/i2c1_master_example.h"
#include "BasicLCD.h"        /// include for LCD 
#include "rotaryencoder.h"
#include "timeManagement.h"
#include "RTCC_Main.h"
#include "BCDArithmetic.h"
#include "menuManager.h"

#pragma warning disable  2053
#pragma warning disable  520
#pragma warning disable  1020

void printFullScreenForApplicationState(void);
void printRunningScreen(void);
void check4ChimesAndDSTAdjust(void);
void DSTAdjust(void);
bool AdjustRTCCTimeforDST(enum triStateBool whichWay);

void processChimes(void);                
void processAlarmTrigger(void);
#define countDownToSleepValue 6;

/*
    Main application
 */
void main(void)
{
    // Initialise the device
    SYSTEM_Initialize();
   /*
     * have to ask for oscillator stability????
     */
    OSCCONbits.HFIOFS = true;
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    //INTCON2bits.INTEDG0 = 0;
    //INTCON2bits.INTEDG1 = 0;
    INTCON2bits.INTEDG2 = 1;
    INTCONbits.RBIE = true;
    IOCBbits.IOCB5 = false;

    initialiseEncoder();
    initialiseTimeManagement();
    loadOscillatorTuneValueFromEEPROM(); 
      
    short firstTimeStartUp = true;
    
wakeMeUpAgain:;
  
    manageThisRTCC(&Rtcctimedate);
   
   
    initialiseRTCC(); 
    PowerExternal(true);
    PowerUp(DISP_ON);		// turn the LCD on
   
    if (firstTimeStartUp)
    {
        ApplicationState = SetTime;

        setDateDayTime();  
    
        WriteRTCCTimeDate();       
        ApplicationState = Running;
    }
    else
    {
        Send_Cmd(line2);
        PrintMsg(" Buon giorno,");
        Send_Cmd(line3);
        PrintMsg(" come stai?");
        __delay_ms(5000);
        ReadRTCCTimeDate();
        DSTAdjust();
        
        ApplicationState = RunningPrintFullScreen;     
    }        
    
    buttonPressOutstanding = false; 
    chimeCounter = 0; 
    short countDown = 10; 
    short mainLoopRunning = true;
    
    short countDownToSleep = countDownToSleepValue;// seconds 
    while (mainLoopRunning)
    {
        printFullScreenForApplicationState();
    
        countDown = 10; 
        while (countDown > 0)
        {
            countDown--;            
            __delay_ms(50);
            if (buttonPressOutstanding)
            {                
                break; 
            }
        }       
        buttonPressOutstanding = false;
        short alarm1 = false; 
        
        switch (ApplicationState)
        {
            case Running:
                INTCONbits.RBIE = true;
                IOCBbits.IOCB5 = true;  // now we can wait for lights out
                check4ChimesAndDSTAdjust();
                break;
                // fall thru intentional
            case RunningChiming:
                // fall thru intentional
            case RunningChimingHour:
                
                processChimes();
                
                break; 
            case SetTime:
                /*
                 * this does not return 
                 */
                Rtcctimedate.setStage = TSS_Day;
                ApplicationState = SetTime;    
                setDateDayTime();
                WriteRTCCTimeDate();
                printFullScreenForApplicationState();
                break; 
            case SetAlarm1:
                alarm1 = true;
                // fall thru intentional
            case SetAlarm0:
                 /*
                 * this does not return 
                 */
                setAlarm(alarm1); 
                /*
                 * when we come back we need to revert to the current 
                 * date and time object 
                 */
                ApplicationState = RunningPrintFullScreen;
                manageThisRTCC(&Rtcctimedate);
   
                break;
            case MenuStart:
                PrintMenu(Menu_Top);
                ApplicationState = Menu;
                break;
            case Menu:
                /*
                 * this does not return 
                 */
                processMenu();
                printFullTimeScreen();
                countDownToSleep = countDownToSleepValue;// seconds 
                break;
            case MenuItemClicked:            
                /*
                 * this WILL return 
                 */
                if (!processMenu())
                {
                    ApplicationState = Menu;
                }
                //printFullTimeScreen();
                break;
            case AlarmTriggered:
                /*
                 * we've an alarm gone off                  
                 */
                processAlarmTrigger();
                ApplicationState = RunningPrintFullScreen;   
                break;
            case Sleep:
                /*
                 * light change on photo diode pin 
                 * 
                 */
                countDownToSleep--;
                
                if (countDownToSleep == 0)
                {
                    countDownToSleep = countDownToSleepValue;// seconds 
                    mainLoopRunning = false; 
                }
                break; 
        }    
    
    }
    
    Send_Cmd(CLR_DISP);
    Send_Cmd(line2);
    PrintMsg(" Buona notte caro!");

    // want to come back HERE not the ISR - turn the GIE flag off 
    /*
     * we want to wake up with interrupts on the light sensor 
     * only 
     */
    
    INTCONbits.GIE = false; 
    INTCONbits.INT0IE = false; 
    INTCONbits.RBIE = true; 
    IOCBbits.IOCB4 = false;
    IOCBbits.IOCB5 = true;
    INTCON3bits.INT2IE = false;
    INTCON3bits.INT1IE = false;
    /*
     * make sure all interrupt flags are cleared 
     */
    INTCONbits.INT0IF = false; 
    INTCONbits.RBIF = false; 
    INTCON3bits.INT1F = false;
    INTCON3bits.INT1IF = false;
    INTCON3bits.INT2IF = false; 
    
    __delay_ms(5000);
    
    PowerDownIn5(); 
    PowerExternal(false);
    
    
    Sleep();
    
    ApplicationState = RunningPrintFullScreen;
    /*
     * ok - so when we wake up we will come back here 
     */
    INTCONbits.GIE = true; 
    INTCONbits.RBIE = true; 
    IOCBbits.IOCB4 = true;
    IOCBbits.IOCB5 = false;         // don't worry about light yet 
    INTCON3bits.INT2IE = true;
    
    firstTimeStartUp = false;
    
  
    ReadRTCCTimeDate();
  
    goto wakeMeUpAgain;
}
void printFullScreenForApplicationState(void)
{
    switch (ApplicationState)
    {
        case Running:
            // fall thru intentional
        case RunningChiming:
            printRunningScreen();
            break; 
        case RunningPrintFullScreen:
            ApplicationState = Running;
            // fall thru intentional
        case SetTime:
            
            printFullTimeScreen();
            break; 
        case SetAlarm0:
        case SetAlarm1:
            break;
        case MenuStart:
            
            break; 
        case Menu:
            processMenu();
            break;
        case AlarmTriggered:
        case Sleep:
            break; 
    }    
}
void printRunningScreen(void)
{
    unsigned short currentDay =  Rtcctimedate.date.Date;
    /*
     * measured - this call takes 55 ms
     */
    ReadRTCCTimeDate();

    if (currentDay != Rtcctimedate.date.Date)
    {
        /*
         * day change over - lets go print the whole thing 
         */
        printFullTimeScreen();
       
    }  
    else
    {
        printTime(false);
    }
}
void check4ChimesAndDSTAdjust(void)
{
    /*
     * single chime on quarter, half and 3 quarter minutes 
     * 
     * chime number of hours on hour
     */
   
    if ( chimeCounter != 0)
    {
        // already doing it 
        return;
    }
    if (Rtcctimedate.time.Sec != 0)
    {             
        /*
         * now is not the time (Charles)
         */
        return;
    }
    if (Rtcctimedate.time.Min  == 0)
    {
        chimeCounter = convertBCD2Binary(Rtcctimedate.time.Hour);
        if (chimeCounter > 12)
        {
            // only do this in 12 hour clock 
            chimeCounter -= 12; 
        }
        else if (chimeCounter == 0)
        {
            chimeCounter = 12; 
        }
         ApplicationState = RunningChimingHour;
         /*
          * make any changes for daylight saving time 
          */
         DSTAdjust();
    }
    else if (Rtcctimedate.time.Min == 0X15)
    {
        chimeCounter = 1;
        ApplicationState = RunningChiming;
    }
    else if (Rtcctimedate.time.Min == 0x30)
    {
        chimeCounter = 1;
        ApplicationState = RunningChiming;
    }            
    else if (Rtcctimedate.time.Min == 0x45)
    {
        chimeCounter = 1;
        ApplicationState = RunningChiming;
    }
}
void processChimes(void)
{
    if (chimeCounter > 0)
    { 
        Buzzer = !Buzzer; 
        if (chimeCounter == 1)
        {
            if (ApplicationState == RunningChimingHour)
                __delay_ms(250);
            else
                __delay_ms(100);
        }
        else
        {
            __delay_ms(100);
        }
        chimeCounter --;
        setEncoderValue(chimeCounter);
        printEncoderValue();
    }
    else
    {
        printDay();
        ApplicationState = Running;
        Buzzer = false;
    }
}
void DSTAdjust(void)
{
    /*
    * now calculate the BST changes if needed
     * 
     * 
     * The idea is to check for a mismatch between the Rtcctimedate.date.DST
     * flag and the date. 
    */
    bool result = false; 
    
    if (Rtcctimedate.date.DST == false)
    {
        /*  DST is UNSET
         * 
         * this means we should be before the last day of march or after 
         * the last day of October. Lets check that 
         */
        switch (Rtcctimedate.date.Month)
        {
            case 1:     // Jan 
                        // fall through intentional 
            case 2:     // feb 
            case 11:    // nov
            case 12:    // dec 
                // nothing to do here 
                return ;
            /*
             * for all of these we should be in DST - so go set it now 
             */
            case 4:     // April 
                        // fall through intentional 
            case 5:     // May
            case 6:     // June 
            case 7:     // July
            case 8:     // August 
            case 9:     // September
                result = AdjustRTCCTimeforDST(SET);
                break; 
            case 3:     // March 
                /*
                 * for March we should be BEFORE the last day and after 1AM
                 * ON the day which we probably will be... 
                 */
                switch (isLastSundayOfMonth())                        
                {
                    case ON:
                        if (Rtcctimedate.time.Hour >= 0x01 )
                            result = AdjustRTCCTimeforDST(SET);
                        break; 
                    case BEFORE:
                        return;
                    case AFTER:
                        result = AdjustRTCCTimeforDST(SET);
                        break;                     
                }
                break;
            case 10:
                /*
                 * for October we should be AFTER the last day and after 2am 
                 * ON the day  
                 */
                switch (isLastSundayOfMonth())                        
                {
                    case ON:
                        if (Rtcctimedate.time.Hour < 0x02 )
                            result = AdjustRTCCTimeforDST(SET);
                        break; 
                    case AFTER:
                        return;
                    case BEFORE:
                        result = AdjustRTCCTimeforDST(SET);
                        break;                     
                }
                break;
                
                
        }
    }
    else
    {
        /*
         * DST IS SET 
         * 
         * this means we should be after the last day of march or before 
         * the last day of October. Lets check that 
         */
        switch (Rtcctimedate.date.Month)
        {
            case 4:     // April 
                        // fall through intentional 
            case 5:     // May
            case 6:     // June 
            case 7:     // July
            case 8:     // August 
            case 9:     // September
                // nothing to do here 
                return ;
            case 1:     // Jan 
                        // fall through intentional 
            case 2:     // feb 
            case 11:    // nov
            case 12:    // dec 
                result = AdjustRTCCTimeforDST(UNSET);
                break; 
            case 3:     // March 
                /*
                 * for March we should be BEFORE the last day and after 1AM
                 * ON the day which we probably will be... 
                 */
                switch (isLastSundayOfMonth())                        
                {
                    case ON:
                        if (Rtcctimedate.time.Hour < 0x01 )
                            result = AdjustRTCCTimeforDST(UNSET);
                        break; 
                    case AFTER:
                        return;
                    case BEFORE:
                        result = AdjustRTCCTimeforDST(UNSET);
                        break;                     
                }
                break;
            case 10:
                /*
                 * for October we should be AFTER the last day and after 2am 
                 * ON the day  
                 */
                switch (isLastSundayOfMonth())                        
                {
                    case ON:
                        if (Rtcctimedate.time.Hour >= 0x02 )
                            result = AdjustRTCCTimeforDST(UNSET);
                        break; 
                    case BEFORE:
                        return;
                    case AFTER:
                        result = AdjustRTCCTimeforDST(UNSET);
                        break;                     
                }
                break;
        }
    }
   if (result == true)
   {          
        chimeCounter++;
        WriteRTCCTimeDate();
        printTime(true);

   }
}
bool AdjustRTCCTimeforDST(enum triStateBool whichWay)
{
    switch (whichWay)
    {
        case UNSET:
            /*
             * means we were in DST but need to move out 
             */
            Rtcctimedate.time.Hour --;
            Rtcctimedate.date.DST = false;
            break; 
        case SET:
            /*
             * means we were NOT in DST but need to move in
             */
            Rtcctimedate.time.Hour ++;
            Rtcctimedate.date.DST = true;
            break; 
        case IGNORE:
            return false; 
    }    
    return true; 
}
void processAlarmTrigger(void)
{
    /*
     * Alarm has gone off - ok lets see which one
     * 
     */
    short which = false; 
    
    unsigned char alarmFlags = getAlarmFlags(which); // start with alarm 0
    
    if (alarmFlags & RTCC_ALARM_INT_FLAG)
    {
        // its this one 
    }
    else
    {
        which = true; 
        alarmFlags = getAlarmFlags(which); 
        if (alarmFlags & RTCC_ALARM_INT_FLAG)
        {
            // its this one 
        }
        else
        {
            ApplicationState = Running; 
            // that shouldn't happen 
            return;
        }
    }
    
    Send_Cmd(CLR_DISP);
    
    blankLine(1);
    char buffer [20];
    
    memset(&buffer[0],0x00,20);
    
    sprintf(buffer,"Alarm Triggered: %X", alarmFlags);    
    PrintMsg(buffer);
  
    blankLine(2);
    PrintMsg("   Press button to  ");
  
    blankLine(3);
    PrintMsg("    acknowledge.");
    
    blankLine(4);
    PrintMsg("  Auto Stop in 15s  ");
    
    resetAlarmFlags(false);
    resetAlarmFlags(true);
    uint8_t count = 0;
    Buzzer = true;             // buzzer on 
    while (!buttonPressOutstanding)
    {
        __delay_ms(100);
        count ++;
        if (count % 5 == 0)
        {
            Buzzer = !Buzzer; 
        }
        if (count % 10 == 0)
        {
            // every second 
            Send_Cmd(line4 + 15);
            memset(&buffer[0],0x00,5);
            sprintf(buffer,"%ds  ", 15 - (count / 10));    
            PrintMsg(buffer);          
        }
        if (count == 150)
        {
            break;
        }
    }
    // done 
    buttonPressOutstanding = false;     
    INTCONbits.RBIE = true;    
}
/**
 End of File
*/