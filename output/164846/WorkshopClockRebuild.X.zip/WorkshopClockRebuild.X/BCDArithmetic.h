/* 
 * File:   BCDArithmetic.h
 * Author: John
 *
 * Created on 09 March 2022, 11:50
 * 
 * perform simple arithmetic on small BCD numbers used in RTCC
 */

#ifndef BCDARITHMETIC_H
#define	BCDARITHMETIC_H

#ifdef	__cplusplus
extern "C" {
#endif

short convertBCD2Binary(unsigned char input);
unsigned char  convertBinary2BCD(short input);



#ifdef	__cplusplus
}
#endif

#endif	/* BCDARITHMETIC_H */

