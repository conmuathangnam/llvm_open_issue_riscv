define i1 @foo(i1 %v) {            ; assume %v is 1
entry:
  %not = xor i1 %v, 1              ; 0
  %not1 = xor i1 %not, 1           ; 1
  %mul = mul i1 %v, 1              ; 1
  %sub = sub i1 %not1, %mul        ; 0
  ret i1 %sub                      ; 0
}
