# 1 "<built-in>"
# 1 "test.c"
void* memcpy();
struct s
{
    char g[2048];
};
void a(struct s *dst, const int *src)
{
    memcpy(dst, src, sizeof(*dst));
}
