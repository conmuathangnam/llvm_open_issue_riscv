// Module partition: defaults
module;

#include <string>
#include <string_view>

export module mymodule:defaults;

export namespace mylib::defaults {

inline const std::string DEFAULT_DATA = "G1 X0 Y0 Z0";

inline std::string getData() {
    return DEFAULT_DATA;
}

} // namespace mylib::defaults
