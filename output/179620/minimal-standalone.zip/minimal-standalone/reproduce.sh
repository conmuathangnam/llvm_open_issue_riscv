#!/bin/bash
# Minimal reproducer for clang static analyzer crash
#
# Root cause: C++20 modules + coverage flags + module partitions
# NO external dependencies required (no CTRE)
#
# Tested with: clang version 21.1.6

set -ex

rm -f *.pcm *.o main

echo "=== Building modules with coverage flags ==="

clang++ -std=c++26 -fprofile-instr-generate -fcoverage-mapping \
    --precompile mymodule-defaults.cppm -o mymodule-defaults.pcm

clang++ -std=c++26 -fprofile-instr-generate -fcoverage-mapping \
    -fmodule-file=mymodule:defaults=mymodule-defaults.pcm \
    --precompile mymodule-common.cppm -o mymodule-common.pcm

clang++ -std=c++26 -fprofile-instr-generate -fcoverage-mapping \
    -fmodule-file=mymodule:defaults=mymodule-defaults.pcm \
    -fmodule-file=mymodule:common=mymodule-common.pcm \
    --precompile mymodule.cppm -o mymodule.pcm

echo ""
echo "=== Running static analyzer (this will crash) ==="
clang++ --analyze -std=c++26 \
    -fmodule-file=mymodule=mymodule.pcm \
    -fmodule-file=mymodule:defaults=mymodule-defaults.pcm \
    -fmodule-file=mymodule:common=mymodule-common.pcm \
    main.cpp

echo "Exit code: $?"
