// Module partition: common (WITHOUT CTRE)
module;

#include <string>
#include <sstream>
#include <vector>

export module mymodule:common;
import :defaults;

export namespace mylib {

// Simple function templates (no CTRE)
template<typename T>
std::string to_str(T value) {
    std::ostringstream oss;
    oss << value;
    return oss.str();
}

template<typename T, typename U>
std::string combine(T a, U b) {
    return to_str(a) + " + " + to_str(b);
}

std::string process(const std::string& input, float value) {
    if (input.empty()) return defaults::getData();
    return to_str(value);
}

} // namespace mylib
