// main.cpp with includes like the original project
#include <fstream>
#include <iostream>
#include <string>

import mymodule;

int main() {
    auto r1 = mylib::process("M109 S200", 220.0f);
    auto r2 = mylib::process("G1 Z10.5", 15.0f);
    auto r3 = mylib::process("", 0.0f);

    std::cout << r1 << std::endl;
    std::cout << r2 << std::endl;

    return 0;
}
