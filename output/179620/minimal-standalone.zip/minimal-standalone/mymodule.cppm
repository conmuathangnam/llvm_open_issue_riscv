// Main module interface with partitions
export module mymodule;

export import :defaults;
export import :common;
