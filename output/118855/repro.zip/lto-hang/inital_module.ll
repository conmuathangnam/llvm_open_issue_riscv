; *** IR Dump After Annotation2MetadataPass on [module] ***
; ModuleID = 'lto_hang.577eccc79634c19c-cgu.0'
source_filename = "lto_hang.577eccc79634c19c-cgu.0"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-fuchsia"

@0 = private unnamed_addr constant <{ [8 x i8], [8 x i8] }> <{ [8 x i8] zeroinitializer, [8 x i8] undef }>, align 8
@1 = private constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCscguycxaEVVT_3std2rt10lang_startuE0INtNtNtCsaflpkWScbL9_4core3ops8function6FnOnceuE9call_once6vtableCs7vJBeK7brjY_8lto_hang, ptr @_RNCINvNtCscguycxaEVVT_3std2rt10lang_startuE0Cs7vJBeK7brjY_8lto_hang, ptr @_RNCINvNtCscguycxaEVVT_3std2rt10lang_startuE0Cs7vJBeK7brjY_8lto_hang }>, align 8, !dbg !0
@2 = private unnamed_addr constant <{ [1 x i8], [1 x i8] }> <{ [1 x i8] zeroinitializer, [1 x i8] undef }>, align 1
@3 = private unnamed_addr constant <{ [82 x i8] }> <{ [82 x i8] c"unsafe precondition(s) violated: hint::unreachable_unchecked must never be reached" }>, align 1
@4 = private unnamed_addr constant <{ [5 x i8] }> <{ [5 x i8] c"add: " }>, align 1
@5 = private unnamed_addr constant <{ [1 x i8] }> <{ [1 x i8] c"\0A" }>, align 1
@6 = private unnamed_addr constant <{ ptr, [8 x i8], ptr, [8 x i8] }> <{ ptr @4, [8 x i8] c"\05\00\00\00\00\00\00\00", ptr @5, [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@7 = private unnamed_addr constant <{ [34 x i8] }> <{ [34 x i8] c"../../src/lib/lto-hang/src/main.rs" }>, align 1
@8 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @7, [16 x i8] c"\22\00\00\00\00\00\00\00\17\00\00\00\09\00\00\00" }>, align 8
@9 = private unnamed_addr constant <{ [12 x i8] }> <{ [12 x i8] c"overflowed2!" }>, align 1
@10 = private unnamed_addr constant <{ ptr, [8 x i8] }> <{ ptr @9, [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
@11 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @7, [16 x i8] c"\22\00\00\00\00\00\00\00\15\00\00\00\0D\00\00\00" }>, align 8
@__rustc_debug_gdb_scripts_section__ = linkonce_odr unnamed_addr constant [34 x i8] c"\01gdb_load_rust_pretty_printers.py\00", section ".debug_gdb_scripts", align 1

; Function Attrs: inlinehint nounwind optsize shadowcallstack uwtable
define internal void @_RINvMs0_NtCsaflpkWScbL9_4core3fmtNtB6_9Arguments6new_v1Kj2_Kj1_ECs7vJBeK7brjY_8lto_hang(ptr dead_on_unwind noalias nocapture noundef writable sret([48 x i8]) align 8 dereferenceable(48) %0, ptr noalias noundef readonly align 8 dereferenceable(32) %1, ptr noalias noundef readonly align 8 dereferenceable(16) %2) unnamed_addr #0 !dbg !44 {
  %4 = alloca [8 x i8], align 8
  %5 = alloca [8 x i8], align 8
  store ptr %1, ptr %5, align 8
    #dbg_declare(ptr %5, !205, !DIExpression(), !207)
  store ptr %2, ptr %4, align 8
    #dbg_declare(ptr %4, !206, !DIExpression(), !208)
  store ptr %1, ptr %0, align 8, !dbg !209
  %6 = getelementptr inbounds i8, ptr %0, i64 8, !dbg !209
  store i64 2, ptr %6, align 8, !dbg !209
  %7 = load ptr, ptr @0, align 8, !dbg !209, !align !210, !noundef !23
  %8 = load i64, ptr getelementptr inbounds (i8, ptr @0, i64 8), align 8, !dbg !209
  %9 = getelementptr inbounds i8, ptr %0, i64 32, !dbg !209
  store ptr %7, ptr %9, align 8, !dbg !209
  %10 = getelementptr inbounds i8, ptr %9, i64 8, !dbg !209
  store i64 %8, ptr %10, align 8, !dbg !209
  %11 = getelementptr inbounds i8, ptr %0, i64 16, !dbg !209
  store ptr %2, ptr %11, align 8, !dbg !209
  %12 = getelementptr inbounds i8, ptr %11, i64 8, !dbg !209
  store i64 1, ptr %12, align 8, !dbg !209
  ret void, !dbg !211
}

; Function Attrs: inlinehint nounwind optsize shadowcallstack uwtable
define internal void @_RINvMs0_NtCsaflpkWScbL9_4core3fmtNtB6_9Arguments9new_constKj1_ECs7vJBeK7brjY_8lto_hang(ptr dead_on_unwind noalias nocapture noundef writable sret([48 x i8]) align 8 dereferenceable(48) %0, ptr noalias noundef readonly align 8 dereferenceable(16) %1) unnamed_addr #0 !dbg !212 {
  %3 = alloca [8 x i8], align 8
  store ptr %1, ptr %3, align 8
    #dbg_declare(ptr %3, !219, !DIExpression(), !220)
  store ptr %1, ptr %0, align 8, !dbg !221
  %4 = getelementptr inbounds i8, ptr %0, i64 8, !dbg !221
  store i64 1, ptr %4, align 8, !dbg !221
  %5 = load ptr, ptr @0, align 8, !dbg !221, !align !210, !noundef !23
  %6 = load i64, ptr getelementptr inbounds (i8, ptr @0, i64 8), align 8, !dbg !221
  %7 = getelementptr inbounds i8, ptr %0, i64 32, !dbg !221
  store ptr %5, ptr %7, align 8, !dbg !221
  %8 = getelementptr inbounds i8, ptr %7, i64 8, !dbg !221
  store i64 %6, ptr %8, align 8, !dbg !221
  %9 = getelementptr inbounds i8, ptr %0, i64 16, !dbg !221
  store ptr inttoptr (i64 8 to ptr), ptr %9, align 8, !dbg !221
  %10 = getelementptr inbounds i8, ptr %9, i64 8, !dbg !221
  store i64 0, ptr %10, align 8, !dbg !221
  ret void, !dbg !222
}

; Function Attrs: alwaysinline nounwind optsize shadowcallstack uwtable
define internal void @_RINvMs_NtNtCsaflpkWScbL9_4core3fmt2rtNtB5_8Argument9new_debugaECs7vJBeK7brjY_8lto_hang(ptr dead_on_unwind noalias nocapture noundef writable sret([16 x i8]) align 8 dereferenceable(16) %0, ptr noalias noundef readonly align 1 dereferenceable(1) %1) unnamed_addr #1 !dbg !223 {
  %3 = alloca [8 x i8], align 8
  %4 = alloca [8 x i8], align 8
  %5 = alloca [8 x i8], align 8
  %6 = alloca [16 x i8], align 8
  store ptr %1, ptr %5, align 8
    #dbg_declare(ptr %5, !233, !DIExpression(), !234)
    #dbg_declare(ptr %5, !235, !DIExpression(), !245)
    #dbg_declare(ptr %5, !247, !DIExpression(), !258)
    #dbg_declare(ptr %5, !260, !DIExpression(), !264)
  store ptr @"_ZN4core3fmt3num49_$LT$impl$u20$core..fmt..Debug$u20$for$u20$i8$GT$3fmt17ha6c07ac2a98e4d11E", ptr %4, align 8, !dbg !266
    #dbg_declare(ptr %4, !244, !DIExpression(), !267)
  call void @llvm.lifetime.start.p0(i64 16, ptr %6), !dbg !268
  store ptr %1, ptr %3, align 8, !dbg !269
    #dbg_declare(ptr %3, !270, !DIExpression(), !278)
    #dbg_declare(ptr %3, !280, !DIExpression(), !287)
  store ptr %1, ptr %6, align 8, !dbg !268
  %7 = getelementptr inbounds i8, ptr %6, i64 8, !dbg !268
  store ptr @"_ZN4core3fmt3num49_$LT$impl$u20$core..fmt..Debug$u20$for$u20$i8$GT$3fmt17ha6c07ac2a98e4d11E", ptr %7, align 8, !dbg !268
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %0, ptr align 8 %6, i64 16, i1 false), !dbg !289
  call void @llvm.lifetime.end.p0(i64 16, ptr %6), !dbg !290
  ret void, !dbg !291
}

; Function Attrs: inlinehint nounwind optsize shadowcallstack uwtable
define internal void @_RINvNtCsaflpkWScbL9_4core3ptr13drop_in_placeNCINvNtCscguycxaEVVT_3std2rt10lang_startuE0ECs7vJBeK7brjY_8lto_hang(ptr noalias noundef align 8 dereferenceable(8) %0) unnamed_addr #0 !dbg !292 {
  %2 = alloca [8 x i8], align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !298, !DIExpression(), !301)
  ret void, !dbg !301
}

; Function Attrs: nounwind optsize shadowcallstack uwtable
define hidden noundef i64 @_RINvNtCscguycxaEVVT_3std2rt10lang_startuECs7vJBeK7brjY_8lto_hang(ptr noundef nonnull %0, i64 noundef %1, ptr noundef %2, i8 noundef %3) unnamed_addr #2 !dbg !302 {
  %5 = alloca [8 x i8], align 8
  %6 = alloca [1 x i8], align 1
  %7 = alloca [8 x i8], align 8
  %8 = alloca [8 x i8], align 8
  %9 = alloca [8 x i8], align 8
  %10 = alloca [8 x i8], align 8
  %11 = alloca [8 x i8], align 8
  store ptr %0, ptr %9, align 8
    #dbg_declare(ptr %9, !310, !DIExpression(), !316)
  store i64 %1, ptr %8, align 8
    #dbg_declare(ptr %8, !311, !DIExpression(), !317)
  store ptr %2, ptr %7, align 8
    #dbg_declare(ptr %7, !312, !DIExpression(), !318)
  store i8 %3, ptr %6, align 1
    #dbg_declare(ptr %6, !313, !DIExpression(), !319)
  call void @llvm.lifetime.start.p0(i64 8, ptr %11), !dbg !320
  call void @llvm.lifetime.start.p0(i64 8, ptr %10), !dbg !321
  store ptr %0, ptr %10, align 8, !dbg !321
  %12 = call noundef i64 @_ZN3std2rt19lang_start_internal17h36683c32e12cf665E(ptr noundef nonnull align 1 %10, ptr noalias noundef readonly align 8 dereferenceable(48) @1, i64 noundef %1, ptr noundef %2, i8 noundef %3) #13, !dbg !320
  store i64 %12, ptr %11, align 8, !dbg !320
  %13 = load i64, ptr %11, align 8, !dbg !322, !noundef !23
  store i64 %13, ptr %5, align 8, !dbg !322
    #dbg_declare(ptr %5, !314, !DIExpression(), !323)
  call void @llvm.lifetime.end.p0(i64 8, ptr %10), !dbg !324
  call void @llvm.lifetime.end.p0(i64 8, ptr %11), !dbg !324
  ret i64 %13, !dbg !325
}

; Function Attrs: noinline nounwind optsize shadowcallstack uwtable
define internal void @_RINvNtNtCscguycxaEVVT_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs7vJBeK7brjY_8lto_hang(ptr noundef nonnull %0) unnamed_addr #3 !dbg !326 {
  %2 = alloca [0 x i8], align 1
  %3 = alloca [8 x i8], align 8
  %4 = alloca [0 x i8], align 1
    #dbg_declare(ptr %4, !334, !DIExpression(), !338)
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !333, !DIExpression(), !339)
    #dbg_declare(ptr %2, !340, !DIExpression(), !347)
  call void @_RNvYFEuINtNtNtCsaflpkWScbL9_4core3ops8function6FnOnceuE9call_onceCs7vJBeK7brjY_8lto_hang(ptr noundef nonnull %0) #13, !dbg !349
  call void asm sideeffect "", "~{memory}"(), !dbg !350, !srcloc !351
  ret void, !dbg !352
}

; Function Attrs: inlinehint nounwind optsize shadowcallstack uwtable
define internal noundef i32 @_RNCINvNtCscguycxaEVVT_3std2rt10lang_startuE0Cs7vJBeK7brjY_8lto_hang(ptr noalias noundef readonly align 8 dereferenceable(8) %0) unnamed_addr #0 !dbg !353 {
  %2 = alloca [8 x i8], align 8
  %3 = alloca [8 x i8], align 8
  %4 = alloca [1 x i8], align 1
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !359, !DIExpression(DW_OP_deref), !360)
    #dbg_declare(ptr %4, !361, !DIExpression(), !379)
  call void @llvm.lifetime.start.p0(i64 1, ptr %4), !dbg !381
  %5 = load ptr, ptr %0, align 8, !dbg !382, !nonnull !23, !noundef !23
  call void @_RINvNtNtCscguycxaEVVT_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs7vJBeK7brjY_8lto_hang(ptr noundef nonnull %5) #13, !dbg !381
  %6 = call noundef i8 @"_ZN54_$LT$$LP$$RP$$u20$as$u20$std..process..Termination$GT$6report17h21d63d7df63b3af2E"() #13, !dbg !381
  store i8 %6, ptr %4, align 1, !dbg !381
  store ptr %4, ptr %2, align 8, !dbg !383
    #dbg_declare(ptr %2, !384, !DIExpression(), !392)
  %7 = load i8, ptr %4, align 1, !dbg !394, !noundef !23
  %8 = zext i8 %7 to i32, !dbg !394
  call void @llvm.lifetime.end.p0(i64 1, ptr %4), !dbg !395
  ret i32 %8, !dbg !396
}

; Function Attrs: inlinehint nounwind optsize shadowcallstack uwtable
define internal noundef i32 @_RNSNvYNCINvNtCscguycxaEVVT_3std2rt10lang_startuE0INtNtNtCsaflpkWScbL9_4core3ops8function6FnOnceuE9call_once6vtableCs7vJBeK7brjY_8lto_hang(ptr noundef %0) unnamed_addr #0 !dbg !397 {
  %2 = alloca [8 x i8], align 8
  %3 = alloca [0 x i8], align 1
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !405, !DIExpression(), !410)
    #dbg_declare(ptr %3, !406, !DIExpression(), !410)
  %4 = load ptr, ptr %0, align 8, !dbg !410, !nonnull !23, !noundef !23
  %5 = call noundef i32 @_RNvYNCINvNtCscguycxaEVVT_3std2rt10lang_startuE0INtNtNtCsaflpkWScbL9_4core3ops8function6FnOnceuE9call_onceCs7vJBeK7brjY_8lto_hang(ptr noundef nonnull %4) #13, !dbg !410
  ret i32 %5, !dbg !410
}

; Function Attrs: inlinehint nounwind optsize shadowcallstack uwtable
define internal { i1, i8 } @_RNvXs3_NtNtCsaflpkWScbL9_4core4iter5rangeINtNtNtB9_3ops5range5RangeaENtB5_17RangeIteratorImpl9spec_nextCs7vJBeK7brjY_8lto_hang(ptr noalias noundef align 1 dereferenceable(2) %0) unnamed_addr #0 !dbg !411 {
  %2 = alloca [1 x i8], align 1
  %3 = alloca [8 x i8], align 8
  %4 = alloca [2 x i8], align 1
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !438, !DIExpression(), !441)
  %5 = getelementptr inbounds i8, ptr %0, i64 1, !dbg !442
  %6 = call noundef zeroext i1 @"_ZN4core3cmp5impls54_$LT$impl$u20$core..cmp..PartialOrd$u20$for$u20$i8$GT$2lt17h5eda5ff3f1ac5b3fE"(ptr noalias noundef readonly align 1 dereferenceable(1) %0, ptr noalias noundef readonly align 1 dereferenceable(1) %5) #13, !dbg !443
  br i1 %6, label %8, label %7, !dbg !443

7:                                                ; preds = %1
  store i8 0, ptr %4, align 1, !dbg !444
  br label %12, !dbg !445

8:                                                ; preds = %1
  %9 = load i8, ptr %0, align 1, !dbg !446, !noundef !23
  store i8 %9, ptr %2, align 1, !dbg !446
    #dbg_declare(ptr %2, !439, !DIExpression(), !447)
  %10 = call noundef i8 @"_ZN46_$LT$i8$u20$as$u20$core..iter..range..Step$GT$17forward_unchecked17h02c715c02f324e03E"(i8 noundef %9, i64 noundef 1) #13, !dbg !448
  store i8 %10, ptr %0, align 1, !dbg !449
  %11 = getelementptr inbounds i8, ptr %4, i64 1, !dbg !450
  store i8 %9, ptr %11, align 1, !dbg !450
  store i8 1, ptr %4, align 1, !dbg !450
  br label %12, !dbg !445

12:                                               ; preds = %8, %7
  %13 = load i8, ptr %4, align 1, !dbg !451, !range !452, !noundef !23
  %14 = trunc i8 %13 to i1, !dbg !451
  %15 = getelementptr inbounds i8, ptr %4, i64 1, !dbg !451
  %16 = load i8, ptr %15, align 1, !dbg !451
  %17 = insertvalue { i1, i8 } poison, i1 %14, 0, !dbg !451
  %18 = insertvalue { i1, i8 } %17, i8 %16, 1, !dbg !451
  ret { i1, i8 } %18, !dbg !451
}

; Function Attrs: inlinehint nounwind optsize shadowcallstack uwtable
define internal { i1, i8 } @_RNvXs4_NtNtCsaflpkWScbL9_4core4iter5rangeINtNtNtB9_3ops5range5RangeaENtNtNtB7_6traits8iterator8Iterator4nextCs7vJBeK7brjY_8lto_hang(ptr noalias noundef align 1 dereferenceable(2) %0) unnamed_addr #0 !dbg !453 {
  %2 = alloca [8 x i8], align 8
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !456, !DIExpression(), !459)
  %3 = call { i1, i8 } @_RNvXs3_NtNtCsaflpkWScbL9_4core4iter5rangeINtNtNtB9_3ops5range5RangeaENtB5_17RangeIteratorImpl9spec_nextCs7vJBeK7brjY_8lto_hang(ptr noalias noundef align 1 dereferenceable(2) %0) #13, !dbg !460
  %4 = extractvalue { i1, i8 } %3, 0, !dbg !460
  %5 = extractvalue { i1, i8 } %3, 1, !dbg !460
  %6 = insertvalue { i1, i8 } poison, i1 %4, 0, !dbg !461
  %7 = insertvalue { i1, i8 } %6, i8 %5, 1, !dbg !461
  ret { i1, i8 } %7, !dbg !461
}

; Function Attrs: inlinehint nounwind optsize shadowcallstack uwtable
define internal { i8, i8 } @_RNvXs_NtNtNtCsaflpkWScbL9_4core4iter6traits7collectINtNtNtBa_3ops5range5RangeaENtB4_12IntoIterator9into_iterCs7vJBeK7brjY_8lto_hang(i8 noundef %0, i8 noundef %1) unnamed_addr #0 !dbg !462 {
  %3 = alloca [2 x i8], align 1
  store i8 %0, ptr %3, align 1
  %4 = getelementptr inbounds i8, ptr %3, i64 1
  store i8 %1, ptr %4, align 1
    #dbg_declare(ptr %3, !470, !DIExpression(), !473)
  %5 = insertvalue { i8, i8 } poison, i8 %0, 0, !dbg !474
  %6 = insertvalue { i8, i8 } %5, i8 %1, 1, !dbg !474
  ret { i8, i8 } %6, !dbg !474
}

; Function Attrs: inlinehint nounwind optsize shadowcallstack uwtable
define internal void @_RNvYFEuINtNtNtCsaflpkWScbL9_4core3ops8function6FnOnceuE9call_onceCs7vJBeK7brjY_8lto_hang(ptr noundef nonnull %0) unnamed_addr #0 !dbg !475 {
  %2 = alloca [8 x i8], align 8
  %3 = alloca [0 x i8], align 1
  store ptr %0, ptr %2, align 8
    #dbg_declare(ptr %2, !477, !DIExpression(), !481)
    #dbg_declare(ptr %3, !478, !DIExpression(), !481)
  call void %0() #13, !dbg !481
  ret void, !dbg !481
}

; Function Attrs: inlinehint nounwind optsize shadowcallstack uwtable
define internal noundef i32 @_RNvYNCINvNtCscguycxaEVVT_3std2rt10lang_startuE0INtNtNtCsaflpkWScbL9_4core3ops8function6FnOnceuE9call_onceCs7vJBeK7brjY_8lto_hang(ptr noundef nonnull %0) unnamed_addr #0 !dbg !482 {
  %2 = alloca [0 x i8], align 1
  %3 = alloca [8 x i8], align 8
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !486, !DIExpression(), !488)
    #dbg_declare(ptr %2, !487, !DIExpression(), !488)
  %4 = call noundef i32 @_RNCINvNtCscguycxaEVVT_3std2rt10lang_startuE0Cs7vJBeK7brjY_8lto_hang(ptr noalias noundef readonly align 8 dereferenceable(8) %3) #13, !dbg !488
  ret i32 %4, !dbg !488
}

; Function Attrs: inlinehint nounwind optsize shadowcallstack uwtable
define internal noundef i8 @"_ZN46_$LT$i8$u20$as$u20$core..iter..range..Step$GT$17forward_unchecked17h02c715c02f324e03E"(i8 noundef %0, i64 noundef %1) unnamed_addr #0 !dbg !489 {
  %3 = alloca [1 x i8], align 1
  %4 = alloca [1 x i8], align 1
  %5 = alloca [1 x i8], align 1
  %6 = alloca [1 x i8], align 1
  %7 = alloca [1 x i8], align 1
  %8 = alloca [1 x i8], align 1
  %9 = alloca [1 x i8], align 1
  %10 = alloca [8 x i8], align 8
  %11 = alloca [1 x i8], align 1
  %12 = alloca [2 x i8], align 1
  store i8 %0, ptr %11, align 1
    #dbg_declare(ptr %11, !494, !DIExpression(), !496)
    #dbg_declare(ptr %11, !497, !DIExpression(), !510)
    #dbg_declare(ptr %11, !512, !DIExpression(), !527)
    #dbg_declare(ptr %11, !529, !DIExpression(), !538)
  store i64 %1, ptr %10, align 8
    #dbg_declare(ptr %10, !495, !DIExpression(), !540)
    #dbg_declare(ptr %12, !541, !DIExpression(), !558)
  call void @llvm.lifetime.start.p0(i64 2, ptr %12), !dbg !560
  %13 = trunc i64 %1 to i8, !dbg !561
  store i8 %13, ptr %9, align 1, !dbg !561
    #dbg_declare(ptr %9, !505, !DIExpression(), !562)
    #dbg_declare(ptr %9, !521, !DIExpression(), !563)
  store i8 %13, ptr %8, align 1, !dbg !564
    #dbg_declare(ptr %8, !522, !DIExpression(), !565)
    #dbg_declare(ptr %8, !534, !DIExpression(), !566)
  %14 = call { i8, i1 } @llvm.sadd.with.overflow.i8(i8 %0, i8 %13), !dbg !567
  %15 = extractvalue { i8, i1 } %14, 0, !dbg !567
  %16 = extractvalue { i8, i1 } %14, 1, !dbg !567
  store i8 %15, ptr %7, align 1, !dbg !568
    #dbg_declare(ptr %7, !506, !DIExpression(), !569)
    #dbg_declare(ptr %7, !524, !DIExpression(), !570)
    #dbg_declare(ptr %7, !535, !DIExpression(), !571)
  %17 = zext i1 %16 to i8, !dbg !572
  store i8 %17, ptr %6, align 1, !dbg !572
    #dbg_declare(ptr %6, !526, !DIExpression(), !573)
    #dbg_declare(ptr %6, !537, !DIExpression(), !574)
  %18 = icmp slt i8 %13, 0, !dbg !575
  %19 = xor i1 %16, %18, !dbg !576
  %20 = zext i1 %19 to i8, !dbg !576
  store i8 %20, ptr %5, align 1, !dbg !576
    #dbg_declare(ptr %5, !508, !DIExpression(), !577)
  call void @llvm.lifetime.start.p0(i64 1, ptr %4), !dbg !578
  %21 = call i1 @llvm.expect.i1(i1 %19, i1 false), !dbg !578
  %22 = zext i1 %21 to i8, !dbg !578
  store i8 %22, ptr %4, align 1, !dbg !578
  %23 = load i8, ptr %4, align 1, !dbg !578, !range !452, !noundef !23
  %24 = trunc i8 %23 to i1, !dbg !578
  call void @llvm.lifetime.end.p0(i64 1, ptr %4), !dbg !578
  br i1 %24, label %29, label %25, !dbg !578

25:                                               ; preds = %2
  %26 = getelementptr inbounds i8, ptr %12, i64 1, !dbg !579
  store i8 %15, ptr %26, align 1, !dbg !579
  store i8 1, ptr %12, align 1, !dbg !579
  %27 = getelementptr inbounds i8, ptr %12, i64 1, !dbg !580
  %28 = load i8, ptr %27, align 1, !dbg !580, !noundef !23
  store i8 %28, ptr %3, align 1, !dbg !580
    #dbg_declare(ptr %3, !556, !DIExpression(), !581)
  call void @llvm.lifetime.end.p0(i64 2, ptr %12), !dbg !582
  ret i8 %28, !dbg !583

29:                                               ; preds = %2
  %30 = load i8, ptr @2, align 1, !dbg !584, !range !452, !noundef !23
  %31 = trunc i8 %30 to i1, !dbg !584
  %32 = load i8, ptr getelementptr inbounds (i8, ptr @2, i64 1), align 1, !dbg !584
  %33 = zext i1 %31 to i8, !dbg !584
  store i8 %33, ptr %12, align 1, !dbg !584
  %34 = getelementptr inbounds i8, ptr %12, i64 1, !dbg !584
  store i8 %32, ptr %34, align 1, !dbg !584
  call void @llvm.assume(i1 false), !dbg !585
  call void @_ZN4core4hint21unreachable_unchecked18precondition_check17h0d35aaba5534f423E() #13, !dbg !590
  unreachable, !dbg !591
}

; Function Attrs: nounwind optsize shadowcallstack uwtable
define internal noundef zeroext i1 @_ZN4core10intrinsics8unlikely17hde30836616cdb810E(i1 noundef zeroext %0) unnamed_addr #2 !dbg !594 {
  %2 = alloca [1 x i8], align 1
  %3 = zext i1 %0 to i8
  store i8 %3, ptr %2, align 1
    #dbg_declare(ptr %2, !600, !DIExpression(), !601)
  ret i1 %0, !dbg !602
}

; Function Attrs: alwaysinline nounwind optsize shadowcallstack uwtable
define internal noundef zeroext i1 @"_ZN4core3cmp5impls54_$LT$impl$u20$core..cmp..PartialOrd$u20$for$u20$i8$GT$2lt17h5eda5ff3f1ac5b3fE"(ptr noalias noundef readonly align 1 dereferenceable(1) %0, ptr noalias noundef readonly align 1 dereferenceable(1) %1) unnamed_addr #1 !dbg !603 {
  %3 = alloca [8 x i8], align 8
  %4 = alloca [8 x i8], align 8
  store ptr %0, ptr %4, align 8
    #dbg_declare(ptr %4, !611, !DIExpression(), !613)
  store ptr %1, ptr %3, align 8
    #dbg_declare(ptr %3, !612, !DIExpression(), !614)
  %5 = load i8, ptr %0, align 1, !dbg !615, !noundef !23
  %6 = load i8, ptr %1, align 1, !dbg !616, !noundef !23
  %7 = icmp slt i8 %5, %6, !dbg !615
  ret i1 %7, !dbg !617
}

; Function Attrs: inlinehint nounwind optsize shadowcallstack uwtable
define internal noundef zeroext i1 @"_ZN4core3fmt3num49_$LT$impl$u20$core..fmt..Debug$u20$for$u20$i8$GT$3fmt17ha6c07ac2a98e4d11E"(ptr noalias noundef readonly align 1 dereferenceable(1) %0, ptr noalias noundef align 8 dereferenceable(64) %1) unnamed_addr #0 !dbg !618 {
  %3 = alloca [8 x i8], align 8
  %4 = alloca [8 x i8], align 8
  %5 = alloca [1 x i8], align 1
  store ptr %0, ptr %4, align 8
    #dbg_declare(ptr %4, !623, !DIExpression(), !625)
  store ptr %1, ptr %3, align 8
    #dbg_declare(ptr %3, !624, !DIExpression(), !626)
    #dbg_declare(ptr %3, !627, !DIExpression(), !634)
    #dbg_declare(ptr %3, !636, !DIExpression(), !640)
  %6 = getelementptr inbounds i8, ptr %1, i64 52, !dbg !642
  %7 = load i32, ptr %6, align 4, !dbg !642, !noundef !23
  %8 = and i32 %7, 16, !dbg !642
  %9 = icmp eq i32 %8, 0, !dbg !643
  br i1 %9, label %10, label %15, !dbg !643

10:                                               ; preds = %2
  %11 = getelementptr inbounds i8, ptr %1, i64 52, !dbg !644
  %12 = load i32, ptr %11, align 4, !dbg !644, !noundef !23
  %13 = and i32 %12, 32, !dbg !644
  %14 = icmp eq i32 %13, 0, !dbg !645
  br i1 %14, label %18, label %21, !dbg !645

15:                                               ; preds = %2
  %16 = call noundef zeroext i1 @"_ZN4core3fmt3num52_$LT$impl$u20$core..fmt..LowerHex$u20$for$u20$i8$GT$3fmt17h1e6f97809f7d5a76E"(ptr noalias noundef readonly align 1 dereferenceable(1) %0, ptr noalias noundef align 8 dereferenceable(64) %1) #13, !dbg !646
  %17 = zext i1 %16 to i8, !dbg !646
  store i8 %17, ptr %5, align 1, !dbg !646
  br label %25, !dbg !646

18:                                               ; preds = %10
  %19 = call noundef zeroext i1 @"_ZN4core3fmt3num3imp51_$LT$impl$u20$core..fmt..Display$u20$for$u20$i8$GT$3fmt17h764f459bb4dd869cE"(ptr noalias noundef readonly align 1 dereferenceable(1) %0, ptr noalias noundef align 8 dereferenceable(64) %1) #13, !dbg !647
  %20 = zext i1 %19 to i8, !dbg !647
  store i8 %20, ptr %5, align 1, !dbg !647
  br label %24, !dbg !647

21:                                               ; preds = %10
  %22 = call noundef zeroext i1 @"_ZN4core3fmt3num52_$LT$impl$u20$core..fmt..UpperHex$u20$for$u20$i8$GT$3fmt17h6a5ee7b90111e665E"(ptr noalias noundef readonly align 1 dereferenceable(1) %0, ptr noalias noundef align 8 dereferenceable(64) %1) #13, !dbg !648
  %23 = zext i1 %22 to i8, !dbg !648
  store i8 %23, ptr %5, align 1, !dbg !648
  br label %24, !dbg !648

24:                                               ; preds = %21, %18
  br label %25, !dbg !649

25:                                               ; preds = %15, %24
  %26 = load i8, ptr %5, align 1, !dbg !650, !range !452, !noundef !23
  %27 = trunc i8 %26 to i1, !dbg !650
  ret i1 %27, !dbg !650
}

; Function Attrs: inlinehint nounwind optsize shadowcallstack uwtable
define internal void @_ZN4core4hint21unreachable_unchecked18precondition_check17h0d35aaba5534f423E() unnamed_addr #0 !dbg !651 {
  call void @_ZN4core9panicking14panic_nounwind17hc6be63233382d1c0E(ptr noalias noundef nonnull readonly align 1 @3, i64 noundef 82) #14, !dbg !653
  unreachable, !dbg !653
}

; Function Attrs: inlinehint nounwind optsize shadowcallstack uwtable
define internal noundef i8 @"_ZN54_$LT$$LP$$RP$$u20$as$u20$std..process..Termination$GT$6report17h21d63d7df63b3af2E"() unnamed_addr #0 !dbg !654 {
  %1 = alloca [0 x i8], align 1
  %2 = alloca [0 x i8], align 1
    #dbg_declare(ptr %2, !660, !DIExpression(), !661)
    #dbg_declare(ptr %1, !659, !DIExpression(), !661)
  ret i8 0, !dbg !662
}

; Function Attrs: nounwind optsize shadowcallstack uwtable
define internal void @_RNvMCs7vJBeK7brjY_8lto_hangNtB2_4Test3new(ptr dead_on_unwind noalias nocapture noundef writable sret([24 x i8]) align 8 dereferenceable(24) %0) unnamed_addr #2 !dbg !663 {
  %2 = alloca [2 x i8], align 1
  call void @llvm.lifetime.start.p0(i64 2, ptr %2), !dbg !674
  call void @llvm.memset.p0.i64(ptr align 1 %2, i8 -128, i64 2, i1 false), !dbg !674
  %3 = getelementptr inbounds i8, ptr %0, i64 16, !dbg !675
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 1 %2, i64 2, i1 false), !dbg !675
  store i64 0, ptr %0, align 8, !dbg !675
  %4 = getelementptr inbounds i8, ptr %0, i64 8, !dbg !675
  store i64 0, ptr %4, align 8, !dbg !675
  call void @llvm.lifetime.end.p0(i64 2, ptr %2), !dbg !676
  ret void, !dbg !677
}

; Function Attrs: nounwind optsize shadowcallstack uwtable
define internal void @_RNvMCs7vJBeK7brjY_8lto_hangNtB2_4Test3add(ptr noalias noundef align 8 dereferenceable(24) %0, i8 noundef %1) unnamed_addr #2 !dbg !678 {
  %3 = alloca [8 x i8], align 8
  %4 = alloca [48 x i8], align 8
  %5 = alloca [16 x i8], align 8
  %6 = alloca [16 x i8], align 8
  %7 = alloca [48 x i8], align 8
  %8 = alloca [1 x i8], align 1
  store i8 %1, ptr %8, align 1
  store ptr %0, ptr %3, align 8
    #dbg_declare(ptr %3, !684, !DIExpression(), !686)
    #dbg_declare(ptr %8, !685, !DIExpression(), !687)
  call void @llvm.lifetime.start.p0(i64 48, ptr %7), !dbg !688
  call void @llvm.lifetime.start.p0(i64 16, ptr %6), !dbg !688
  call void @llvm.lifetime.start.p0(i64 16, ptr %5), !dbg !688
  call void @_RINvMs_NtNtCsaflpkWScbL9_4core3fmt2rtNtB5_8Argument9new_debugaECs7vJBeK7brjY_8lto_hang(ptr noalias nocapture noundef sret([16 x i8]) align 8 dereferenceable(16) %5, ptr noalias noundef readonly align 1 dereferenceable(1) %8) #13, !dbg !688
  %9 = getelementptr inbounds [1 x { { ptr, [1 x i64] } }], ptr %6, i64 0, i64 0, !dbg !688
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %9, ptr align 8 %5, i64 16, i1 false), !dbg !688
  call void @llvm.lifetime.end.p0(i64 16, ptr %5), !dbg !688
  call void @_RINvMs0_NtCsaflpkWScbL9_4core3fmtNtB6_9Arguments6new_v1Kj2_Kj1_ECs7vJBeK7brjY_8lto_hang(ptr noalias nocapture noundef sret([48 x i8]) align 8 dereferenceable(48) %7, ptr noalias noundef readonly align 8 dereferenceable(32) @6, ptr noalias noundef readonly align 8 dereferenceable(16) %6) #13, !dbg !688
  call void @_ZN3std2io5stdio6_print17h32cb0951b39bbc8aE(ptr noalias nocapture noundef align 8 dereferenceable(48) %7) #13, !dbg !688
  call void @llvm.lifetime.end.p0(i64 48, ptr %7), !dbg !688
  call void @llvm.lifetime.end.p0(i64 16, ptr %6), !dbg !688
  %10 = load i64, ptr %0, align 8, !dbg !689, !noundef !23
  %11 = icmp ult i64 %10, 2, !dbg !689
  br i1 %11, label %13, label %12, !dbg !689

12:                                               ; preds = %2
  br label %16, !dbg !690

13:                                               ; preds = %2
  %14 = load i64, ptr %0, align 8, !dbg !691, !noundef !23
  %15 = add i64 %14, 1, !dbg !691
  store i64 %15, ptr %0, align 8, !dbg !691
  br label %16, !dbg !690

16:                                               ; preds = %13, %12
  %17 = load i8, ptr %8, align 1, !dbg !692, !noundef !23
  %18 = icmp sgt i8 %17, 10, !dbg !692
  br i1 %18, label %23, label %19, !dbg !692

19:                                               ; preds = %16
  %20 = getelementptr inbounds i8, ptr %0, i64 8, !dbg !693
  %21 = load i64, ptr %20, align 8, !dbg !693, !noundef !23
  %22 = icmp ult i64 %21, 2, !dbg !694
  br i1 %22, label %24, label %33, !dbg !694

23:                                               ; preds = %16
  call void @llvm.lifetime.start.p0(i64 48, ptr %4), !dbg !695
  call void @_RINvMs0_NtCsaflpkWScbL9_4core3fmtNtB6_9Arguments9new_constKj1_ECs7vJBeK7brjY_8lto_hang(ptr noalias nocapture noundef sret([48 x i8]) align 8 dereferenceable(48) %4, ptr noalias noundef readonly align 8 dereferenceable(16) @10) #13, !dbg !695
  call void @_ZN4core9panicking9panic_fmt17hf8cd88f163379b2bE(ptr noalias nocapture noundef readonly align 8 dereferenceable(48) %4, ptr noalias noundef readonly align 8 dereferenceable(24) @11) #14, !dbg !695
  unreachable, !dbg !695

24:                                               ; preds = %19
  %25 = getelementptr inbounds i8, ptr %0, i64 16, !dbg !694
  %26 = getelementptr inbounds [2 x i8], ptr %25, i64 0, i64 %21, !dbg !694
  %27 = load i8, ptr %8, align 1, !dbg !694, !noundef !23
  store i8 %27, ptr %26, align 1, !dbg !694
  %28 = getelementptr inbounds i8, ptr %0, i64 8, !dbg !696
  %29 = load i64, ptr %28, align 8, !dbg !696, !noundef !23
  %30 = add i64 %29, 1, !dbg !697
  %31 = getelementptr inbounds i8, ptr %0, i64 8, !dbg !698
  %32 = urem i64 %30, 2, !dbg !698
  store i64 %32, ptr %31, align 8, !dbg !698
  ret void, !dbg !699

33:                                               ; preds = %19
  call void @_ZN4core9panicking18panic_bounds_check17h88ec794af8babdb9E(i64 noundef %21, i64 noundef 2, ptr noalias noundef readonly align 8 dereferenceable(24) @8) #14, !dbg !694
  unreachable, !dbg !694
}

; Function Attrs: noinline nounwind optsize shadowcallstack uwtable
define internal void @_RNvCs7vJBeK7brjY_8lto_hang11do_the_test() unnamed_addr #3 !dbg !700 {
  %1 = alloca [1 x i8], align 1
  %2 = alloca [2 x i8], align 1
  %3 = alloca [2 x i8], align 1
  %4 = alloca [24 x i8], align 8
    #dbg_declare(ptr %4, !702, !DIExpression(), !708)
    #dbg_declare(ptr %3, !704, !DIExpression(), !709)
  call void @llvm.lifetime.start.p0(i64 24, ptr %4), !dbg !710
  call void @_RNvMCs7vJBeK7brjY_8lto_hangNtB2_4Test3new(ptr noalias nocapture noundef sret([24 x i8]) align 8 dereferenceable(24) %4) #13, !dbg !711
  %5 = call { i8, i8 } @_RNvXs_NtNtNtCsaflpkWScbL9_4core4iter6traits7collectINtNtNtBa_3ops5range5RangeaENtB4_12IntoIterator9into_iterCs7vJBeK7brjY_8lto_hang(i8 noundef -4, i8 noundef 0) #13, !dbg !712
  %6 = extractvalue { i8, i8 } %5, 0, !dbg !712
  %7 = extractvalue { i8, i8 } %5, 1, !dbg !712
  call void @llvm.lifetime.start.p0(i64 2, ptr %3), !dbg !712
  store i8 %6, ptr %3, align 1, !dbg !712
  %8 = getelementptr inbounds i8, ptr %3, i64 1, !dbg !712
  store i8 %7, ptr %8, align 1, !dbg !712
  br label %9, !dbg !713

9:                                                ; preds = %20, %0
  call void @llvm.lifetime.start.p0(i64 2, ptr %2), !dbg !709
  %10 = call { i1, i8 } @_RNvXs4_NtNtCsaflpkWScbL9_4core4iter5rangeINtNtNtB9_3ops5range5RangeaENtNtNtB7_6traits8iterator8Iterator4nextCs7vJBeK7brjY_8lto_hang(ptr noalias noundef align 1 dereferenceable(2) %3) #13, !dbg !709
  %11 = extractvalue { i1, i8 } %10, 0, !dbg !709
  %12 = extractvalue { i1, i8 } %10, 1, !dbg !709
  %13 = zext i1 %11 to i8, !dbg !709
  store i8 %13, ptr %2, align 1, !dbg !709
  %14 = getelementptr inbounds i8, ptr %2, i64 1, !dbg !709
  store i8 %12, ptr %14, align 1, !dbg !709
  %15 = load i8, ptr %2, align 1, !dbg !709, !range !452, !noundef !23
  %16 = trunc i8 %15 to i1, !dbg !709
  %17 = zext i1 %16 to i64, !dbg !709
  switch i64 %17, label %18 [
    i64 0, label %19
    i64 1, label %20
  ], !dbg !709

18:                                               ; preds = %9
  unreachable, !dbg !709

19:                                               ; preds = %9
  call void @llvm.lifetime.end.p0(i64 2, ptr %2), !dbg !714
  call void @llvm.lifetime.end.p0(i64 2, ptr %3), !dbg !715
  call void @_RNvMCs7vJBeK7brjY_8lto_hangNtB2_4Test3add(ptr noalias noundef align 8 dereferenceable(24) %4, i8 noundef 0) #13, !dbg !716
  call void @llvm.lifetime.end.p0(i64 24, ptr %4), !dbg !717
  ret void, !dbg !718

20:                                               ; preds = %9
  %21 = getelementptr inbounds i8, ptr %2, i64 1, !dbg !719
  %22 = load i8, ptr %21, align 1, !dbg !719, !noundef !23
  store i8 %22, ptr %1, align 1, !dbg !719
    #dbg_declare(ptr %1, !706, !DIExpression(), !720)
  call void @_RNvMCs7vJBeK7brjY_8lto_hangNtB2_4Test3add(ptr noalias noundef align 8 dereferenceable(24) %4, i8 noundef %22) #13, !dbg !721
  call void @llvm.lifetime.end.p0(i64 2, ptr %2), !dbg !714
  br label %9, !dbg !713
}

; Function Attrs: nounwind optsize shadowcallstack uwtable
define internal void @_RNvCs7vJBeK7brjY_8lto_hang4main() unnamed_addr #2 !dbg !722 {
  call void @_RNvCs7vJBeK7brjY_8lto_hang11do_the_test() #13, !dbg !723
  ret void, !dbg !724
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #4

; Function Attrs: nounwind optsize shadowcallstack uwtable
declare noundef i64 @_ZN3std2rt19lang_start_internal17h36683c32e12cf665E(ptr noundef nonnull align 1, ptr noalias noundef readonly align 8 dereferenceable(48), i64 noundef, ptr noundef, i8 noundef) unnamed_addr #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i8, i1 } @llvm.sadd.with.overflow.i8(i8, i8) #5

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.expect.i1(i1, i1) #6

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #7

; Function Attrs: nounwind optsize shadowcallstack uwtable
declare noundef zeroext i1 @"_ZN4core3fmt3num3imp51_$LT$impl$u20$core..fmt..Display$u20$for$u20$i8$GT$3fmt17h764f459bb4dd869cE"(ptr noalias noundef readonly align 1 dereferenceable(1), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #2

; Function Attrs: nounwind optsize shadowcallstack uwtable
declare noundef zeroext i1 @"_ZN4core3fmt3num52_$LT$impl$u20$core..fmt..UpperHex$u20$for$u20$i8$GT$3fmt17h6a5ee7b90111e665E"(ptr noalias noundef readonly align 1 dereferenceable(1), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #2

; Function Attrs: nounwind optsize shadowcallstack uwtable
declare noundef zeroext i1 @"_ZN4core3fmt3num52_$LT$impl$u20$core..fmt..LowerHex$u20$for$u20$i8$GT$3fmt17h1e6f97809f7d5a76E"(ptr noalias noundef readonly align 1 dereferenceable(1), ptr noalias noundef align 8 dereferenceable(64)) unnamed_addr #2

; Function Attrs: cold noinline noreturn nounwind optsize shadowcallstack uwtable
declare void @_ZN4core9panicking14panic_nounwind17hc6be63233382d1c0E(ptr noalias noundef nonnull readonly align 1, i64 noundef) unnamed_addr #8

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #9

; Function Attrs: nounwind optsize shadowcallstack uwtable
declare void @_ZN3std2io5stdio6_print17h32cb0951b39bbc8aE(ptr noalias nocapture noundef align 8 dereferenceable(48)) unnamed_addr #2

; Function Attrs: cold minsize noinline noreturn nounwind optsize shadowcallstack uwtable
declare void @_ZN4core9panicking18panic_bounds_check17h88ec794af8babdb9E(i64 noundef, i64 noundef, ptr noalias noundef readonly align 8 dereferenceable(24)) unnamed_addr #10

; Function Attrs: cold noinline noreturn nounwind optsize shadowcallstack uwtable
declare void @_ZN4core9panicking9panic_fmt17hf8cd88f163379b2bE(ptr noalias nocapture noundef readonly align 8 dereferenceable(48), ptr noalias noundef readonly align 8 dereferenceable(24)) unnamed_addr #8

; Function Attrs: shadowcallstack
define i32 @main(i32 %0, ptr %1) unnamed_addr #11 {
  %3 = load volatile i8, ptr @__rustc_debug_gdb_scripts_section__, align 1
  %4 = sext i32 %0 to i64
  %5 = call i64 @_RINvNtCscguycxaEVVT_3std2rt10lang_startuECs7vJBeK7brjY_8lto_hang(ptr @_RNvCs7vJBeK7brjY_8lto_hang4main, i64 %4, ptr %1, i8 0)
  %6 = trunc i64 %5 to i32
  ret i32 %6
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #12

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #12

attributes #0 = { inlinehint nounwind optsize shadowcallstack uwtable "frame-pointer"="all" "probe-stack"="inline-asm" "target-cpu"="generic" "target-features"="+v8a,+crc,+aes,+neon,+fp-armv8,+neon,+fp-armv8,+sha2" }
attributes #1 = { alwaysinline nounwind optsize shadowcallstack uwtable "frame-pointer"="all" "probe-stack"="inline-asm" "target-cpu"="generic" "target-features"="+v8a,+crc,+aes,+neon,+fp-armv8,+neon,+fp-armv8,+sha2" }
attributes #2 = { nounwind optsize shadowcallstack uwtable "frame-pointer"="all" "probe-stack"="inline-asm" "target-cpu"="generic" "target-features"="+v8a,+crc,+aes,+neon,+fp-armv8,+neon,+fp-armv8,+sha2" }
attributes #3 = { noinline nounwind optsize shadowcallstack uwtable "frame-pointer"="all" "probe-stack"="inline-asm" "target-cpu"="generic" "target-features"="+v8a,+crc,+aes,+neon,+fp-armv8,+neon,+fp-armv8,+sha2" }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #7 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #8 = { cold noinline noreturn nounwind optsize shadowcallstack uwtable "frame-pointer"="all" "probe-stack"="inline-asm" "target-cpu"="generic" "target-features"="+v8a,+crc,+aes,+neon,+fp-armv8,+neon,+fp-armv8,+sha2" }
attributes #9 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #10 = { cold minsize noinline noreturn nounwind optsize shadowcallstack uwtable "frame-pointer"="all" "probe-stack"="inline-asm" "target-cpu"="generic" "target-features"="+v8a,+crc,+aes,+neon,+fp-armv8,+neon,+fp-armv8,+sha2" }
attributes #11 = { shadowcallstack "frame-pointer"="all" "target-cpu"="generic" }
attributes #12 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #13 = { nounwind }
attributes #14 = { noreturn nounwind }

!llvm.module.flags = !{!24, !25, !26, !27, !28}
!llvm.ident = !{!29}
!llvm.dbg.cu = !{!30}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "<std::rt::lang_start::{closure_env#0}<()> as core::ops::function::Fn<()>>::{vtable}", scope: null, file: !2, type: !3, isLocal: true, isDefinition: true)
!2 = !DIFile(filename: "<unknown>", directory: "")
!3 = !DICompositeType(tag: DW_TAG_structure_type, name: "<std::rt::lang_start::{closure_env#0}<()> as core::ops::function::Fn<()>>::{vtable_type}", file: !2, size: 384, align: 64, flags: DIFlagArtificial, elements: !4, vtableHolder: !14, templateParams: !23, identifier: "a13b33fe48acf747fa2e1135361bab6e")
!4 = !{!5, !8, !10, !11, !12, !13}
!5 = !DIDerivedType(tag: DW_TAG_member, name: "drop_in_place", scope: !3, file: !2, baseType: !6, size: 64, align: 64)
!6 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*const ()", baseType: !7, size: 64, align: 64, dwarfAddressSpace: 0)
!7 = !DIBasicType(name: "()", encoding: DW_ATE_unsigned)
!8 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !3, file: !2, baseType: !9, size: 64, align: 64, offset: 64)
!9 = !DIBasicType(name: "usize", size: 64, encoding: DW_ATE_unsigned)
!10 = !DIDerivedType(tag: DW_TAG_member, name: "align", scope: !3, file: !2, baseType: !9, size: 64, align: 64, offset: 128)
!11 = !DIDerivedType(tag: DW_TAG_member, name: "__method3", scope: !3, file: !2, baseType: !6, size: 64, align: 64, offset: 192)
!12 = !DIDerivedType(tag: DW_TAG_member, name: "__method4", scope: !3, file: !2, baseType: !6, size: 64, align: 64, offset: 256)
!13 = !DIDerivedType(tag: DW_TAG_member, name: "__method5", scope: !3, file: !2, baseType: !6, size: 64, align: 64, offset: 320)
!14 = !DICompositeType(tag: DW_TAG_structure_type, name: "{closure_env#0}<()>", scope: !15, file: !2, size: 64, align: 64, elements: !18, templateParams: !23, identifier: "10f53c9d44010f49f7d35e40a1664459")
!15 = !DINamespace(name: "lang_start", scope: !16)
!16 = !DINamespace(name: "rt", scope: !17)
!17 = !DINamespace(name: "std", scope: null)
!18 = !{!19}
!19 = !DIDerivedType(tag: DW_TAG_member, name: "main", scope: !14, file: !2, baseType: !20, size: 64, align: 64)
!20 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "fn()", baseType: !21, size: 64, align: 64, dwarfAddressSpace: 0)
!21 = !DISubroutineType(types: !22)
!22 = !{null}
!23 = !{}
!24 = !{i32 8, !"PIC Level", i32 2}
!25 = !{i32 7, !"PIE Level", i32 2}
!26 = !{i32 4, !"EnableSplitLTOUnit", i32 1}
!27 = !{i32 2, !"Dwarf Version", i32 4}
!28 = !{i32 2, !"Debug Info Version", i32 3}
!29 = !{!"rustc version 1.84.0-nightly (583b25d8d 2024-11-12)"}
!30 = distinct !DICompileUnit(language: DW_LANG_Rust, file: !31, producer: "clang LLVM (rustc version 1.84.0-nightly (583b25d8d 2024-11-12))", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, enums: !32, globals: !43, splitDebugInlining: false, nameTableKind: None)
!31 = !DIFile(filename: "../../src/lib/lto-hang/src/main.rs/@/lto_hang.577eccc79634c19c-cgu.0", directory: ".")
!32 = !{!33}
!33 = !DICompositeType(tag: DW_TAG_enumeration_type, name: "Alignment", scope: !34, file: !2, baseType: !37, size: 8, align: 8, flags: DIFlagEnumClass, elements: !38)
!34 = !DINamespace(name: "rt", scope: !35)
!35 = !DINamespace(name: "fmt", scope: !36)
!36 = !DINamespace(name: "core", scope: null)
!37 = !DIBasicType(name: "u8", size: 8, encoding: DW_ATE_unsigned)
!38 = !{!39, !40, !41, !42}
!39 = !DIEnumerator(name: "Left", value: 0, isUnsigned: true)
!40 = !DIEnumerator(name: "Right", value: 1, isUnsigned: true)
!41 = !DIEnumerator(name: "Center", value: 2, isUnsigned: true)
!42 = !DIEnumerator(name: "Unknown", value: 3, isUnsigned: true)
!43 = !{!0}
!44 = distinct !DISubprogram(name: "new_v1<2, 1>", linkageName: "_RINvMs0_NtCsaflpkWScbL9_4core3fmtNtB6_9Arguments6new_v1Kj2_Kj1_ECs7vJBeK7brjY_8lto_hang", scope: !46, file: !45, line: 348, type: !193, scopeLine: 348, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, declaration: !203, retainedNodes: !204)
!45 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/core/src/fmt/mod.rs", directory: "", checksumkind: CSK_MD5, checksum: "ec5a7794b741f88ad8c8e777fe6199cc")
!46 = !DICompositeType(tag: DW_TAG_structure_type, name: "Arguments", scope: !35, file: !2, size: 384, align: 64, flags: DIFlagPublic, elements: !47, templateParams: !23, identifier: "7659c7fddce42291e111f9673c99a8e4")
!47 = !{!48, !59, !105}
!48 = !DIDerivedType(tag: DW_TAG_member, name: "pieces", scope: !46, file: !2, baseType: !49, size: 128, align: 64, flags: DIFlagPrivate)
!49 = !DICompositeType(tag: DW_TAG_structure_type, name: "&[&str]", file: !2, size: 128, align: 64, elements: !50, templateParams: !23, identifier: "4e66b00a376d6af5b8765440fb2839f")
!50 = !{!51, !58}
!51 = !DIDerivedType(tag: DW_TAG_member, name: "data_ptr", scope: !49, file: !2, baseType: !52, size: 64, align: 64)
!52 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !53, size: 64, align: 64, dwarfAddressSpace: 0)
!53 = !DICompositeType(tag: DW_TAG_structure_type, name: "&str", file: !2, size: 128, align: 64, elements: !54, templateParams: !23, identifier: "9277eecd40495f85161460476aacc992")
!54 = !{!55, !57}
!55 = !DIDerivedType(tag: DW_TAG_member, name: "data_ptr", scope: !53, file: !2, baseType: !56, size: 64, align: 64)
!56 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !37, size: 64, align: 64, dwarfAddressSpace: 0)
!57 = !DIDerivedType(tag: DW_TAG_member, name: "length", scope: !53, file: !2, baseType: !9, size: 64, align: 64, offset: 64)
!58 = !DIDerivedType(tag: DW_TAG_member, name: "length", scope: !49, file: !2, baseType: !9, size: 64, align: 64, offset: 64)
!59 = !DIDerivedType(tag: DW_TAG_member, name: "fmt", scope: !46, file: !2, baseType: !60, size: 128, align: 64, offset: 256, flags: DIFlagPrivate)
!60 = !DICompositeType(tag: DW_TAG_structure_type, name: "Option<&[core::fmt::rt::Placeholder]>", scope: !61, file: !2, size: 128, align: 64, flags: DIFlagPublic, elements: !62, templateParams: !23, identifier: "374760e41401df004cf94b64a062789")
!61 = !DINamespace(name: "option", scope: !36)
!62 = !{!63}
!63 = !DICompositeType(tag: DW_TAG_variant_part, scope: !60, file: !2, size: 128, align: 64, elements: !64, templateParams: !23, identifier: "7f036f1acf40bd966d3874f239bf764", discriminator: !104)
!64 = !{!65, !100}
!65 = !DIDerivedType(tag: DW_TAG_member, name: "None", scope: !63, file: !2, baseType: !66, size: 128, align: 64, extraData: i128 0)
!66 = !DICompositeType(tag: DW_TAG_structure_type, name: "None", scope: !60, file: !2, size: 128, align: 64, flags: DIFlagPublic, elements: !23, templateParams: !67, identifier: "5e12be4503fab506252b75d8d3af517b")
!67 = !{!68}
!68 = !DITemplateTypeParameter(name: "T", type: !69)
!69 = !DICompositeType(tag: DW_TAG_structure_type, name: "&[core::fmt::rt::Placeholder]", file: !2, size: 128, align: 64, elements: !70, templateParams: !23, identifier: "e8a0ca4535f5979148b9f011ebfb858d")
!70 = !{!71, !99}
!71 = !DIDerivedType(tag: DW_TAG_member, name: "data_ptr", scope: !69, file: !2, baseType: !72, size: 64, align: 64)
!72 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !73, size: 64, align: 64, dwarfAddressSpace: 0)
!73 = !DICompositeType(tag: DW_TAG_structure_type, name: "Placeholder", scope: !34, file: !2, size: 448, align: 64, flags: DIFlagPublic, elements: !74, templateParams: !23, identifier: "316d9d1d9fffd392774271512ee0f22f")
!74 = !{!75, !76, !78, !79, !81, !98}
!75 = !DIDerivedType(tag: DW_TAG_member, name: "position", scope: !73, file: !2, baseType: !9, size: 64, align: 64, offset: 256, flags: DIFlagPublic)
!76 = !DIDerivedType(tag: DW_TAG_member, name: "fill", scope: !73, file: !2, baseType: !77, size: 32, align: 32, offset: 320, flags: DIFlagPublic)
!77 = !DIBasicType(name: "char", size: 32, encoding: DW_ATE_UTF)
!78 = !DIDerivedType(tag: DW_TAG_member, name: "align", scope: !73, file: !2, baseType: !33, size: 8, align: 8, offset: 384, flags: DIFlagPublic)
!79 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !73, file: !2, baseType: !80, size: 32, align: 32, offset: 352, flags: DIFlagPublic)
!80 = !DIBasicType(name: "u32", size: 32, encoding: DW_ATE_unsigned)
!81 = !DIDerivedType(tag: DW_TAG_member, name: "precision", scope: !73, file: !2, baseType: !82, size: 128, align: 64, flags: DIFlagPublic)
!82 = !DICompositeType(tag: DW_TAG_structure_type, name: "Count", scope: !34, file: !2, size: 128, align: 64, flags: DIFlagPublic, elements: !83, templateParams: !23, identifier: "8f6d386ff540b34fc6bce2cb6656d935")
!83 = !{!84}
!84 = !DICompositeType(tag: DW_TAG_variant_part, scope: !82, file: !2, size: 128, align: 64, elements: !85, templateParams: !23, identifier: "e425f870ed42e6675fc20433e52f1483", discriminator: !96)
!85 = !{!86, !90, !94}
!86 = !DIDerivedType(tag: DW_TAG_member, name: "Is", scope: !84, file: !2, baseType: !87, size: 128, align: 64, extraData: i128 0)
!87 = !DICompositeType(tag: DW_TAG_structure_type, name: "Is", scope: !82, file: !2, size: 128, align: 64, flags: DIFlagPublic, elements: !88, templateParams: !23, identifier: "b60b8f80cef4d5ce82ea1688618b1756")
!88 = !{!89}
!89 = !DIDerivedType(tag: DW_TAG_member, name: "__0", scope: !87, file: !2, baseType: !9, size: 64, align: 64, offset: 64, flags: DIFlagPublic)
!90 = !DIDerivedType(tag: DW_TAG_member, name: "Param", scope: !84, file: !2, baseType: !91, size: 128, align: 64, extraData: i128 1)
!91 = !DICompositeType(tag: DW_TAG_structure_type, name: "Param", scope: !82, file: !2, size: 128, align: 64, flags: DIFlagPublic, elements: !92, templateParams: !23, identifier: "e02967cf8fb336aec75d42bed160660f")
!92 = !{!93}
!93 = !DIDerivedType(tag: DW_TAG_member, name: "__0", scope: !91, file: !2, baseType: !9, size: 64, align: 64, offset: 64, flags: DIFlagPublic)
!94 = !DIDerivedType(tag: DW_TAG_member, name: "Implied", scope: !84, file: !2, baseType: !95, size: 128, align: 64, extraData: i128 2)
!95 = !DICompositeType(tag: DW_TAG_structure_type, name: "Implied", scope: !82, file: !2, size: 128, align: 64, flags: DIFlagPublic, elements: !23, identifier: "e3155a0efde07409ca328d1c0de29b40")
!96 = !DIDerivedType(tag: DW_TAG_member, scope: !82, file: !2, baseType: !97, size: 64, align: 64, flags: DIFlagArtificial)
!97 = !DIBasicType(name: "u64", size: 64, encoding: DW_ATE_unsigned)
!98 = !DIDerivedType(tag: DW_TAG_member, name: "width", scope: !73, file: !2, baseType: !82, size: 128, align: 64, offset: 128, flags: DIFlagPublic)
!99 = !DIDerivedType(tag: DW_TAG_member, name: "length", scope: !69, file: !2, baseType: !9, size: 64, align: 64, offset: 64)
!100 = !DIDerivedType(tag: DW_TAG_member, name: "Some", scope: !63, file: !2, baseType: !101, size: 128, align: 64)
!101 = !DICompositeType(tag: DW_TAG_structure_type, name: "Some", scope: !60, file: !2, size: 128, align: 64, flags: DIFlagPublic, elements: !102, templateParams: !67, identifier: "dbe60c94b1a3666570045a3fd6c4b46e")
!102 = !{!103}
!103 = !DIDerivedType(tag: DW_TAG_member, name: "__0", scope: !101, file: !2, baseType: !69, size: 128, align: 64, flags: DIFlagPublic)
!104 = !DIDerivedType(tag: DW_TAG_member, scope: !60, file: !2, baseType: !97, size: 64, align: 64, flags: DIFlagArtificial)
!105 = !DIDerivedType(tag: DW_TAG_member, name: "args", scope: !46, file: !2, baseType: !106, size: 128, align: 64, offset: 128, flags: DIFlagPrivate)
!106 = !DICompositeType(tag: DW_TAG_structure_type, name: "&[core::fmt::rt::Argument]", file: !2, size: 128, align: 64, elements: !107, templateParams: !23, identifier: "beeaee4a56f8c44a12fb70aef1ca4776")
!107 = !{!108, !192}
!108 = !DIDerivedType(tag: DW_TAG_member, name: "data_ptr", scope: !106, file: !2, baseType: !109, size: 64, align: 64)
!109 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !110, size: 64, align: 64, dwarfAddressSpace: 0)
!110 = !DICompositeType(tag: DW_TAG_structure_type, name: "Argument", scope: !34, file: !2, size: 128, align: 64, flags: DIFlagPublic, elements: !111, templateParams: !23, identifier: "57773ff3dc2bf289f78ea586e9ae43c")
!111 = !{!112}
!112 = !DIDerivedType(tag: DW_TAG_member, name: "ty", scope: !110, file: !2, baseType: !113, size: 128, align: 64, flags: DIFlagPrivate)
!113 = !DICompositeType(tag: DW_TAG_structure_type, name: "ArgumentType", scope: !34, file: !2, size: 128, align: 64, flags: DIFlagPrivate, elements: !114, templateParams: !23, identifier: "5230b5c7dcd407df45df7a38762dbfdc")
!114 = !{!115}
!115 = !DICompositeType(tag: DW_TAG_variant_part, scope: !113, file: !2, size: 128, align: 64, elements: !116, templateParams: !23, identifier: "d0b8e7fee5331fd3f5b397027f8b5ed", discriminator: !191)
!116 = !{!117, !187}
!117 = !DIDerivedType(tag: DW_TAG_member, name: "Placeholder", scope: !115, file: !2, baseType: !118, size: 128, align: 64)
!118 = !DICompositeType(tag: DW_TAG_structure_type, name: "Placeholder", scope: !113, file: !2, size: 128, align: 64, flags: DIFlagPrivate, elements: !119, templateParams: !23, identifier: "d1a7fc682265a67265426bfe009e918e")
!119 = !{!120, !128, !181}
!120 = !DIDerivedType(tag: DW_TAG_member, name: "value", scope: !118, file: !2, baseType: !121, size: 64, align: 64, flags: DIFlagPrivate)
!121 = !DICompositeType(tag: DW_TAG_structure_type, name: "NonNull<()>", scope: !122, file: !2, size: 64, align: 64, flags: DIFlagPublic, elements: !124, templateParams: !126, identifier: "eb02336b7201179e44dd03f20fc6d041")
!122 = !DINamespace(name: "non_null", scope: !123)
!123 = !DINamespace(name: "ptr", scope: !36)
!124 = !{!125}
!125 = !DIDerivedType(tag: DW_TAG_member, name: "pointer", scope: !121, file: !2, baseType: !6, size: 64, align: 64, flags: DIFlagPrivate)
!126 = !{!127}
!127 = !DITemplateTypeParameter(name: "T", type: !7)
!128 = !DIDerivedType(tag: DW_TAG_member, name: "formatter", scope: !118, file: !2, baseType: !129, size: 64, align: 64, offset: 64, flags: DIFlagPrivate)
!129 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "unsafe fn(core::ptr::non_null::NonNull<()>, &mut core::fmt::Formatter) -> core::result::Result<(), core::fmt::Error>", baseType: !130, size: 64, align: 64, dwarfAddressSpace: 0)
!130 = !DISubroutineType(types: !131)
!131 = !{!132, !121, !149}
!132 = !DICompositeType(tag: DW_TAG_structure_type, name: "Result<(), core::fmt::Error>", scope: !133, file: !2, size: 8, align: 8, flags: DIFlagPublic, elements: !134, templateParams: !23, identifier: "cb7a47fd4c9c76acf2d51b913c8288a")
!133 = !DINamespace(name: "result", scope: !36)
!134 = !{!135}
!135 = !DICompositeType(tag: DW_TAG_variant_part, scope: !132, file: !2, size: 8, align: 8, elements: !136, templateParams: !23, identifier: "9355bcb9f084bddb9fa071fd253b030a", discriminator: !148)
!136 = !{!137, !144}
!137 = !DIDerivedType(tag: DW_TAG_member, name: "Ok", scope: !135, file: !2, baseType: !138, size: 8, align: 8, extraData: i128 0)
!138 = !DICompositeType(tag: DW_TAG_structure_type, name: "Ok", scope: !132, file: !2, size: 8, align: 8, flags: DIFlagPublic, elements: !139, templateParams: !141, identifier: "39011d3f1eb1378c5fa52d64147b19d9")
!139 = !{!140}
!140 = !DIDerivedType(tag: DW_TAG_member, name: "__0", scope: !138, file: !2, baseType: !7, align: 8, offset: 8, flags: DIFlagPublic)
!141 = !{!127, !142}
!142 = !DITemplateTypeParameter(name: "E", type: !143)
!143 = !DICompositeType(tag: DW_TAG_structure_type, name: "Error", scope: !35, file: !2, align: 8, flags: DIFlagPublic, elements: !23, identifier: "6179370c4e4f8c7c58e4b3a294fe102e")
!144 = !DIDerivedType(tag: DW_TAG_member, name: "Err", scope: !135, file: !2, baseType: !145, size: 8, align: 8, extraData: i128 1)
!145 = !DICompositeType(tag: DW_TAG_structure_type, name: "Err", scope: !132, file: !2, size: 8, align: 8, flags: DIFlagPublic, elements: !146, templateParams: !141, identifier: "606996f31c780fc66443a062ec34d7c0")
!146 = !{!147}
!147 = !DIDerivedType(tag: DW_TAG_member, name: "__0", scope: !145, file: !2, baseType: !143, align: 8, offset: 8, flags: DIFlagPublic)
!148 = !DIDerivedType(tag: DW_TAG_member, scope: !132, file: !2, baseType: !37, size: 8, align: 8, flags: DIFlagArtificial)
!149 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "&mut core::fmt::Formatter", baseType: !150, size: 64, align: 64, dwarfAddressSpace: 0)
!150 = !DICompositeType(tag: DW_TAG_structure_type, name: "Formatter", scope: !35, file: !2, size: 512, align: 64, flags: DIFlagPublic, elements: !151, templateParams: !23, identifier: "6bd48bc4e7f6b5365b2d98b5d9c72")
!151 = !{!152, !153, !154, !155, !169, !170}
!152 = !DIDerivedType(tag: DW_TAG_member, name: "flags", scope: !150, file: !2, baseType: !80, size: 32, align: 32, offset: 416, flags: DIFlagPrivate)
!153 = !DIDerivedType(tag: DW_TAG_member, name: "fill", scope: !150, file: !2, baseType: !77, size: 32, align: 32, offset: 384, flags: DIFlagPrivate)
!154 = !DIDerivedType(tag: DW_TAG_member, name: "align", scope: !150, file: !2, baseType: !33, size: 8, align: 8, offset: 448, flags: DIFlagPrivate)
!155 = !DIDerivedType(tag: DW_TAG_member, name: "width", scope: !150, file: !2, baseType: !156, size: 128, align: 64, flags: DIFlagPrivate)
!156 = !DICompositeType(tag: DW_TAG_structure_type, name: "Option<usize>", scope: !61, file: !2, size: 128, align: 64, flags: DIFlagPublic, elements: !157, templateParams: !23, identifier: "48c758be57d59c951f4693f29c1e1876")
!157 = !{!158}
!158 = !DICompositeType(tag: DW_TAG_variant_part, scope: !156, file: !2, size: 128, align: 64, elements: !159, templateParams: !23, identifier: "6870b248824d0a9bc8db99d894a3a1c0", discriminator: !168)
!159 = !{!160, !164}
!160 = !DIDerivedType(tag: DW_TAG_member, name: "None", scope: !158, file: !2, baseType: !161, size: 128, align: 64, extraData: i128 0)
!161 = !DICompositeType(tag: DW_TAG_structure_type, name: "None", scope: !156, file: !2, size: 128, align: 64, flags: DIFlagPublic, elements: !23, templateParams: !162, identifier: "2cdb850385bf2468e84bb883f970703a")
!162 = !{!163}
!163 = !DITemplateTypeParameter(name: "T", type: !9)
!164 = !DIDerivedType(tag: DW_TAG_member, name: "Some", scope: !158, file: !2, baseType: !165, size: 128, align: 64, extraData: i128 1)
!165 = !DICompositeType(tag: DW_TAG_structure_type, name: "Some", scope: !156, file: !2, size: 128, align: 64, flags: DIFlagPublic, elements: !166, templateParams: !162, identifier: "f580385fa52a3c7b830588f61928e92a")
!166 = !{!167}
!167 = !DIDerivedType(tag: DW_TAG_member, name: "__0", scope: !165, file: !2, baseType: !9, size: 64, align: 64, offset: 64, flags: DIFlagPublic)
!168 = !DIDerivedType(tag: DW_TAG_member, scope: !156, file: !2, baseType: !97, size: 64, align: 64, flags: DIFlagArtificial)
!169 = !DIDerivedType(tag: DW_TAG_member, name: "precision", scope: !150, file: !2, baseType: !156, size: 128, align: 64, offset: 128, flags: DIFlagPrivate)
!170 = !DIDerivedType(tag: DW_TAG_member, name: "buf", scope: !150, file: !2, baseType: !171, size: 128, align: 64, offset: 256, flags: DIFlagPrivate)
!171 = !DICompositeType(tag: DW_TAG_structure_type, name: "&mut dyn core::fmt::Write", file: !2, size: 128, align: 64, elements: !172, templateParams: !23, identifier: "71f8090b67cc919c8df130d762d35301")
!172 = !{!173, !176}
!173 = !DIDerivedType(tag: DW_TAG_member, name: "pointer", scope: !171, file: !2, baseType: !174, size: 64, align: 64)
!174 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !175, size: 64, align: 64, dwarfAddressSpace: 0)
!175 = !DICompositeType(tag: DW_TAG_structure_type, name: "dyn core::fmt::Write", file: !2, align: 8, elements: !23, identifier: "fa8036d12bf71cf646417cf76ffd98d5")
!176 = !DIDerivedType(tag: DW_TAG_member, name: "vtable", scope: !171, file: !2, baseType: !177, size: 64, align: 64, offset: 64)
!177 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "&[usize; 6]", baseType: !178, size: 64, align: 64, dwarfAddressSpace: 0)
!178 = !DICompositeType(tag: DW_TAG_array_type, baseType: !9, size: 384, align: 64, elements: !179)
!179 = !{!180}
!180 = !DISubrange(count: 6, lowerBound: 0)
!181 = !DIDerivedType(tag: DW_TAG_member, name: "_lifetime", scope: !118, file: !2, baseType: !182, align: 8, offset: 128, flags: DIFlagPrivate)
!182 = !DICompositeType(tag: DW_TAG_structure_type, name: "PhantomData<&()>", scope: !183, file: !2, align: 8, flags: DIFlagPublic, elements: !23, templateParams: !184, identifier: "bc4c8982f1bcf10375660d3145d9c59c")
!183 = !DINamespace(name: "marker", scope: !36)
!184 = !{!185}
!185 = !DITemplateTypeParameter(name: "T", type: !186)
!186 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "&()", baseType: !7, size: 64, align: 64, dwarfAddressSpace: 0)
!187 = !DIDerivedType(tag: DW_TAG_member, name: "Count", scope: !115, file: !2, baseType: !188, size: 128, align: 64, extraData: i128 0)
!188 = !DICompositeType(tag: DW_TAG_structure_type, name: "Count", scope: !113, file: !2, size: 128, align: 64, flags: DIFlagPrivate, elements: !189, templateParams: !23, identifier: "59931463705d8aa0534cce4da741dc98")
!189 = !{!190}
!190 = !DIDerivedType(tag: DW_TAG_member, name: "__0", scope: !188, file: !2, baseType: !9, size: 64, align: 64, offset: 64, flags: DIFlagPrivate)
!191 = !DIDerivedType(tag: DW_TAG_member, scope: !113, file: !2, baseType: !97, size: 64, align: 64, flags: DIFlagArtificial)
!192 = !DIDerivedType(tag: DW_TAG_member, name: "length", scope: !106, file: !2, baseType: !9, size: 64, align: 64, offset: 64)
!193 = !DISubroutineType(types: !194)
!194 = !{!46, !195, !199}
!195 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "&[&str; 2]", baseType: !196, size: 64, align: 64, dwarfAddressSpace: 0)
!196 = !DICompositeType(tag: DW_TAG_array_type, baseType: !53, size: 256, align: 64, elements: !197)
!197 = !{!198}
!198 = !DISubrange(count: 2, lowerBound: 0)
!199 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "&[core::fmt::rt::Argument; 1]", baseType: !200, size: 64, align: 64, dwarfAddressSpace: 0)
!200 = !DICompositeType(tag: DW_TAG_array_type, baseType: !110, size: 128, align: 64, elements: !201)
!201 = !{!202}
!202 = !DISubrange(count: 1, lowerBound: 0)
!203 = !DISubprogram(name: "new_v1<2, 1>", linkageName: "_RINvMs0_NtCsaflpkWScbL9_4core3fmtNtB6_9Arguments6new_v1Kj2_Kj1_ECs7vJBeK7brjY_8lto_hang", scope: !46, file: !45, line: 348, type: !193, scopeLine: 348, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagOptimized, templateParams: !23)
!204 = !{!205, !206}
!205 = !DILocalVariable(name: "pieces", arg: 1, scope: !44, file: !45, line: 349, type: !195)
!206 = !DILocalVariable(name: "args", arg: 2, scope: !44, file: !45, line: 350, type: !199)
!207 = !DILocation(line: 349, column: 9, scope: !44)
!208 = !DILocation(line: 350, column: 9, scope: !44)
!209 = !DILocation(line: 353, column: 9, scope: !44)
!210 = !{i64 8}
!211 = !DILocation(line: 354, column: 6, scope: !44)
!212 = distinct !DISubprogram(name: "new_const<1>", linkageName: "_RINvMs0_NtCsaflpkWScbL9_4core3fmtNtB6_9Arguments9new_constKj1_ECs7vJBeK7brjY_8lto_hang", scope: !46, file: !45, line: 340, type: !213, scopeLine: 340, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, declaration: !217, retainedNodes: !218)
!213 = !DISubroutineType(types: !214)
!214 = !{!46, !215}
!215 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "&[&str; 1]", baseType: !216, size: 64, align: 64, dwarfAddressSpace: 0)
!216 = !DICompositeType(tag: DW_TAG_array_type, baseType: !53, size: 128, align: 64, elements: !201)
!217 = !DISubprogram(name: "new_const<1>", linkageName: "_RINvMs0_NtCsaflpkWScbL9_4core3fmtNtB6_9Arguments9new_constKj1_ECs7vJBeK7brjY_8lto_hang", scope: !46, file: !45, line: 340, type: !213, scopeLine: 340, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagOptimized, templateParams: !23)
!218 = !{!219}
!219 = !DILocalVariable(name: "pieces", arg: 1, scope: !212, file: !45, line: 340, type: !215)
!220 = !DILocation(line: 340, column: 44, scope: !212)
!221 = !DILocation(line: 342, column: 9, scope: !212)
!222 = !DILocation(line: 343, column: 6, scope: !212)
!223 = distinct !DISubprogram(name: "new_debug<i8>", linkageName: "_RINvMs_NtNtCsaflpkWScbL9_4core3fmt2rtNtB5_8Argument9new_debugaECs7vJBeK7brjY_8lto_hang", scope: !110, file: !224, line: 117, type: !225, scopeLine: 117, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !230, declaration: !229, retainedNodes: !232)
!224 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/core/src/fmt/rt.rs", directory: "", checksumkind: CSK_MD5, checksum: "b94396039e3c87f654797fdd982cf3e9")
!225 = !DISubroutineType(types: !226)
!226 = !{!110, !227}
!227 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "&i8", baseType: !228, size: 64, align: 64, dwarfAddressSpace: 0)
!228 = !DIBasicType(name: "i8", size: 8, encoding: DW_ATE_signed)
!229 = !DISubprogram(name: "new_debug<i8>", linkageName: "_RINvMs_NtNtCsaflpkWScbL9_4core3fmt2rtNtB5_8Argument9new_debugaECs7vJBeK7brjY_8lto_hang", scope: !110, file: !224, line: 117, type: !225, scopeLine: 117, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagOptimized, templateParams: !230)
!230 = !{!231}
!231 = !DITemplateTypeParameter(name: "T", type: !228)
!232 = !{!233}
!233 = !DILocalVariable(name: "x", arg: 1, scope: !223, file: !224, line: 117, type: !227)
!234 = !DILocation(line: 117, column: 32, scope: !223)
!235 = !DILocalVariable(name: "x", arg: 1, scope: !236, file: !224, line: 99, type: !227)
!236 = distinct !DISubprogram(name: "new<i8>", linkageName: "_RINvMs_NtNtCsaflpkWScbL9_4core3fmt2rtNtB5_8Argument3newaECs7vJBeK7brjY_8lto_hang", scope: !110, file: !224, line: 99, type: !237, scopeLine: 99, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !230, declaration: !242, retainedNodes: !243)
!237 = !DISubroutineType(types: !238)
!238 = !{!110, !227, !239}
!239 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "fn(&i8, &mut core::fmt::Formatter) -> core::result::Result<(), core::fmt::Error>", baseType: !240, size: 64, align: 64, dwarfAddressSpace: 0)
!240 = !DISubroutineType(types: !241)
!241 = !{!132, !227, !149}
!242 = !DISubprogram(name: "new<i8>", linkageName: "_RINvMs_NtNtCsaflpkWScbL9_4core3fmt2rtNtB5_8Argument3newaECs7vJBeK7brjY_8lto_hang", scope: !110, file: !224, line: 99, type: !237, scopeLine: 99, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagOptimized, templateParams: !230)
!243 = !{!235, !244}
!244 = !DILocalVariable(name: "f", arg: 2, scope: !236, file: !224, line: 99, type: !239)
!245 = !DILocation(line: 99, column: 19, scope: !236, inlinedAt: !246)
!246 = !DILocation(line: 118, column: 9, scope: !223)
!247 = !DILocalVariable(name: "r", arg: 1, scope: !248, file: !249, line: 1622, type: !227)
!248 = distinct !DISubprogram(name: "from<i8>", linkageName: "_RNvXsh_NtNtCsaflpkWScbL9_4core3ptr8non_nullINtB5_7NonNullaEINtNtB9_7convert4FromRaE4fromCs7vJBeK7brjY_8lto_hang", scope: !250, file: !249, line: 1622, type: !251, scopeLine: 1622, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !230, retainedNodes: !257)
!249 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/core/src/ptr/non_null.rs", directory: "", checksumkind: CSK_MD5, checksum: "1519f88add6f06bccf70a2b22cd77776")
!250 = !DINamespace(name: "{impl#19}", scope: !122)
!251 = !DISubroutineType(types: !252)
!252 = !{!253, !227}
!253 = !DICompositeType(tag: DW_TAG_structure_type, name: "NonNull<i8>", scope: !122, file: !2, size: 64, align: 64, flags: DIFlagPublic, elements: !254, templateParams: !230, identifier: "7ac31d4394e1c4efec36e807e76125d0")
!254 = !{!255}
!255 = !DIDerivedType(tag: DW_TAG_member, name: "pointer", scope: !253, file: !2, baseType: !256, size: 64, align: 64, flags: DIFlagPrivate)
!256 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*const i8", baseType: !228, size: 64, align: 64, dwarfAddressSpace: 0)
!257 = !{!247}
!258 = !DILocation(line: 1622, column: 13, scope: !248, inlinedAt: !259)
!259 = !DILocation(line: 104, column: 24, scope: !236, inlinedAt: !246)
!260 = !DILocalVariable(name: "r", arg: 1, scope: !261, file: !249, line: 232, type: !227)
!261 = distinct !DISubprogram(name: "from_ref<i8>", linkageName: "_RNvMs1_NtNtCsaflpkWScbL9_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs7vJBeK7brjY_8lto_hang", scope: !253, file: !249, line: 232, type: !251, scopeLine: 232, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !230, declaration: !262, retainedNodes: !263)
!262 = !DISubprogram(name: "from_ref<i8>", linkageName: "_RNvMs1_NtNtCsaflpkWScbL9_4core3ptr8non_nullINtB5_7NonNullaE8from_refCs7vJBeK7brjY_8lto_hang", scope: !253, file: !249, line: 232, type: !251, scopeLine: 232, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagOptimized, templateParams: !230)
!263 = !{!260}
!264 = !DILocation(line: 232, column: 27, scope: !261, inlinedAt: !265)
!265 = !DILocation(line: 1623, column: 9, scope: !248, inlinedAt: !259)
!266 = !DILocation(line: 118, column: 22, scope: !223)
!267 = !DILocation(line: 99, column: 29, scope: !236, inlinedAt: !246)
!268 = !DILocation(line: 103, column: 17, scope: !236, inlinedAt: !246)
!269 = !DILocation(line: 234, column: 18, scope: !261, inlinedAt: !265)
!270 = !DILocalVariable(name: "self", arg: 1, scope: !271, file: !249, line: 433, type: !253)
!271 = distinct !DISubprogram(name: "cast<i8, ()>", linkageName: "_RINvMs1_NtNtCsaflpkWScbL9_4core3ptr8non_nullINtB6_7NonNullaE4castuECs7vJBeK7brjY_8lto_hang", scope: !253, file: !249, line: 433, type: !272, scopeLine: 433, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !275, declaration: !274, retainedNodes: !277)
!272 = !DISubroutineType(types: !273)
!273 = !{!121, !253}
!274 = !DISubprogram(name: "cast<i8, ()>", linkageName: "_RINvMs1_NtNtCsaflpkWScbL9_4core3ptr8non_nullINtB6_7NonNullaE4castuECs7vJBeK7brjY_8lto_hang", scope: !253, file: !249, line: 433, type: !272, scopeLine: 433, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagOptimized, templateParams: !275)
!275 = !{!231, !276}
!276 = !DITemplateTypeParameter(name: "U", type: !7)
!277 = !{!270}
!278 = !DILocation(line: 433, column: 26, scope: !271, inlinedAt: !279)
!279 = !DILocation(line: 104, column: 41, scope: !236, inlinedAt: !246)
!280 = !DILocalVariable(name: "self", arg: 1, scope: !281, file: !249, line: 337, type: !253)
!281 = distinct !DISubprogram(name: "as_ptr<i8>", linkageName: "_RNvMs1_NtNtCsaflpkWScbL9_4core3ptr8non_nullINtB5_7NonNullaE6as_ptrCs7vJBeK7brjY_8lto_hang", scope: !253, file: !249, line: 337, type: !282, scopeLine: 337, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !230, declaration: !285, retainedNodes: !286)
!282 = !DISubroutineType(types: !283)
!283 = !{!284, !253}
!284 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*mut i8", baseType: !228, size: 64, align: 64, dwarfAddressSpace: 0)
!285 = !DISubprogram(name: "as_ptr<i8>", linkageName: "_RNvMs1_NtNtCsaflpkWScbL9_4core3ptr8non_nullINtB5_7NonNullaE6as_ptrCs7vJBeK7brjY_8lto_hang", scope: !253, file: !249, line: 337, type: !282, scopeLine: 337, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagOptimized, templateParams: !230)
!286 = !{!280}
!287 = !DILocation(line: 337, column: 25, scope: !281, inlinedAt: !288)
!288 = !DILocation(line: 435, column: 42, scope: !271, inlinedAt: !279)
!289 = !DILocation(line: 100, column: 9, scope: !236, inlinedAt: !246)
!290 = !DILocation(line: 109, column: 9, scope: !236, inlinedAt: !246)
!291 = !DILocation(line: 119, column: 6, scope: !223)
!292 = distinct !DISubprogram(name: "drop_in_place<std::rt::lang_start::{closure_env#0}<()>>", linkageName: "_RINvNtCsaflpkWScbL9_4core3ptr13drop_in_placeNCINvNtCscguycxaEVVT_3std2rt10lang_startuE0ECs7vJBeK7brjY_8lto_hang", scope: !123, file: !293, line: 521, type: !294, scopeLine: 521, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !299, retainedNodes: !297)
!293 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/core/src/ptr/mod.rs", directory: "", checksumkind: CSK_MD5, checksum: "97e70fd72b1f918550c9029626d34208")
!294 = !DISubroutineType(types: !295)
!295 = !{null, !296}
!296 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*mut std::rt::lang_start::{closure_env#0}<()>", baseType: !14, size: 64, align: 64, dwarfAddressSpace: 0)
!297 = !{!298}
!298 = !DILocalVariable(arg: 1, scope: !292, file: !293, line: 521, type: !296)
!299 = !{!300}
!300 = !DITemplateTypeParameter(name: "T", type: !14)
!301 = !DILocation(line: 521, column: 1, scope: !292)
!302 = distinct !DISubprogram(name: "lang_start<()>", linkageName: "_RINvNtCscguycxaEVVT_3std2rt10lang_startuECs7vJBeK7brjY_8lto_hang", scope: !16, file: !303, line: 188, type: !304, scopeLine: 188, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !126, retainedNodes: !309)
!303 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/std/src/rt.rs", directory: "", checksumkind: CSK_MD5, checksum: "1f3acc0374c7f5dba2b7965889da591f")
!304 = !DISubroutineType(types: !305)
!305 = !{!306, !20, !306, !307, !37}
!306 = !DIBasicType(name: "isize", size: 64, encoding: DW_ATE_signed)
!307 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*const *const u8", baseType: !308, size: 64, align: 64, dwarfAddressSpace: 0)
!308 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "*const u8", baseType: !37, size: 64, align: 64, dwarfAddressSpace: 0)
!309 = !{!310, !311, !312, !313, !314}
!310 = !DILocalVariable(name: "main", arg: 1, scope: !302, file: !303, line: 189, type: !20)
!311 = !DILocalVariable(name: "argc", arg: 2, scope: !302, file: !303, line: 190, type: !306)
!312 = !DILocalVariable(name: "argv", arg: 3, scope: !302, file: !303, line: 191, type: !307)
!313 = !DILocalVariable(name: "sigpipe", arg: 4, scope: !302, file: !303, line: 192, type: !37)
!314 = !DILocalVariable(name: "v", scope: !315, file: !303, line: 194, type: !306, align: 8)
!315 = distinct !DILexicalBlock(scope: !302, file: !303, line: 194, column: 5)
!316 = !DILocation(line: 189, column: 5, scope: !302)
!317 = !DILocation(line: 190, column: 5, scope: !302)
!318 = !DILocation(line: 191, column: 5, scope: !302)
!319 = !DILocation(line: 192, column: 5, scope: !302)
!320 = !DILocation(line: 194, column: 17, scope: !302)
!321 = !DILocation(line: 195, column: 10, scope: !302)
!322 = !DILocation(line: 194, column: 12, scope: !302)
!323 = !DILocation(line: 194, column: 12, scope: !315)
!324 = !DILocation(line: 199, column: 6, scope: !302)
!325 = !DILocation(line: 201, column: 2, scope: !302)
!326 = distinct !DISubprogram(name: "__rust_begin_short_backtrace<fn(), ()>", linkageName: "_RINvNtNtCscguycxaEVVT_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs7vJBeK7brjY_8lto_hang", scope: !328, file: !327, line: 150, type: !330, scopeLine: 150, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !336, retainedNodes: !332)
!327 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/std/src/sys/backtrace.rs", directory: "", checksumkind: CSK_MD5, checksum: "f08630b35df57d53399ec9f081204be7")
!328 = !DINamespace(name: "backtrace", scope: !329)
!329 = !DINamespace(name: "sys", scope: !17)
!330 = !DISubroutineType(types: !331)
!331 = !{null, !20}
!332 = !{!333, !334}
!333 = !DILocalVariable(name: "f", arg: 1, scope: !326, file: !327, line: 150, type: !20)
!334 = !DILocalVariable(name: "result", scope: !335, file: !327, line: 154, type: !7, align: 1)
!335 = distinct !DILexicalBlock(scope: !326, file: !327, line: 154, column: 5)
!336 = !{!337, !127}
!337 = !DITemplateTypeParameter(name: "F", type: !20)
!338 = !DILocation(line: 154, column: 9, scope: !335)
!339 = !DILocation(line: 150, column: 43, scope: !326)
!340 = !DILocalVariable(name: "dummy", scope: !341, file: !342, line: 388, type: !7, align: 1)
!341 = distinct !DISubprogram(name: "black_box<()>", linkageName: "_RINvNtCsaflpkWScbL9_4core4hint9black_boxuECs7vJBeK7brjY_8lto_hang", scope: !343, file: !342, line: 388, type: !344, scopeLine: 388, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !126, retainedNodes: !346)
!342 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/core/src/hint.rs", directory: "", checksumkind: CSK_MD5, checksum: "12235ea9cded7e7cc8ee4855aaaba161")
!343 = !DINamespace(name: "hint", scope: !36)
!344 = !DISubroutineType(types: !345)
!345 = !{null, !7}
!346 = !{!340}
!347 = !DILocation(line: 388, column: 27, scope: !341, inlinedAt: !348)
!348 = !DILocation(line: 157, column: 5, scope: !335)
!349 = !DILocation(line: 154, column: 18, scope: !326)
!350 = !DILocation(line: 389, column: 5, scope: !341, inlinedAt: !348)
!351 = !{i32 2688779}
!352 = !DILocation(line: 160, column: 2, scope: !326)
!353 = distinct !DISubprogram(name: "{closure#0}<()>", linkageName: "_RNCINvNtCscguycxaEVVT_3std2rt10lang_startuE0Cs7vJBeK7brjY_8lto_hang", scope: !15, file: !303, line: 195, type: !354, scopeLine: 195, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !126, retainedNodes: !358)
!354 = !DISubroutineType(types: !355)
!355 = !{!356, !357}
!356 = !DIBasicType(name: "i32", size: 32, encoding: DW_ATE_signed)
!357 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "&std::rt::lang_start::{closure_env#0}<()>", baseType: !14, size: 64, align: 64, dwarfAddressSpace: 0)
!358 = !{!359}
!359 = !DILocalVariable(name: "main", scope: !353, file: !303, line: 189, type: !20, align: 8)
!360 = !DILocation(line: 189, column: 5, scope: !353)
!361 = !DILocalVariable(name: "self", arg: 1, scope: !362, file: !363, line: 2052, type: !364)
!362 = distinct !DISubprogram(name: "to_i32", linkageName: "_ZN3std7process8ExitCode6to_i3217hac38b6b5178a1822E", scope: !364, file: !363, line: 2052, type: !375, scopeLine: 2052, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, declaration: !377, retainedNodes: !378)
!363 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/std/src/process.rs", directory: "", checksumkind: CSK_MD5, checksum: "7c2edf9c7a2c84e06b13ad428156c063")
!364 = !DICompositeType(tag: DW_TAG_structure_type, name: "ExitCode", scope: !365, file: !2, size: 8, align: 8, flags: DIFlagPublic, elements: !366, templateParams: !23, identifier: "6a9bcda40ece9de6d78c5704b20c2727")
!365 = !DINamespace(name: "process", scope: !17)
!366 = !{!367}
!367 = !DIDerivedType(tag: DW_TAG_member, name: "__0", scope: !364, file: !2, baseType: !368, size: 8, align: 8, flags: DIFlagPrivate)
!368 = !DICompositeType(tag: DW_TAG_structure_type, name: "ExitCode", scope: !369, file: !2, size: 8, align: 8, flags: DIFlagPublic, elements: !373, templateParams: !23, identifier: "a22296a45d9764be780c5c5de93512f4")
!369 = !DINamespace(name: "process_common", scope: !370)
!370 = !DINamespace(name: "process", scope: !371)
!371 = !DINamespace(name: "unix", scope: !372)
!372 = !DINamespace(name: "pal", scope: !329)
!373 = !{!374}
!374 = !DIDerivedType(tag: DW_TAG_member, name: "__0", scope: !368, file: !2, baseType: !37, size: 8, align: 8, flags: DIFlagPrivate)
!375 = !DISubroutineType(types: !376)
!376 = !{!356, !364}
!377 = !DISubprogram(name: "to_i32", linkageName: "_ZN3std7process8ExitCode6to_i3217hac38b6b5178a1822E", scope: !364, file: !363, line: 2052, type: !375, scopeLine: 2052, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagOptimized, templateParams: !23)
!378 = !{!361}
!379 = !DILocation(line: 2052, column: 19, scope: !362, inlinedAt: !380)
!380 = !DILocation(line: 195, column: 85, scope: !353)
!381 = !DILocation(line: 195, column: 18, scope: !353)
!382 = !DILocation(line: 195, column: 70, scope: !353)
!383 = !DILocation(line: 2053, column: 9, scope: !362, inlinedAt: !380)
!384 = !DILocalVariable(name: "self", arg: 1, scope: !385, file: !386, line: 635, type: !389)
!385 = distinct !DISubprogram(name: "as_i32", linkageName: "_ZN3std3sys3pal4unix7process14process_common8ExitCode6as_i3217h2c4464a686f347a8E", scope: !368, file: !386, line: 635, type: !387, scopeLine: 635, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, declaration: !390, retainedNodes: !391)
!386 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/std/src/sys/pal/unix/process/process_common.rs", directory: "", checksumkind: CSK_MD5, checksum: "c24616daddebe24e73c8d390f9a2c5b7")
!387 = !DISubroutineType(types: !388)
!388 = !{!356, !389}
!389 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "&std::sys::pal::unix::process::process_common::ExitCode", baseType: !368, size: 64, align: 64, dwarfAddressSpace: 0)
!390 = !DISubprogram(name: "as_i32", linkageName: "_ZN3std3sys3pal4unix7process14process_common8ExitCode6as_i3217h2c4464a686f347a8E", scope: !368, file: !386, line: 635, type: !387, scopeLine: 635, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagOptimized, templateParams: !23)
!391 = !{!384}
!392 = !DILocation(line: 635, column: 19, scope: !385, inlinedAt: !393)
!393 = !DILocation(line: 2053, column: 16, scope: !362, inlinedAt: !380)
!394 = !DILocation(line: 636, column: 9, scope: !385, inlinedAt: !393)
!395 = !DILocation(line: 195, column: 92, scope: !353)
!396 = !DILocation(line: 195, column: 93, scope: !353)
!397 = distinct !DISubprogram(name: "call_once<std::rt::lang_start::{closure_env#0}<()>, ()>", linkageName: "_RNSNvYNCINvNtCscguycxaEVVT_3std2rt10lang_startuE0INtNtNtCsaflpkWScbL9_4core3ops8function6FnOnceuE9call_once6vtableCs7vJBeK7brjY_8lto_hang", scope: !399, file: !398, line: 250, type: !402, scopeLine: 250, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !407, retainedNodes: !404)
!398 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/core/src/ops/function.rs", directory: "", checksumkind: CSK_MD5, checksum: "27f40bbdeb6cc525c0d0d7cf434d92c4")
!399 = !DINamespace(name: "FnOnce", scope: !400)
!400 = !DINamespace(name: "function", scope: !401)
!401 = !DINamespace(name: "ops", scope: !36)
!402 = !DISubroutineType(types: !403)
!403 = !{!356, !296}
!404 = !{!405, !406}
!405 = !DILocalVariable(arg: 1, scope: !397, file: !398, line: 250, type: !296)
!406 = !DILocalVariable(arg: 2, scope: !397, file: !398, line: 250, type: !7)
!407 = !{!408, !409}
!408 = !DITemplateTypeParameter(name: "Self", type: !14)
!409 = !DITemplateTypeParameter(name: "Args", type: !7)
!410 = !DILocation(line: 250, column: 5, scope: !397)
!411 = distinct !DISubprogram(name: "spec_next<i8>", linkageName: "_RNvXs3_NtNtCsaflpkWScbL9_4core4iter5rangeINtNtNtB9_3ops5range5RangeaENtB5_17RangeIteratorImpl9spec_nextCs7vJBeK7brjY_8lto_hang", scope: !413, file: !412, line: 751, type: !416, scopeLine: 751, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !230, retainedNodes: !437)
!412 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/core/src/iter/range.rs", directory: "", checksumkind: CSK_MD5, checksum: "cad9e97b9b52cde41ae486fcfb368b94")
!413 = !DINamespace(name: "{impl#5}", scope: !414)
!414 = !DINamespace(name: "range", scope: !415)
!415 = !DINamespace(name: "iter", scope: !36)
!416 = !DISubroutineType(types: !417)
!417 = !{!418, !429}
!418 = !DICompositeType(tag: DW_TAG_structure_type, name: "Option<i8>", scope: !61, file: !2, size: 16, align: 8, flags: DIFlagPublic, elements: !419, templateParams: !23, identifier: "ae1ab766ec2faf5d8a64fda108ed6b00")
!419 = !{!420}
!420 = !DICompositeType(tag: DW_TAG_variant_part, scope: !418, file: !2, size: 16, align: 8, elements: !421, templateParams: !23, identifier: "3e57fdb5924d916bd051a85501d58fbd", discriminator: !428)
!421 = !{!422, !424}
!422 = !DIDerivedType(tag: DW_TAG_member, name: "None", scope: !420, file: !2, baseType: !423, size: 16, align: 8, extraData: i128 0)
!423 = !DICompositeType(tag: DW_TAG_structure_type, name: "None", scope: !418, file: !2, size: 16, align: 8, flags: DIFlagPublic, elements: !23, templateParams: !230, identifier: "5e90a323eae6d14376949512e22ed6d")
!424 = !DIDerivedType(tag: DW_TAG_member, name: "Some", scope: !420, file: !2, baseType: !425, size: 16, align: 8, extraData: i128 1)
!425 = !DICompositeType(tag: DW_TAG_structure_type, name: "Some", scope: !418, file: !2, size: 16, align: 8, flags: DIFlagPublic, elements: !426, templateParams: !230, identifier: "140769fcc13738e0ec5c33df1607c48c")
!426 = !{!427}
!427 = !DIDerivedType(tag: DW_TAG_member, name: "__0", scope: !425, file: !2, baseType: !228, size: 8, align: 8, offset: 8, flags: DIFlagPublic)
!428 = !DIDerivedType(tag: DW_TAG_member, scope: !418, file: !2, baseType: !37, size: 8, align: 8, flags: DIFlagArtificial)
!429 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "&mut core::ops::range::Range<i8>", baseType: !430, size: 64, align: 64, dwarfAddressSpace: 0)
!430 = !DICompositeType(tag: DW_TAG_structure_type, name: "Range<i8>", scope: !431, file: !2, size: 16, align: 8, flags: DIFlagPublic, elements: !432, templateParams: !435, identifier: "92362aa716cf8d829698cfebada47d71")
!431 = !DINamespace(name: "range", scope: !401)
!432 = !{!433, !434}
!433 = !DIDerivedType(tag: DW_TAG_member, name: "start", scope: !430, file: !2, baseType: !228, size: 8, align: 8, flags: DIFlagPublic)
!434 = !DIDerivedType(tag: DW_TAG_member, name: "end", scope: !430, file: !2, baseType: !228, size: 8, align: 8, offset: 8, flags: DIFlagPublic)
!435 = !{!436}
!436 = !DITemplateTypeParameter(name: "Idx", type: !228)
!437 = !{!438, !439}
!438 = !DILocalVariable(name: "self", arg: 1, scope: !411, file: !412, line: 751, type: !429)
!439 = !DILocalVariable(name: "old", scope: !440, file: !412, line: 753, type: !228, align: 1)
!440 = distinct !DILexicalBlock(scope: !411, file: !412, line: 753, column: 13)
!441 = !DILocation(line: 751, column: 18, scope: !411)
!442 = !DILocation(line: 752, column: 25, scope: !411)
!443 = !DILocation(line: 752, column: 12, scope: !411)
!444 = !DILocation(line: 758, column: 13, scope: !411)
!445 = !DILocation(line: 752, column: 9, scope: !411)
!446 = !DILocation(line: 753, column: 23, scope: !411)
!447 = !DILocation(line: 753, column: 17, scope: !440)
!448 = !DILocation(line: 755, column: 35, scope: !440)
!449 = !DILocation(line: 755, column: 13, scope: !440)
!450 = !DILocation(line: 756, column: 13, scope: !440)
!451 = !DILocation(line: 760, column: 6, scope: !411)
!452 = !{i8 0, i8 2}
!453 = distinct !DISubprogram(name: "next<i8>", linkageName: "_RNvXs4_NtNtCsaflpkWScbL9_4core4iter5rangeINtNtNtB9_3ops5range5RangeaENtNtNtB7_6traits8iterator8Iterator4nextCs7vJBeK7brjY_8lto_hang", scope: !454, file: !412, line: 842, type: !416, scopeLine: 842, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !457, retainedNodes: !455)
!454 = !DINamespace(name: "{impl#6}", scope: !414)
!455 = !{!456}
!456 = !DILocalVariable(name: "self", arg: 1, scope: !453, file: !412, line: 842, type: !429)
!457 = !{!458}
!458 = !DITemplateTypeParameter(name: "A", type: !228)
!459 = !DILocation(line: 842, column: 13, scope: !453)
!460 = !DILocation(line: 843, column: 9, scope: !453)
!461 = !DILocation(line: 844, column: 6, scope: !453)
!462 = distinct !DISubprogram(name: "into_iter<core::ops::range::Range<i8>>", linkageName: "_RNvXs_NtNtNtCsaflpkWScbL9_4core4iter6traits7collectINtNtNtBa_3ops5range5RangeaENtB4_12IntoIterator9into_iterCs7vJBeK7brjY_8lto_hang", scope: !464, file: !463, line: 355, type: !467, scopeLine: 355, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !471, retainedNodes: !469)
!463 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/core/src/iter/traits/collect.rs", directory: "", checksumkind: CSK_MD5, checksum: "ba5ae75acba44b2070f97e6bc210e7de")
!464 = !DINamespace(name: "{impl#1}", scope: !465)
!465 = !DINamespace(name: "collect", scope: !466)
!466 = !DINamespace(name: "traits", scope: !415)
!467 = !DISubroutineType(types: !468)
!468 = !{!430, !430}
!469 = !{!470}
!470 = !DILocalVariable(name: "self", arg: 1, scope: !462, file: !463, line: 355, type: !430)
!471 = !{!472}
!472 = !DITemplateTypeParameter(name: "I", type: !430)
!473 = !DILocation(line: 355, column: 18, scope: !462)
!474 = !DILocation(line: 357, column: 6, scope: !462)
!475 = distinct !DISubprogram(name: "call_once<fn(), ()>", linkageName: "_RNvYFEuINtNtNtCsaflpkWScbL9_4core3ops8function6FnOnceuE9call_onceCs7vJBeK7brjY_8lto_hang", scope: !399, file: !398, line: 250, type: !330, scopeLine: 250, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !479, retainedNodes: !476)
!476 = !{!477, !478}
!477 = !DILocalVariable(arg: 1, scope: !475, file: !398, line: 250, type: !20)
!478 = !DILocalVariable(arg: 2, scope: !475, file: !398, line: 250, type: !7)
!479 = !{!480, !409}
!480 = !DITemplateTypeParameter(name: "Self", type: !20)
!481 = !DILocation(line: 250, column: 5, scope: !475)
!482 = distinct !DISubprogram(name: "call_once<std::rt::lang_start::{closure_env#0}<()>, ()>", linkageName: "_RNvYNCINvNtCscguycxaEVVT_3std2rt10lang_startuE0INtNtNtCsaflpkWScbL9_4core3ops8function6FnOnceuE9call_onceCs7vJBeK7brjY_8lto_hang", scope: !399, file: !398, line: 250, type: !483, scopeLine: 250, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !407, retainedNodes: !485)
!483 = !DISubroutineType(types: !484)
!484 = !{!356, !14}
!485 = !{!486, !487}
!486 = !DILocalVariable(arg: 1, scope: !482, file: !398, line: 250, type: !14)
!487 = !DILocalVariable(arg: 2, scope: !482, file: !398, line: 250, type: !7)
!488 = !DILocation(line: 250, column: 5, scope: !482)
!489 = distinct !DISubprogram(name: "forward_unchecked", linkageName: "_ZN46_$LT$i8$u20$as$u20$core..iter..range..Step$GT$17forward_unchecked17h02c715c02f324e03E", scope: !490, file: !412, line: 189, type: !491, scopeLine: 189, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, retainedNodes: !493)
!490 = !DINamespace(name: "{impl#36}", scope: !414)
!491 = !DISubroutineType(types: !492)
!492 = !{!228, !228, !9}
!493 = !{!494, !495}
!494 = !DILocalVariable(name: "start", arg: 1, scope: !489, file: !412, line: 189, type: !228)
!495 = !DILocalVariable(name: "n", arg: 2, scope: !489, file: !412, line: 189, type: !9)
!496 = !DILocation(line: 189, column: 37, scope: !489)
!497 = !DILocalVariable(name: "self", arg: 1, scope: !498, file: !499, line: 545, type: !228)
!498 = distinct !DISubprogram(name: "checked_add_unsigned", linkageName: "_ZN4core3num20_$LT$impl$u20$i8$GT$20checked_add_unsigned17h6d09d952ab676598E", scope: !500, file: !499, line: 545, type: !502, scopeLine: 545, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, retainedNodes: !504)
!499 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/core/src/num/int_macros.rs", directory: "", checksumkind: CSK_MD5, checksum: "b995099a9f7db857add856bfd3ff5d73")
!500 = !DINamespace(name: "{impl#0}", scope: !501)
!501 = !DINamespace(name: "num", scope: !36)
!502 = !DISubroutineType(types: !503)
!503 = !{!418, !228, !37}
!504 = !{!497, !505, !506, !508}
!505 = !DILocalVariable(name: "rhs", arg: 2, scope: !498, file: !499, line: 545, type: !37)
!506 = !DILocalVariable(name: "a", scope: !507, file: !499, line: 546, type: !228, align: 1)
!507 = distinct !DILexicalBlock(scope: !498, file: !499, line: 546, column: 13)
!508 = !DILocalVariable(name: "b", scope: !507, file: !499, line: 546, type: !509, align: 1)
!509 = !DIBasicType(name: "bool", size: 8, encoding: DW_ATE_boolean)
!510 = !DILocation(line: 545, column: 43, scope: !498, inlinedAt: !511)
!511 = !DILocation(line: 191, column: 28, scope: !489)
!512 = !DILocalVariable(name: "self", arg: 1, scope: !513, file: !499, line: 2386, type: !228)
!513 = distinct !DISubprogram(name: "overflowing_add_unsigned", linkageName: "_ZN4core3num20_$LT$impl$u20$i8$GT$24overflowing_add_unsigned17h19a0f4d56f0de099E", scope: !500, file: !499, line: 2386, type: !514, scopeLine: 2386, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, retainedNodes: !520)
!514 = !DISubroutineType(types: !515)
!515 = !{!516, !228, !37}
!516 = !DICompositeType(tag: DW_TAG_structure_type, name: "(i8, bool)", file: !2, size: 16, align: 8, elements: !517, templateParams: !23, identifier: "1aeb764860112e49ba68336506b5226")
!517 = !{!518, !519}
!518 = !DIDerivedType(tag: DW_TAG_member, name: "__0", scope: !516, file: !2, baseType: !228, size: 8, align: 8)
!519 = !DIDerivedType(tag: DW_TAG_member, name: "__1", scope: !516, file: !2, baseType: !509, size: 8, align: 8, offset: 8)
!520 = !{!512, !521, !522, !524, !526}
!521 = !DILocalVariable(name: "rhs", arg: 2, scope: !513, file: !499, line: 2386, type: !37)
!522 = !DILocalVariable(name: "rhs", scope: !523, file: !499, line: 2387, type: !228, align: 1)
!523 = distinct !DILexicalBlock(scope: !513, file: !499, line: 2387, column: 13)
!524 = !DILocalVariable(name: "res", scope: !525, file: !499, line: 2388, type: !228, align: 1)
!525 = distinct !DILexicalBlock(scope: !523, file: !499, line: 2388, column: 13)
!526 = !DILocalVariable(name: "overflowed", scope: !525, file: !499, line: 2388, type: !509, align: 1)
!527 = !DILocation(line: 2386, column: 47, scope: !513, inlinedAt: !528)
!528 = !DILocation(line: 546, column: 31, scope: !498, inlinedAt: !511)
!529 = !DILocalVariable(name: "self", arg: 1, scope: !530, file: !499, line: 2304, type: !228)
!530 = distinct !DISubprogram(name: "overflowing_add", linkageName: "_ZN4core3num20_$LT$impl$u20$i8$GT$15overflowing_add17hb0cf5263ac6fa83bE", scope: !500, file: !499, line: 2304, type: !531, scopeLine: 2304, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, retainedNodes: !533)
!531 = !DISubroutineType(types: !532)
!532 = !{!516, !228, !228}
!533 = !{!529, !534, !535, !537}
!534 = !DILocalVariable(name: "rhs", arg: 2, scope: !530, file: !499, line: 2304, type: !228)
!535 = !DILocalVariable(name: "a", scope: !536, file: !499, line: 2305, type: !228, align: 1)
!536 = distinct !DILexicalBlock(scope: !530, file: !499, line: 2305, column: 13)
!537 = !DILocalVariable(name: "b", scope: !536, file: !499, line: 2305, type: !509, align: 1)
!538 = !DILocation(line: 2304, column: 38, scope: !530, inlinedAt: !539)
!539 = !DILocation(line: 2388, column: 42, scope: !523, inlinedAt: !528)
!540 = !DILocation(line: 189, column: 50, scope: !489)
!541 = !DILocalVariable(name: "self", arg: 1, scope: !542, file: !543, line: 1077, type: !418)
!542 = distinct !DISubprogram(name: "unwrap_unchecked<i8>", linkageName: "_RNvMNtCsaflpkWScbL9_4core6optionINtB2_6OptionaE16unwrap_uncheckedCs7vJBeK7brjY_8lto_hang", scope: !418, file: !543, line: 1077, type: !544, scopeLine: 1077, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !230, declaration: !554, retainedNodes: !555)
!543 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/core/src/option.rs", directory: "", checksumkind: CSK_MD5, checksum: "4d43394f8c71dd9cc814c64ba679d486")
!544 = !DISubroutineType(types: !545)
!545 = !{!228, !418, !546}
!546 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "&core::panic::location::Location", baseType: !547, size: 64, align: 64, dwarfAddressSpace: 0)
!547 = !DICompositeType(tag: DW_TAG_structure_type, name: "Location", scope: !548, file: !2, size: 192, align: 64, flags: DIFlagPublic, elements: !550, templateParams: !23, identifier: "3e7c437b4e44cc3972305a166d1e6473")
!548 = !DINamespace(name: "location", scope: !549)
!549 = !DINamespace(name: "panic", scope: !36)
!550 = !{!551, !552, !553}
!551 = !DIDerivedType(tag: DW_TAG_member, name: "file", scope: !547, file: !2, baseType: !53, size: 128, align: 64, flags: DIFlagPrivate)
!552 = !DIDerivedType(tag: DW_TAG_member, name: "line", scope: !547, file: !2, baseType: !80, size: 32, align: 32, offset: 128, flags: DIFlagPrivate)
!553 = !DIDerivedType(tag: DW_TAG_member, name: "col", scope: !547, file: !2, baseType: !80, size: 32, align: 32, offset: 160, flags: DIFlagPrivate)
!554 = !DISubprogram(name: "unwrap_unchecked<i8>", linkageName: "_RNvMNtCsaflpkWScbL9_4core6optionINtB2_6OptionaE16unwrap_uncheckedCs7vJBeK7brjY_8lto_hang", scope: !418, file: !543, line: 1077, type: !544, scopeLine: 1077, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagOptimized, templateParams: !230)
!555 = !{!541, !556}
!556 = !DILocalVariable(name: "val", scope: !557, file: !543, line: 1079, type: !228, align: 1)
!557 = distinct !DILexicalBlock(scope: !542, file: !543, line: 1079, column: 13)
!558 = !DILocation(line: 1077, column: 42, scope: !542, inlinedAt: !559)
!559 = !DILocation(line: 191, column: 65, scope: !489)
!560 = !DILocation(line: 191, column: 22, scope: !489)
!561 = !DILocation(line: 191, column: 49, scope: !489)
!562 = !DILocation(line: 545, column: 49, scope: !498, inlinedAt: !511)
!563 = !DILocation(line: 2386, column: 53, scope: !513, inlinedAt: !528)
!564 = !DILocation(line: 2387, column: 23, scope: !513, inlinedAt: !528)
!565 = !DILocation(line: 2387, column: 17, scope: !523, inlinedAt: !528)
!566 = !DILocation(line: 2304, column: 44, scope: !530, inlinedAt: !539)
!567 = !DILocation(line: 2305, column: 26, scope: !530, inlinedAt: !539)
!568 = !DILocation(line: 2305, column: 18, scope: !530, inlinedAt: !539)
!569 = !DILocation(line: 546, column: 18, scope: !507, inlinedAt: !511)
!570 = !DILocation(line: 2388, column: 18, scope: !525, inlinedAt: !528)
!571 = !DILocation(line: 2305, column: 18, scope: !536, inlinedAt: !539)
!572 = !DILocation(line: 2305, column: 21, scope: !530, inlinedAt: !539)
!573 = !DILocation(line: 2388, column: 23, scope: !525, inlinedAt: !528)
!574 = !DILocation(line: 2305, column: 21, scope: !536, inlinedAt: !539)
!575 = !DILocation(line: 2389, column: 32, scope: !525, inlinedAt: !528)
!576 = !DILocation(line: 2389, column: 19, scope: !525, inlinedAt: !528)
!577 = !DILocation(line: 546, column: 21, scope: !507, inlinedAt: !511)
!578 = !DILocation(line: 547, column: 16, scope: !507, inlinedAt: !511)
!579 = !DILocation(line: 547, column: 56, scope: !507, inlinedAt: !511)
!580 = !DILocation(line: 1079, column: 18, scope: !542, inlinedAt: !559)
!581 = !DILocation(line: 1079, column: 18, scope: !557, inlinedAt: !559)
!582 = !DILocation(line: 191, column: 82, scope: !489)
!583 = !DILocation(line: 192, column: 10, scope: !489)
!584 = !DILocation(line: 547, column: 42, scope: !507, inlinedAt: !511)
!585 = !DILocation(line: 77, column: 35, scope: !586, inlinedAt: !589)
!586 = !DILexicalBlockFile(scope: !588, file: !587, discriminator: 0)
!587 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/core/src/ub_checks.rs", directory: "", checksumkind: CSK_MD5, checksum: "70c085c1e8c518a1929aea5cf87e989a")
!588 = distinct !DISubprogram(name: "unreachable_unchecked", linkageName: "_ZN4core4hint21unreachable_unchecked17h4752e3f281443123E", scope: !343, file: !342, line: 101, type: !21, scopeLine: 101, flags: DIFlagPrototyped | DIFlagNoReturn, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23)
!589 = !DILocation(line: 1081, column: 30, scope: !542, inlinedAt: !559)
!590 = !DILocation(line: 78, column: 17, scope: !586, inlinedAt: !589)
!591 = !DILocation(line: 0, scope: !592, inlinedAt: !559)
!592 = !DILexicalBlockFile(scope: !542, file: !593, discriminator: 0)
!593 = !DIFile(filename: "../../src/lib/lto-hang/src/main.rs", directory: ".", checksumkind: CSK_MD5, checksum: "5446fdabeea50a01108c1bf6af070029")
!594 = distinct !DISubprogram(name: "unlikely", linkageName: "_ZN4core10intrinsics8unlikely17hde30836616cdb810E", scope: !596, file: !595, line: 1038, type: !597, scopeLine: 1038, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, retainedNodes: !599)
!595 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/core/src/intrinsics/mod.rs", directory: "", checksumkind: CSK_MD5, checksum: "6d4a6d6a58e6a1dbc862bee5bd5cb802")
!596 = !DINamespace(name: "intrinsics", scope: !36)
!597 = !DISubroutineType(types: !598)
!598 = !{!509, !509}
!599 = !{!600}
!600 = !DILocalVariable(name: "b", arg: 1, scope: !594, file: !595, line: 1038, type: !509)
!601 = !DILocation(line: 1038, column: 23, scope: !594)
!602 = !DILocation(line: 1040, column: 2, scope: !594)
!603 = distinct !DISubprogram(name: "lt", linkageName: "_ZN4core3cmp5impls54_$LT$impl$u20$core..cmp..PartialOrd$u20$for$u20$i8$GT$2lt17h5eda5ff3f1ac5b3fE", scope: !605, file: !604, line: 1720, type: !608, scopeLine: 1720, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, retainedNodes: !610)
!604 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/core/src/cmp.rs", directory: "", checksumkind: CSK_MD5, checksum: "6514baa4261f88fbee4787020ca20aad")
!605 = !DINamespace(name: "{impl#72}", scope: !606)
!606 = !DINamespace(name: "impls", scope: !607)
!607 = !DINamespace(name: "cmp", scope: !36)
!608 = !DISubroutineType(types: !609)
!609 = !{!509, !227, !227}
!610 = !{!611, !612}
!611 = !DILocalVariable(name: "self", arg: 1, scope: !603, file: !604, line: 1720, type: !227)
!612 = !DILocalVariable(name: "other", arg: 2, scope: !603, file: !604, line: 1720, type: !227)
!613 = !DILocation(line: 1720, column: 23, scope: !603)
!614 = !DILocation(line: 1720, column: 30, scope: !603)
!615 = !DILocation(line: 1720, column: 52, scope: !603)
!616 = !DILocation(line: 1720, column: 62, scope: !603)
!617 = !DILocation(line: 1720, column: 72, scope: !603)
!618 = distinct !DISubprogram(name: "fmt", linkageName: "_ZN4core3fmt3num49_$LT$impl$u20$core..fmt..Debug$u20$for$u20$i8$GT$3fmt17ha6c07ac2a98e4d11E", scope: !620, file: !619, line: 180, type: !240, scopeLine: 180, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, retainedNodes: !622)
!619 = !DIFile(filename: "/b/s/w/ir/x/w/fuchsia-third_party-rust/library/core/src/fmt/num.rs", directory: "", checksumkind: CSK_MD5, checksum: "05d1962e69b15830e728f4370af03817")
!620 = !DINamespace(name: "{impl#78}", scope: !621)
!621 = !DINamespace(name: "num", scope: !35)
!622 = !{!623, !624}
!623 = !DILocalVariable(name: "self", arg: 1, scope: !618, file: !619, line: 180, type: !227)
!624 = !DILocalVariable(name: "f", arg: 2, scope: !618, file: !619, line: 180, type: !149)
!625 = !DILocation(line: 180, column: 24, scope: !618)
!626 = !DILocation(line: 180, column: 31, scope: !618)
!627 = !DILocalVariable(name: "self", arg: 1, scope: !628, file: !45, line: 1936, type: !149)
!628 = distinct !DISubprogram(name: "debug_lower_hex", linkageName: "_ZN4core3fmt9Formatter15debug_lower_hex17hcba9cf2ba67f85d8E", scope: !150, file: !45, line: 1936, type: !629, scopeLine: 1936, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, declaration: !632, retainedNodes: !633)
!629 = !DISubroutineType(types: !630)
!630 = !{!509, !631}
!631 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "&core::fmt::Formatter", baseType: !150, size: 64, align: 64, dwarfAddressSpace: 0)
!632 = !DISubprogram(name: "debug_lower_hex", linkageName: "_ZN4core3fmt9Formatter15debug_lower_hex17hcba9cf2ba67f85d8E", scope: !150, file: !45, line: 1936, type: !629, scopeLine: 1936, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagOptimized, templateParams: !23)
!633 = !{!627}
!634 = !DILocation(line: 1936, column: 24, scope: !628, inlinedAt: !635)
!635 = !DILocation(line: 181, column: 26, scope: !618)
!636 = !DILocalVariable(name: "self", arg: 1, scope: !637, file: !45, line: 1940, type: !149)
!637 = distinct !DISubprogram(name: "debug_upper_hex", linkageName: "_ZN4core3fmt9Formatter15debug_upper_hex17h83b93444cb59c791E", scope: !150, file: !45, line: 1940, type: !629, scopeLine: 1940, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, declaration: !638, retainedNodes: !639)
!638 = !DISubprogram(name: "debug_upper_hex", linkageName: "_ZN4core3fmt9Formatter15debug_upper_hex17h83b93444cb59c791E", scope: !150, file: !45, line: 1940, type: !629, scopeLine: 1940, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagOptimized, templateParams: !23)
!639 = !{!636}
!640 = !DILocation(line: 1940, column: 24, scope: !637, inlinedAt: !641)
!641 = !DILocation(line: 183, column: 33, scope: !618)
!642 = !DILocation(line: 1937, column: 9, scope: !628, inlinedAt: !635)
!643 = !DILocation(line: 181, column: 24, scope: !618)
!644 = !DILocation(line: 1941, column: 9, scope: !637, inlinedAt: !641)
!645 = !DILocation(line: 183, column: 31, scope: !618)
!646 = !DILocation(line: 182, column: 25, scope: !618)
!647 = !DILocation(line: 186, column: 25, scope: !618)
!648 = !DILocation(line: 184, column: 25, scope: !618)
!649 = !DILocation(line: 181, column: 21, scope: !618)
!650 = !DILocation(line: 188, column: 18, scope: !618)
!651 = distinct !DISubprogram(name: "precondition_check", linkageName: "_ZN4core4hint21unreachable_unchecked18precondition_check17h0d35aaba5534f423E", scope: !652, file: !587, line: 69, type: !21, scopeLine: 69, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23)
!652 = !DINamespace(name: "unreachable_unchecked", scope: !343)
!653 = !DILocation(line: 71, column: 21, scope: !651)
!654 = distinct !DISubprogram(name: "report", linkageName: "_ZN54_$LT$$LP$$RP$$u20$as$u20$std..process..Termination$GT$6report17h21d63d7df63b3af2E", scope: !655, file: !363, line: 2422, type: !656, scopeLine: 2422, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, retainedNodes: !658)
!655 = !DINamespace(name: "{impl#57}", scope: !365)
!656 = !DISubroutineType(types: !657)
!657 = !{!364, !7}
!658 = !{!659, !660}
!659 = !DILocalVariable(name: "self", scope: !654, file: !363, line: 2422, type: !7, align: 1)
!660 = !DILocalVariable(arg: 1, scope: !654, file: !363, line: 2422, type: !7)
!661 = !DILocation(line: 2422, column: 15, scope: !654)
!662 = !DILocation(line: 2424, column: 6, scope: !654)
!663 = distinct !DISubprogram(name: "new", linkageName: "_RNvMCs7vJBeK7brjY_8lto_hangNtB2_4Test3new", scope: !664, file: !593, line: 9, type: !671, scopeLine: 9, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, declaration: !673)
!664 = !DICompositeType(tag: DW_TAG_structure_type, name: "Test", scope: !665, file: !2, size: 192, align: 64, flags: DIFlagPrivate, elements: !666, templateParams: !23, identifier: "5bc35746dfa6cee5fcf83015ec0c7ffd")
!665 = !DINamespace(name: "lto_hang", scope: null)
!666 = !{!667, !669, !670}
!667 = !DIDerivedType(tag: DW_TAG_member, name: "samples", scope: !664, file: !2, baseType: !668, size: 16, align: 8, offset: 128, flags: DIFlagPrivate)
!668 = !DICompositeType(tag: DW_TAG_array_type, baseType: !228, size: 16, align: 8, elements: !197)
!669 = !DIDerivedType(tag: DW_TAG_member, name: "n", scope: !664, file: !2, baseType: !9, size: 64, align: 64, flags: DIFlagPrivate)
!670 = !DIDerivedType(tag: DW_TAG_member, name: "i", scope: !664, file: !2, baseType: !9, size: 64, align: 64, offset: 64, flags: DIFlagPrivate)
!671 = !DISubroutineType(types: !672)
!672 = !{!664}
!673 = !DISubprogram(name: "new", linkageName: "_RNvMCs7vJBeK7brjY_8lto_hangNtB2_4Test3new", scope: !664, file: !593, line: 9, type: !671, scopeLine: 9, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagOptimized, templateParams: !23)
!674 = !DILocation(line: 11, column: 35, scope: !663)
!675 = !DILocation(line: 10, column: 9, scope: !663)
!676 = !DILocation(line: 12, column: 9, scope: !663)
!677 = !DILocation(line: 13, column: 6, scope: !663)
!678 = distinct !DISubprogram(name: "add", linkageName: "_RNvMCs7vJBeK7brjY_8lto_hangNtB2_4Test3add", scope: !664, file: !593, line: 15, type: !679, scopeLine: 15, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, declaration: !682, retainedNodes: !683)
!679 = !DISubroutineType(types: !680)
!680 = !{null, !681, !228}
!681 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "&mut lto_hang::Test", baseType: !664, size: 64, align: 64, dwarfAddressSpace: 0)
!682 = !DISubprogram(name: "add", linkageName: "_RNvMCs7vJBeK7brjY_8lto_hangNtB2_4Test3add", scope: !664, file: !593, line: 15, type: !679, scopeLine: 15, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagOptimized, templateParams: !23)
!683 = !{!684, !685}
!684 = !DILocalVariable(name: "self", arg: 1, scope: !678, file: !593, line: 15, type: !681)
!685 = !DILocalVariable(name: "new", arg: 2, scope: !678, file: !593, line: 15, type: !228)
!686 = !DILocation(line: 15, column: 12, scope: !678)
!687 = !DILocation(line: 15, column: 23, scope: !678)
!688 = !DILocation(line: 16, column: 9, scope: !678)
!689 = !DILocation(line: 17, column: 12, scope: !678)
!690 = !DILocation(line: 17, column: 9, scope: !678)
!691 = !DILocation(line: 18, column: 13, scope: !678)
!692 = !DILocation(line: 20, column: 12, scope: !678)
!693 = !DILocation(line: 23, column: 22, scope: !678)
!694 = !DILocation(line: 23, column: 9, scope: !678)
!695 = !DILocation(line: 21, column: 13, scope: !678)
!696 = !DILocation(line: 24, column: 19, scope: !678)
!697 = !DILocation(line: 24, column: 18, scope: !678)
!698 = !DILocation(line: 24, column: 9, scope: !678)
!699 = !DILocation(line: 25, column: 6, scope: !678)
!700 = distinct !DISubprogram(name: "do_the_test", linkageName: "_RNvCs7vJBeK7brjY_8lto_hang11do_the_test", scope: !665, file: !593, line: 29, type: !21, scopeLine: 29, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !30, templateParams: !23, retainedNodes: !701)
!701 = !{!702, !704, !706}
!702 = !DILocalVariable(name: "test", scope: !703, file: !593, line: 30, type: !664, align: 8)
!703 = distinct !DILexicalBlock(scope: !700, file: !593, line: 30, column: 5)
!704 = !DILocalVariable(name: "iter", scope: !705, file: !593, line: 31, type: !430, align: 1)
!705 = distinct !DILexicalBlock(scope: !703, file: !593, line: 31, column: 5)
!706 = !DILocalVariable(name: "i", scope: !707, file: !593, line: 31, type: !228, align: 1)
!707 = distinct !DILexicalBlock(scope: !705, file: !593, line: 31, column: 20)
!708 = !DILocation(line: 30, column: 9, scope: !703)
!709 = !DILocation(line: 31, column: 14, scope: !705)
!710 = !DILocation(line: 30, column: 9, scope: !700)
!711 = !DILocation(line: 30, column: 20, scope: !700)
!712 = !DILocation(line: 31, column: 14, scope: !703)
!713 = !DILocation(line: 31, column: 5, scope: !705)
!714 = !DILocation(line: 33, column: 5, scope: !705)
!715 = !DILocation(line: 33, column: 5, scope: !703)
!716 = !DILocation(line: 34, column: 5, scope: !703)
!717 = !DILocation(line: 35, column: 1, scope: !700)
!718 = !DILocation(line: 35, column: 2, scope: !700)
!719 = !DILocation(line: 31, column: 9, scope: !705)
!720 = !DILocation(line: 31, column: 9, scope: !707)
!721 = !DILocation(line: 32, column: 9, scope: !707)
!722 = distinct !DISubprogram(name: "main", linkageName: "_RNvCs7vJBeK7brjY_8lto_hang4main", scope: !665, file: !593, line: 37, type: !21, scopeLine: 37, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized | DISPFlagMainSubprogram, unit: !30, templateParams: !23)
!723 = !DILocation(line: 38, column: 5, scope: !722)
!724 = !DILocation(line: 39, column: 2, scope: !722)

