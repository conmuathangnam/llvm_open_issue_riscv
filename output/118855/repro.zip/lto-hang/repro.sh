#!/bin/bash

OPT=%HOME/llvm-fork/build/bin/opt

${OPT} -passes=indvars -S < before.indvars.0.ll -o after.indvars.1.ll
${OPT} -passes=instcombine -S < after.indvars.1.ll -o after.instcombine.2.ll
${OPT} -passes=simplifycfg -S < after.instcombine.2.ll -o after.simplifycfg.0.ll

